These content element files are for 
 JoomFish 2.x (should be working with 1.8.x as well)
and
 RSGallery 2.x (should be working with 1.14 as well)

30 march 2010