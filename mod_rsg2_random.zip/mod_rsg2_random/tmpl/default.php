<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); ?>

<table class="rsg2_random_table" align="center">
    <tr>
        <td align="center">
            <b>Random Picture<?php if( ((int)$params->get('count')) > 1)echo 's'; ?></b>
        </td>
    </tr>
    <?php
    foreach($images as $item)
    {
        echo modRSG2RandomHelper::getImageCell( $item );
        
        if( $params->get('display_title') )
        {
            echo modRSG2RandomHelper::getImageTitle( $item );
        }
    }
   ?>
</table>