<?php
/**
 * RSGallery2 random picture Module Entry Point
 * 
 * @ package Joomla! Open Source
 * @subpackage Modules
 * @ Joomla! Open Source is Free Software
 * @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @ version 0.0.1
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Include the syndicate functions only once
require_once( dirname(__FILE__).DS.'helper.php' );

$images = modRSG2RandomHelper::getRandomImage( $params );

require( JModuleHelper::getLayoutPath( 'mod_rsg2_random' ) );