<?php
/**
* Tab to display the link to the RSGallery2 edit page in Community Builder
* Author: Dave Ludwigsen (palamangelus) dave@daveludwigsen.com
*/

class getrsgallery2Tab extends cbTabHandler 
{
	function getrsgallery2Tab() 
	{
		$this->cbTabHandler();
	}
	
	function getDisplayTab($tab,$user,$ui) 
	{
		global $database, $mosConfig_live_site, $mosConfig_absolute_path, $mosConfig_lang;
	
		//$params = $this->params;
		//$eventLimit = $params->get('rsgallery2Link','');

		//$query = "SELECT id FROM #__uhp WHERE user_id='".$user->id."'";
		//$database->setQuery($query);
		//$uhpid = $database->loadResult();
	
		$return=$this->ShowUserGalleries($user);

		return $return;
	}

	function ShowUserGalleries($user)
	{
		global $my, $database, $Itemid;

		$htmlText = "";
	
		//if this user, show edit galleries link
		if ($my->id == $user->id)
		{
			$htmlText.="<div align=left><a href=\"index.php?option=com_rsgallery2&rsgOption=myGalleries\">My Galleries</a></div><br><br>";
		}

		
		//Prepare query for gallery list
		
		$htmlText.="<div>Galleries<br><br>";
		$database->setQuery("SELECT * FROM #__rsgallery2_galleries WHERE published=1 AND parent=0 AND uid=".$user->id." ORDER BY ordering ASC");
		//$htmlText.="SELECT * FROM #__rsgallery2_galleries WHERE published=1 AND parent=0 AND uid=".$my->id." ORDER BY ordering ASC";
		//Loop through the galleries
     		$galleries=$database->loadObjectList();

		$htmlText.="<div><ul type=none>";
	        foreach ($galleries as $gallery) 
		{
			$htmlText.="<li>";
			$htmlText.="<a href=\"/index.php?option=com_rsgallery2&Itemid=".$Itemid."&catid=".$gallery->id."\">";

			//get the first image for the gallery
			//images/rsgallery/thumb/
			$database->setQuery("SELECT * FROM #__rsgallery2_files WHERE gallery_id=".$gallery->id." LIMIT 1");
			//$htmlText.="SELECT * FROM #__rsgallery2_files WHERE gallery_id=".$gallery->id." LIMIT 1";
			$thumbnails=$database->loadObjectList();

			//leave room in case we later want to expand for more thumbnails.
			foreach ($thumbnails as $thumbnail)
			{
				$htmlText.="<img src=\"/images/rsgallery/thumb/".$thumbnail->name.".jpg\" border=0 alt=\"".$thumbnail->descr."\" valign=absmiddle> ";
				break;
			}

			$htmlText.=$gallery->name;
			$htmlText.="</a></li>";
		}
		$htmlText.="</ul></div></div>";	
		return $htmlText;
	}

}	
?>