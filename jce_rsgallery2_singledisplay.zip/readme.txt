RSGallery2 is a Joomla component for creating image galleries.
www.rsgallery2.nl

With the "RSGallery2 Single Image Display plugin" (for Joomla) you can insert an image in an article by entering " {rsg2_singledisplay: imageid, size, caption, format}".

JCE is a configurable WYSIWYG editor for Joomla! based on Moxiecode's TinyMCE. Plugins can be used to expand its functionality.
http://www.joomlacontenteditor.net/

This "RSGallery2 Single Image Display plugin" for JCE inserts {rsg2_singledisplay: imageid, size, caption, format} based on chosen options. You need
- RSGallery2
- RSGallery2 Single Image Display plugin
- JCE
and of course this plugin.