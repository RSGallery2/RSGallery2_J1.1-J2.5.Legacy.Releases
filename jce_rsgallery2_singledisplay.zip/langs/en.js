// UK lang variables
tinyMCE.addI18n('en.rsg2_singledisplay',{
desc : 'RSG2_SingleDisplay',
delta_width : 0,
delta_height : 0
});
