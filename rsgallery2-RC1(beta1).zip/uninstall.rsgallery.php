<?php
/**
* This file handles the uninstall processing for RSGallery.
*
* @version $ 2.0 RC-1 $
* @package RSGallery_2.0
* @copyright (C) 2003 - 2004 RSDevelopment
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* RSGallery is Free Software
**/

function com_uninstall()
	{
	require_once("../configuration.php");
	global $database;
	echo "Uninstalled succesfully";
	}
?>
