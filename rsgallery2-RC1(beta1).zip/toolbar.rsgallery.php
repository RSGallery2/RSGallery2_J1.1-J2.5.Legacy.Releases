<?php
// $Id: toolbar.rsgallery.php,v 1.1 2005/04/22 15:04:11 richardjfoster Exp $
/**
* Weblink Toolbar Menu
* @package Mambo Open Source
* @Copyright (C) 2000 - 2003 Miro International Pty Ltd
* @ All rights reserved
* @ Mambo Open Source is Free Software
* @ Released under GNU/GPL License: http://www.gnu.org/copyleft/gpl.html
* @version $Revision: 1.1 $
**/

// ensure this file is being included by a parent file
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

require_once( $mainframe->getPath( 'toolbar_html' ) );
require_once( $mainframe->getPath( 'toolbar_default' ) );

switch ($task)
	{
	case "new":
		menuRSGallery::NEW_MENU();
		break;

	case "edit_image":
		menuRSGallery::EDIT_MENU();
		break;
		
	case "upload":
		menuRSGallery::UPLOAD_MENU();
		break;
	
	case "view_images":
	case "images_orderup":
	case "images_orderdown":
		menuRSGallery::VIEW_IMAGES_MENU();
		break;
		
	case "view_categories":
	case "categories_orderup":
	case "categories_orderdown":
		menuRSGallery::VIEW_CAT_MENU();
		break;
		
	case "new_category":
		menuRSGallery::NEWCAT_MENU();
		break;
		
	case "edit_category":
		menuRSGallery::EDITCAT_MENU();
		break;

	case "settings":
		menuRSGallery::SETTINGS_MENU();
		break;

	default:
		menuRSGallery::VIEW_IMAGES_MENU();
		break;
	}
?>