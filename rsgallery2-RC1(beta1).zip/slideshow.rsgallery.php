<?php
/**
* This file handles the slideshow processing for RSGallery.
*
* @version $ 2.0 RC-1 $
* @package RSGallery_2.0
* @copyright (C) 2003 - 2004 RSDevelopment
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* RSGallery is Free Software
**/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
include($mosConfig_absolute_path.'/configuration.php');
include($mosConfig_absolute_path.'/administrator/components/com_rsgallery/settings.rsgallery.php');

// There is a problem here in that the html below assumes that this is a standalone
// page when in fact it is a 'component' of a Mambo page using a template index.php
// file.  Therefore by the time we are executing this code, the <head> portion of the
// page has already been output or at least sent to the PHP output buffer if output
// buffering is enabled.  Thus, the code below will produce non-conforming html.
// The only way to get this to work properly is to be able to 'insert' the <head>
// portion below into the existing PHP output buffer contents.  Doable, but tricky at best.

// capture all the head output below
ob_start();
?>

<script language="JavaScript" src="components/com_rsgallery/browser_detect.js" type="text/javascript"></script>
<script language="JavaScript" type="text/javascript">
<!--
// (C) 2003 by CodeLifter.com
// Free for all users, but leave in this header.
// Modified by Ronald Smit and Dave McDonnell for RSGallery
// http://www.webdreamers.nl
// Modification date: 23-02-2004

var Picture = new Array(); // don't change this
var Caption = new Array(); // don't change this
var showHot = false;       // don't change this

<?php
//Echo JS-array from DB-query here
$k = 1;
foreach ($rows as $row)
	{
	echo "Picture[".$k."] = '".$mosConfig_live_site.$imagepath.$row->name."'\n";
	$k++;
	}

//Echo JS-array from DB-query here
$r = 1;
foreach ($rows as $row)
	{
	if($row->descr == '') $row->descr = " ";
	echo "Caption[".$r."] = '<h3>".htmlspecialchars(stripslashes($row->descr), ENT_QUOTES)."</h3>'\n";
	$r++;
	}
?>

// =====================================
// Do not edit anything below this line!
// =====================================

var tss;
var iss;
var jss = 0;
var pss = Picture.length-1;

var capTimer;
var timeout=0;
var firstTime=true;
var textfield;
var timer;
var height;
var maxHeight=0;
var imageLoaded=0;

var preLoad = new Array();
for (iss = 1; iss < pss+1; iss++){
	preLoad[iss] = new Image();
	preLoad[iss].onload = function (evt){imageLoaded++; return true;};
	preLoad[iss].src = Picture[iss];
}

function init_vars(){
	//alert('in init_vars');
	// Note that the transition effects are performed on a div containing the image
	// rather than the image itself.  It makes for cleaner transitions this way when
	// the images are of different sizes.  However, the div container must be sized
	// to the max. pic size to prevent display alignment issues.  The maxHeight for
	// all the images is calculated after waiting for all images to preload.
	// loop here waiting for all images to be preloaded and all
	// image dimensions data to be non-zero.  Need to do this because IE does
	// not seem to have the image dimensions always available after the onload event!!
	
	while(imageLoaded < pss) {
		initTimeout = setTimeout("init_vars()", 200);
		return;
	}
	for (iss = 1; iss < pss+1; iss++){
		while (preLoad[iss].height == 0 || preLoad[iss].width == 0) height=0;
		height = preLoad[iss].height * <?php echo $PicWidth; ?> / preLoad[iss].width;
		if (maxHeight < height) maxHeight = height;
		preLoad[iss].height = Math.round(height);
		//alert('preLoad[iss].height is: '+preLoad[iss].height+' and height is: '+height);
	}

	maxHeight = Math.round(maxHeight);
	
	if (browser.isDOM1){
		if(browser.isIE4up) textfield = document.getElementById('item1');
		timer = document.getElementById('item4');
		document.getElementById('CaptionBox').innerHTML= '&nbsp;';
		document.getElementById('pic0').style.height = maxHeight+'px';
		} else if (document.all){
		if(browser.isIE4up) textfield = document.all('form1').item1;
		timer = document.all('form1').item4;
		document.all("CaptionBox").innerHTML= '&nbsp;';
		document.all('pic0').style.height=maxHeight+'px';
	} else if (document.layers) {
		timer = document.layers['form1'].item4;
	}
	showHot= true;
}

function doTimer()
	{
	timer1 = timer.value;
	if (timer1 == 0)
		alert('<?php echo _RSGALLERY_SETSPEED; ?>');
	else
		{
		control('F');
		timeout = setTimeout("doTimer();", timer1);
		}
	}

function doCaption(jss){
	if (browser.isDOM1)
		document.getElementById("CaptionBox").innerHTML= Caption[jss];
	else if(typeof document.all('CaptionBox').innerHTML != 'undefined')
		document.all('CaptionBox').innerHTML= Caption[jss];
	else
		// we assume the textarea we originally defined below is still there
		document.forms('caption').textarea.value = Caption[jss];
}

function control(how){
	if (showHot){

		if (how=="H") 
			jss = 1;
		if (how=="F") 
			jss = jss + 1;
		if (how=="B") 
			jss = jss - 1;
		if (jss > (pss)) 
			jss=1;
		if (jss < 1) 
			jss = pss;

		if(browser.isDOM1)
		    picDivObj = document.getElementById('pic0');
		else
		    picDivObj = document.all.pic0;
		    
		if(browser.isIE4up){

			if (browser.isIE55up && textfield.value == 25){
				// IE 5.5 fade transition
				picDivObj.style.filter = "progid:DXImageTransform.Microsoft.Fade(Duration=1.0, Overlap=0.0, Transition=25)";
				picDivObj.filters.item(0).Apply();
			}
			else if (browser.isIE55up && textfield.value == 24){
				// IE 5.5 fade transition
				//if(picDivObj.filters.item(0)) picDivObj.filters.item(0).Apply();
				picDivObj.style.filter = "";
			}
			else if (browser.isIE55up){
				picDivObj.style.filter = "revealTrans(Duration=1.5, Transition=" + textfield.value + ")";
				picDivObj.filters.item(0).Apply();
			}
			else if (textfield.value < 24){
				// IE built-in transition
				picDivObj.style.filter = "revealTrans(Duration=1.5, Transition=" + textfield.value + ")";
				picDivObj.filters.item(0).Apply();
			}
		}

		if (browser.isDOM1){
			document.getElementById('PictureBox').src = preLoad[jss].src;
			document.getElementById('PictureBox').height = preLoad[jss].height;
			document.getElementById('PictureBox').width = <?php echo $PicWidth; ?>;
		} else if (browser.isIE)
			document.images('PictureBox').src = preLoad[jss].src;

		// Note that you really want the caption to change only when the new pic is
		// coming in.  This can be either at the start or midway thru the transition
		// It's best if the caption actually changes after half the transition period
		if (browser.isIE4up && textfield.value != 24)
			capTimer = setTimeout("doCaption(jss);", 700);
		else
			doCaption(jss);

		if (picDivObj.filters &&
			(browser.isIE55up  && textfield.value != 24 || browser.isIE4up && textfield.value < 24))
			picDivObj.filters.item(0).Play();
	}
}

// if an onload handler for the body is already defined, then we want to daisy chain onto it
//alert('onload handler is:' + window.onload);
if(window.onload)
	{
	var oldOnload = window.onload;
	window.onload = function (evt) {oldOnload();  init_vars()};
	}
//alert('onload handler is:' + window.onload);
else
	{
	window.onload = init_vars;
	}
//-->
</script>

<?php
$myHead = ob_get_contents();
ob_end_clean();

$htmlSoFar = ob_get_contents();
// destroy the MOS output buffer for now, we will recreate after we insert our stuff
ob_end_clean();

//=====================================================================
// ok, this is scary stuff, but it should work.
// The code below is copied from the MOS main index.php file and is used to re-start the
// output buffer.

$do_gzip_compress = FALSE;
if ($mosConfig_gzip==1) {
	$phpver = phpversion();
	$useragent = (isset($_SERVER["HTTP_USER_AGENT"]) ) ? $_SERVER["HTTP_USER_AGENT"] : $HTTP_USER_AGENT;

	if ( $phpver >= '4.0.4pl1' && ( strstr($useragent,'compatible') || strstr($useragent,'Gecko') ) )
	{
		if ( extension_loaded('zlib') )
		{
			ob_start('ob_gzhandler');
		}
	}
	else if ( $phpver > '4.0' )
	{
		if ( strstr($HTTP_SERVER_VARS['HTTP_ACCEPT_ENCODING'], 'gzip') )
		{
			if ( extension_loaded('zlib') )
			{
				$do_gzip_compress = TRUE;
				ob_start();
				ob_implicit_flush(0);

				header('Content-Encoding: gzip');
			}
		}
	}
} else {
	ob_start();
}

// end of MOS obstart code ==========================================================

// Now search the output buffer for the </head> tag so we can insert our own stuff
if (!preg_match('/<[ \t]*\/head[ \t]*>/mi', $htmlSoFar, $match)){
	// error, could not find the ending </head> tag!!  What to do!?
	// print an error message for now.
	echo $htmlSoFar . "<br />ERROR!  RsGallery Slideshow:  Cannot locate the HTML </head> tag for this page!  exiting...<br />";
	exit;
} else {
	if(($htagOffset = strpos($htmlSoFar, $match[0])) === false){
		// error, we SHOULD find it if we found it above.
		echo $htmlSoFar . "<br />ERROR!  RsGallery Slideshow:  secondary HTML </head> tag error for this page!  exiting...<br />";
		exit;
	} else {
		// output the new <head>...</head> section
		echo substr($htmlSoFar,0,$htagOffset) . "\n". $myHead . "</head>\n";
	}
	// go find the <body ... >tag which should be the next tag
	$htmlSoFar = substr($htmlSoFar,$htagOffset+strlen($match[0]));
	// this matching algorithm below is NOT foolproof but reasonable for 95% of the MOS
	// templates most likely.  A more robust algo would need to parse strings delimited
	// by either ' or ".  Will add this in later if it becomes an issue.
	
	if (!preg_match('/<[ \t]*body[^>]*>/mi', $htmlSoFar, $bmatch)){
		// error, could not find the <body ...> tag
		echo $htmlSoFar . "<br />ERROR!  RsGallery Slideshow:  Cannot locate the HTML <body> tag for this page!  exiting...<br />";
		exit;
	} else {
		if(($bodyTagOffset = strpos($htmlSoFar, $bmatch[0])) === false){
			// error, we SHOULD find it if we found it above.
			echo $htmlSoFar . "<br />ERROR!  RsGallery Slideshow:  secondary HTML <body> tag error for this page!  exiting...<br />";
			exit;
		} else {
			$bodyTag = $bmatch[0];
			$htmlSoFar = substr($htmlSoFar, $bodyTagOffset+strlen($bodyTag));
			if(preg_match('/[ \t]+onload[ \t]*=[ \t]*("|\')/', $bodyTag, $omatch)){
				// ok, seems like there is an existing inline onload event handler
				$insertPos = strpos($bodyTag,$omatch[0])+strlen($omatch[0]);
				$bodyTag = substr($bodyTag,0,strpos($bodyTag,$omatch[0])) .
				    $omatch[0] . 'init_vars();self.focus();' .substr($bodyTag,$insertPos) . "\n";
			} else {
				// for now we assume that there may be a javascript-defined onload
				// handler.  We already have code in our new header section to daisy-chain
				// onto any existing handler
				//$bodyTag = substr($bodyTag,0,-1) . " onload='init_vars();self.focus();'>\n";
			}
			echo $bodyTag . $htmlSoFar;
			//ok, insertions done, continue on...
		}
	}
}


?>	
<br />
<?php echo TableHeaderTop(); ?>
<table border="0" width="90%">
	<tr>
		<td align="left">&nbsp;</td>
		<td align="right">
<form id="form1" name="Form" method="post">

<script language="JavaScript" type="text/javascript">
<!--
if(browser.isIE4up){
	document.write(
	'<select name="item1" id="item1" onChange="textfield.value=this.value;" class="galSelect">\
	<option value="24" selected >- Transition Effect -</option>\
	<option value="0">Box in</option>\
	<option value="1">Box out</option>\
	<option value="2">Circle in</option>\
	<option value="3">Circle out</option>\
	<option value="4">Wipe up</option>\
	<option value="5">Wipe down</option>\
	<option value="6">Wipe right</option>\
	<option value="7">Wipe left</option>\
	<option value="8">Vertical blinds</option>\
	<option value="9">Horizontal blinds</option>\
	<option value="10">Checkerboard across</option>\
	<option value="11">Checkerboard down</option>\
	<option value="12">Random dissolve</option>\
	<option value="13">Split vertical in</option>\
	<option value="14">Split vertical out</option>\
	<option value="15">Split horizontal in</option>\
	<option value="16">Split horizontal out</option>\
	<option value="17">Stripes left down</option>\
	<option value="18">Stripes left up</option>\
	<option value="19">Stripes right down</option>\
	<option value="20">Stripes right up</option>\
	<option value="21">Random bars horizontal</option>\
	<option value="22">Random bars vertical</option>\
	<option value="23">Random</option>\n');

	if(browser.isIE55up)
		document.write('<option value="25">Fade</option>\n');
	document.write('</select>\n');
	}
//-->
</script>

</select>
<select name="item4" id="item4" onChange="timer.value=this.value;" class="galSelect">
	<option value="">- Choose speed -</option>
	<option value="1000">1 sec</option>
	<option value="2000">2 secs</option>
	<option value="3000">3 secs</option>
	<option value="4000">4 secs</option>
	<option value="5000">5 secs</option>
	<option value="6000">6 sec</option>
	<option value="7000">7 secs</option>
	<option value="8000">8 secs</option>
	<option value="9000">9 secs</option>
	<option value="10000">10 secs</option>
</select>
</form>
[<a name="Start" id="Start" href="javascript:onClick=doTimer();">Start</a>]&nbsp;&nbsp;&nbsp;
[<a name="Stop" id="Stop" href="javascript:onClick=clearTimeout(timeout);location='index.php?option=com_rsgallery&page=inline&catid=<?php echo $catid; ?>&id=';">Stop</a>]

</td>
</tr>
</table>

<?php echo TableHeaderBottom(); ?>
<br /><br />

<?php echo TableHeaderTop(); ?>

<table border="0" cellpadding="5" cellspacing="0" width="<?php echo $PicWidth+10; ?>">
	<tr>
		<!-- PDW 3-8-2004 align=center toegevoegd -->
		<td align="center">
				<div id="pic0" style="position:relative;width:<?php echo $PicWidth; ?>px;overflow:hidden">
				<!-- PDW 3-8-2004 position van image aangepast naar relative -->
				<img src="<?php echo $mosConfig_live_site; ?>/components/com_rsgallery/images/slideshow.gif" align="center" name="PictureBox" id="PictureBox" style="position:relative;width:<?php echo $PicWidth; ?>" />
		</div>
		</td>
	</tr>
	<tr>
		<td id="CaptionBox" class="Caption" style="text-align:center;">
			<form id="caption" name="caption">
				<textarea id="captionText" cols="100%" style="visibility:hidden">&nbsp;</textarea>
			</form>
		</td>
	</tr>
</table>

<?php echo TableHeaderBottom();?>


