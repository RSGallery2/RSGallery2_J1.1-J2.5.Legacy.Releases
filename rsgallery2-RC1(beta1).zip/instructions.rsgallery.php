<head>
	<title></title>
	<link href="templates/mt_business/css/template_css.css" rel="stylesheet" type="text/css" />
</head>
<body>
<h1>RSGallery2 preview1</h1>
<p>Thank you for installing RSGallery2. You found yourself a full featured Gallery component for Mambo Open Source.</p>
<p>To start using this, please follow these very simple steps:</p>
<ol type="1">
	<li>Goto Components->RSGallery->Settings. Select the tab Admin Settings. Here you need to set the type of thumbnail generator you want to use. All types supported marked in green. Select the proper generator.</li>
	<li>Choose the width of the thumbnails generated. Usually a value between 100 and 150 is sufficient</li>
	<li>Thumbnail quality is preset at 85%. This is OK for most systems. Change this if you really want.</li>
	<li>Choose is you want the full picture to appear inline or in a popup window. Note that in a popup window, there is no slideshow possibility yet.</li>
	<li>Next, goto Components->RSGallery->View categories. Create a category. No need to publish, the cateogry will publish automatically.</li>
	<li>Now you can start uploading images. THe quickest way is to create a ZIP-file with all images in it and choose Components->RSGallery->Upload ZIP-file. Select the right category and click Next.</li>
	<li>Next screen is the overview screen. Enter titles and click Upload. (when you don't enter titles, the filename will be stored as title)</li>

</ol>
</body>
