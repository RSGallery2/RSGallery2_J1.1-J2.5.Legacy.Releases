<?php
/**
* This file handles configuration processing for RSGallery.
*
* @version $ 2.0 RC-1 $
* @package RSGallery_2.0
* @copyright (C) 2003 - 2004 RSDevelopment
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* RSGallery is Free Software
**/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

include_once($mosConfig_absolute_path.'/administrator/components/com_rsgallery/mimetype.php');

/**
* Create a thumbnail using ImageMagick library
* @param string Complete path to sourcefile
* @param string Complete path to targetfile
* @param int Size of thumbnails in pixels
*/
function CreateThumbIM($in, $out, $size)
	{
	global $IM_path;

	if ( $IM_path )
		{
		$cmd = $IM_path."convert -resize $size $in $out";
		@exec($cmd);
		}
	}

/**
* Create a thumbnail using NETPBM library
* @param string Complete path to sourcefile
* @param string Complete path to targetfile
* @param int Max size of thumbnails in pixels
* @param string Original filename
* @param string Image quality of thumbnail in percentages
*/
function CreateThumbNETPBM($file,$desfile,$maxsize,$origname,$quality)
	{
	global $NETPBM_path;

	if($NETPBM_path)
		{
		if(!is_dir($NETPBM_path))
			{
			echo "NetPbm path not correct";
			die;
			}
		}
		if (eregi("\.png", $origname))
			{
			$cmd = $NETPBM_path . "pngtopnm $file | " . $NETPBM_path . "pnmscale -xysize $maxsize $maxsize | " . $NETPBM_path . "pnmtopng > $desfile" ;
			}
		else if (eregi("\.(jpg|jpeg)", $origname))
			{
			$cmd = $NETPBM_path . "jpegtopnm $file | " . $NETPBM_path . "pnmscale -xysize $maxsize $maxsize | " . $NETPBM_path . "ppmtojpeg -quality=$quality > $desfile" ;
			}
		else if (eregi("\.gif", $origname))
			{ 
			$cmd = $NETPBM_path . "giftopnm $file | " . $NETPBM_path . "pnmscale -xysize $maxsize $maxsize | " . $NETPBM_path . "ppmquant 256 | " . $NETPBM_path . "ppmtogif > $desfile" ; 
			}//end if.. 
	@exec($cmd);
	}
####################################
#       Function checkAdmin        #
#----------------------------------#
#       Created Arthur Konze       #
#    http://www.mamboportal.com    #
#----------------------------------#
# Checks whether logged in user is #
# admin or not!					   #
####################################

function checkAdmin($database, $db, $dbprefix, $cook, $admin)
	{
  	global $CurrUID;
  	/* Get the visitor's UserType */
  	$utype = "";
  	if ($cook<>"")
		{
    	$cryptSessionID=md5($cook);
    	$queryg = "SELECT usertype, userid FROM #__session WHERE session_ID='$cryptSessionID'";
    	$resultg = $database->openConnectionWithReturn($queryg);
    	while ($rowg = mysql_fetch_object($resultg))
			{
      		$utype = $rowg->usertype;
      		$CurrUID = $rowg->userid;
    		}
	    if ($admin) 
			{
	      	if ($utype=="administrator" or $utype=="superadministrator")
				{
	        	return true;
	      		}
			else
				{
	        	return false;
	      		}
	     	} 
		else 
			{
	      	if ($utype=="user" or $utype=="editor")
				{
	        	return true;
	      		}
			else 
				{
	        	return false;
	      		}
			}
		}
	}

/**
* Create a thumbnail using GD library
* @param string extension of filename
* @param string Complete path to sourcefile
* @param string Complete path to destinationfile
* @param string Image quality of thumbnail in percentages
* @param integer Max size of thumbnails in pixels
* @param string method og GD, e.g. GD1 or GD1(Defaults to GD2)
* @return integer Appears to return 1 if file not found, 2 on success, 3 on bad file type.
*/
function CreateThumbGD2($ext, $img_source, $img_dest, $img_quality, $size_limit, $imagemethod = 'gd2')
{
//debugbreak();
//$imagemethod = 'gd2';

if (!file_exists($img_source))
	{
	return(1); //file not found return 1
	}
$ext = strtolower($ext);
 //load the original image and put its height/width in $img_info
 $img_info = GetImageSize($img_source);

 //$img_info ARRAY KEY
 //0 = width
 //1 = height
 //2 = image type
 //3 = hight and width string
 $orig_height	= $img_info[1]; //source height from $img_info
 $orig_width 	= $img_info[0]; //source width from $img_info
 $type 			= $img_info[2];

$newheight 		= $size_limit;
$newwidth 		= $size_limit;

// debugbreak();
switch ($ext)
	{
	case "jpg":
		$im = ImageCreateFromJPEG($img_source);
		break;
	case "jpeg":
		$im = ImageCreateFromJPEG($img_source);
		break;
	case "png":
		$im = ImageCreateFromPNG($img_source);
		break;
	case "gif":
		if ($imagemethod == 'gd1')
			{
			$im = ImageCreateFromGIF($img_source);
			break;
			}
		else
			{
			return(1);
			}
	}

	if ($newheight && ($orig_width < $orig_height))
		{
		$newwidth = ($newheight / $orig_height) * $orig_width;
		}
	else
		{
		$newheight = ($newwidth / $orig_width) * $orig_height;
		}
	if ($imagemethod == "gd2")
		{
		$im2 = ImageCreateTrueColor($newwidth,$newheight);
		ImageCopyResampled($im2,$im,0,0,0,0,$newwidth,$newheight,$orig_width,$orig_height);
		}
	else
		{
		$im2 = ImageCreate($newwidth,$newheight);
		ImageCopyResized($im2,$im,0,0,0,0,$newwidth,$newheight,$orig_width,$orig_height);
		}

switch ($ext)
	{
	case "jpg":
		ImageJpeg($im2, $img_dest, $img_quality);
		return(2);

	case "png":
		ImagePNG($im2, $img_dest);
		return(2);

	case "gif":
		if ($imagemethod == 'gd1')
			{
			ImageGif($im2, $img_dest);
			return(2);
			}
		else
			{
			return(1);
			}

	default:
		// Nothing special.
	}

return(3);
}

/* RJF - 16 Nov 2004
 * It appears that getThumb is called from some places where only the first 
 * parameter (catid) is supplied. As a temporary measure, the height, width, and
 * class information now have defaults.
 */

function getThumb($catid, $height = 0, $width = 0,$class = "")
	{
	global $database,$imagepath,$mosConfig_live_site;
	$imgatt="";
	if ($height>0)
		$imgatt.=" height=\"$height\" ";
	if ($width>0)
		$imgatt.=" width=\"$width\" ";
	if ($class> "")
		$imgatt.=" class=\"$class\" ";
	else
		$imgatt.=" class=\"RSgalthumb\" ";
	$database->setQuery("SELECT * FROM #__rsgallery as a, #__rsgalleryfiles as b WHERE a.id = b.gallery_id AND b.gallery_id = '$catid'");
	$rows = $database->loadObjectList();
	if (!$rows)
		{
		$t_path = "<img $imgatt src=\"".$mosConfig_live_site."/components/com_rsgallery/images/no_pics.gif\" alt=\"No pictures in gallery\" border=\"0\" />";
		}
	else
		{
		foreach ($rows as $row)
			{
			$t_path = "<img $imgatt src=\"".$mosConfig_live_site.$imagepath."thumbs/".$row->name."\" alt=\"\" border=\"0\" />";
			}
		}
	return $t_path;
	}

function getNumber($id)
	{
	global $database;
	$database->setQuery("SELECT count(*) FROM #__rsgalleryfiles WHERE gallery_id = '$id'");
	$count = $database->loadResult();
	return $count;
	}

function getCurrentDate()
	{
	$now = getdate(); 
	$datetime = $now['year']."-".$now['mon']."-".$now['mday']." ".$now['hours'].":".$now['minutes'].":".$now['seconds']; 
	echo $datetime;
	}

function getCatname($id)
	{
	global $database;
	$database->setQuery("SELECT catname FROM #__rsgallery WHERE id = '$id'");
	$catname = $database->loadResult();
	echo $catname;
	}

function showUserCatSelect($user_id,$p_catid)
	{
	global $database,$my;
	$my_id = $my->id;

	//PDW 1-8-2004
	//Changed so administrators can upload to the site galleries
	//Todo i dont like checking on userid=62
	//That could be better
	if ($my_id == '62')
		$database->setQuery("SELECT * FROM #__rsgallery ORDER BY ordering ASC");
	else
		$database->setQuery("SELECT * FROM #__rsgallery WHERE uid = '$user_id' AND parent='0' AND user='1' ORDER BY ordering ASC");

	$rows = $database->loadObjectList();
	if (isset($p_catid))
		echo "<option value=\"xx\" >- Select category -</option>";
	else
		echo "<option value=\"xx\" SELECTED>- Select category -</option>";
	foreach ($rows as $row)
		{
		if ($row->parent_id == 0)
			{
			echo "<option value=\"$row->id\" ";
			if ($row->id==$p_catid)
				{
				echo "selected";
				}	
			echo "><b>---$row->catname</b></option>";
			}
		else
			{
			echo "<option value=\"$row->id\">$row->catname</option>";
			}
		}
	}

/**
 * Generates the HTML to populate the "categories" drop-down.
 * 
 * @param integer The ID of the currently selected category [Optional]
 */
function showCategories2($s_id = 0)
	{
	global $database, $rows, $rows2;
	$database->setQuery("SELECT * FROM #__rsgallery WHERE parent = '0' ORDER BY ordering ASC");
	$rows = $database->loadObjectList();
	echo "<option value=\"xx\" SELECTED>- Select category -</option>\n";
	foreach ($rows as $row)
		{
		$id = $row->id;
		$database->setQuery("SELECT * FROM #__rsgallery WHERE parent = '$id' ORDER BY ordering ASC");
		$rows2 = $database->loadObjectList();

		//PDW 20-7-2004
		//Added check to see if s_id is filled. If not then make 0	
		if (!isset($s_id))
			{
			$s_id=0;
			}
		?>
		<option value="<?php echo $row->id;?>" <?php if ($row->id == $s_id) echo "SELECTED";?>><?php echo $row->catname;?></option>
		<?php
		foreach($rows2 as $row2)
			{
			?>
			<option value="<?php echo $row2->id;?>">--><?php echo $row2->catname;?></option>
			<?php
			}
		}
	}

function getFileName($id)
	{
	global $database;
	$database->setQuery("SELECT name FROM #__rsgalleryfiles WHERE id = '$id'");
	$filename = $database->loadResult();
	return $filename;
	}

function regenerateAllThumbs($catid = NULL)
	{
    // re-do all thumbnail pics for selected category(s) or all pics in directory
    global $database, $mosConfig_absolute_path, $imagepath, $conversiontype, $size, $JPEGquality,$IM_path;

    // dmcd to do:

	// 1. put back in GD1 thumbnail call
	// 2. check for database query error
	// 3. if there are a lot of pics, this can take a while, so may need to
	//    reset php max execution timeout so it does not terminate prematurely

    // if manual thumb creation has been chosen, then no resizing will occur
    if($conversiontype == 0) return;

    // $catid == 0  all categories
	// $catid == NULL all pic files found in gallery subdirectory
	// $catid == 1..  all pic files for that particular category

	if(isset($catid) && $catid == 0)
		$database->setQuery("SELECT name FROM #__rsgalleryfiles");
	elseif($catid != NULL)
		$database->setQuery("SELECT name FROM #__rsgalleryfiles WHERE gallery_id='$catid'");

	if($catid != NULL){
		$files = loadObjectList('name');

	// if there is no thumbs subdirectory, then no thumbs can be generated
        if(!(file_exists($mosConfig_absolute_path.$imagepath."thumbs"))) return;
        $pics = mosReadDirectory($mosConfig_absolute_path.$imagepath);
        $maxsize    = $size;
        $quality    = $JPEGquality;
        foreach($pics as $pic)
			{
            // check to see if we want to do this pic
            // No need to check catid again, since it must be non-null for us to get here!
			if(!array_key_exists($files, $pic)) continue;

            // go regenerate the thumbs
            $file_in = $mosConfig_absolute_path.$imagepath.$pic;
            $file_out = $mosConfig_absolute_path.$imagepath."thumbs/".$pic;
            if(is_dir($file_in)) continue;
            // delete the existing thumb if present
            if(file_exists($file_out)) unlink($file_out);
            switch ($conversiontype)
				{
				//ImageMagick
				case 1:
					$cmd = $IM_path."convert -resize $size $file_in $file_out";
					@exec($cmd);
					break;
				//NETPBM
				case 2:
					CreateThumbNETPBM($file_in,$file_out,$maxsize,$pic,$quality);
					break;
				//GD1
				case 3:
					CreateThumbGD2($file_in, $file_out, $quality, $maxsize, 'gd1');
					break;
				//GD2
				case 4:
					CreateThumbGD2($file_in, $file_out, $quality, $maxsize);
					break;
				}
			}
		}
	}

function getGalleryId($id)
	{
	global $database;
	$database->setQuery("SELECT gallery_id FROM #__rsgalleryfiles WHERE id = '$id'");
	$gallery_id = $database->loadResult();
	return $gallery_id;
	}

function addHit($id)
	{
	global $database;
	//Get hits from DB
	$database->setQuery("SELECT hits FROM #__rsgalleryfiles WHERE id = '$id'");
	$hits = $database->loadResult();
	$hits++;
	$database->setQuery("UPDATE #__rsgalleryfiles SET hits = '$hits' WHERE id = '$id'");
	if ($database->query())
		{
		return(1);//OK
		}
	else
		{
		return(0);//Not OK
		}
	}

function addCatHit($hid)
	{
	global $database;
	//Get hits from DB
	$database->setQuery("SELECT hits FROM #__rsgallery WHERE id = '$hid'");
	$hits = $database->loadResult();
	$hits++;
	$database->setQuery("UPDATE #__rsgallery SET hits = '$hits' WHERE id = '$hid'");
	if ($database->query())
		{
		return(1);//OK
		}
	else
		{
		return(0);//Not OK
		}
	}

function showRating($id)
	{
	global $database,$mosConfig_live_site;
	$database->setQuery("SELECT * FROM #__rsgalleryfiles WHERE id = '$id'");
	$values = array("No rating","Very bad","Bad","OK","Good","Very good");
	$rows = $database->loadObjectList();
	$images = "";
	foreach ($rows as $row)
		{
		$average = $row->rating/$row->votes;
		$average1 = round($average);
		for ($t = 1; $t <= $average1; $t++)
			{
			$images .= "<img src=\"$mosConfig_live_site/images/M_images/rating_star.png\">&nbsp;";
			}
		}
		return $images;
		//return $values[$average1]." (".$average.")";
	}

function showEXIF($imagefile)
	{
	//echo "EXIF information for <strong>$imagefile</strong> will be shown here";
	if(!function_exists('exif_read_data'))
		{
		echo "PHP not compiled with EXIF-support!";
		}
	else
		{
		$exif = exif_read_data($imagefile, 0, true);
		?>
		<table width="100%" border="0" cellspacing="1" cellpadding="0">
		<tr bgcolor="#483D8B">
			<td><strong><font color="#FFFFFF">&nbsp;Section</font></strong></td>
			<td><strong><font color="#FFFFFF">&nbsp;Name</font></strong></td>
			<td><strong><font color="#FFFFFF">&nbsp;Value</font></strong></td>
		</tr>
		<?php
		foreach ($exif as $key => $section)
			{
			foreach ($section as $name => $val)
				{
				?>
				<tr>
					<td><?php echo $key;?></td>
					<td><strong><?php echo $name;?></strong></td>
					<td><em><?php echo $val;?></em></td>
				</tr>
				<?php
				}
			}
			?>
			</table>
			<?php
		}
	}

function showRandom()
	{
	//PDW 17-7-2004
	//Rewritten the function. Is a little more simple now.
	global $database,$imagepath,$mosConfig_live_site;
	$database->setQuery("SELECT file.gallery_id, file.ordering, file.id, file.name, file.descr FROM #__rsgalleryfiles file, #__rsgallery gal WHERE file.gallery_id=gal.id and gal.published=1 order by rand() limit 3");

	$rows = $database->loadObjectList();
	//TODO
	//Too lazy to rewrite $image_tag
	$thumbs = "thumbs";
	$image_tag = "";


	//This row shows the random pictures.
	?>
	<br/>
	<table class="RSTbl" cellspacing="0" cellpadding="0">
	<tr>
		<td class="RSlefttop" ><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
		<td class="RStopline" colspan="3"></td>
		<td class="RSrighttop" ><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
	</tr>
	<tr>
		<td class="RSleftline"></td>
		<td colspan="3" class="sectiontableheader"><?php echo _RSGALLERY_RANDOM_TITLE;?></td>
		<td class="RSrightline"></td>
	</tr>
	<tr>
		<td class="RSleftline"></td>
		<td colspan="3">&nbsp;</td>
		<td class="RSrightline"></td>
	</tr>
	<tr>
		<td class="RSleftline"></td>
		<?php
		foreach($rows as $row)
			{
			$l_start = $row->ordering - 1;
			$image_tag .= "<td align=\"center\"><a href=\"$mosConfig_live_site/index.php?option=com_rsgallery&amp;page=inline&amp;id=$row->id&amp;catid=$row->gallery_id&amp;limitstart=$l_start\"><img src=\"$mosConfig_live_site$imagepath$thumbs/$row->name\" alt=\"$row->descr\" border=\"0\" width=\"100\" /></a></td>\n";
			}
			echo $image_tag;
		?>
		<td class="RSrightline"></td>
	</tr>
	<tr>
		<td class="RSleftbottom"></td>
		<td class="RSbottomline" colspan="3"></td>
		<td class="RSrightbottom"></td>
	</tr>
	</table>
	<?php
	}

function showLatest()
	{
	//PDW 17-7-2004
	//Rewritten the function. Is a little more simple now.
	global $database,$imagepath,$mosConfig_live_site;
	$database->setQuery("SELECT file.gallery_id, file.ordering, file.id, file.name, file.descr FROM #__rsgalleryfiles file, #__rsgallery gal WHERE file.gallery_id=gal.id and gal.published=1 order by date desc limit 3");

	$rows = $database->loadObjectList();
	//TODO
	//Too lazy to rewrite $image_tag
	$thumbs = "thumbs";
	$image_tag = "";


	//This row shows the latest pictures.
	?>
	<br/>
	<table class="RSTbl" cellspacing="0" cellpadding="0">
	<tr>
		<td class="RSlefttop" ><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
		<td class="RStopline" colspan="3"></td>
		<td class="RSrighttop" ><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
	</tr>
	<tr>
		<td class="RSleftline"></td>
		<td colspan="3" class="sectiontableheader"><?php echo _RSGALLERY_LATEST_TITLE;?></td>
		<td class="RSrightline"></td>
	</tr>
	<tr>
		<td class="RSleftline"></td>
		<td colspan="3">&nbsp;</td>
		<td class="RSrightline"></td>
	</tr>
	<tr>
		<td class="RSleftline"></td>
		<?php
		foreach($rows as $row)
			{
			$l_start = $row->ordering - 1;
			$image_tag .= "<td align=\"center\"><a href=\"$mosConfig_live_site/index.php?option=com_rsgallery&amp;page=inline&amp;id=$row->id&amp;catid=$row->gallery_id&amp;limitstart=$l_start\"><img src=\"$mosConfig_live_site$imagepath$thumbs/$row->name\" alt=\"$row->descr\" border=\"0\" width=\"100\" /></a></td>\n";
			}
		echo $image_tag;
		?>
		<td class="RSrightline"></td>
	</tr>
	<tr>
		<td class="RSleftbottom"></td>
		<td class="RSbottomline" colspan="3"></td>
		<td class="RSrightbottom"></td>
	</tr>
	</table>
	<?php
	}


function TableHeaderTop()
	{
	global $mosConfig_live_site;
	?>
	<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
		<td width="10" height="10"><img src="<?php echo $mosConfig_live_site;?>/components/com_rsgallery/images/top_left_corner.gif" width="10" height="10" alt="" /></td>
		<td background="<?php echo $mosConfig_live_site;?>/components/com_rsgallery/images/top_line.gif"></td>
		<td width="10" height="10"><img src="<?php echo $mosConfig_live_site;?>/components/com_rsgallery/images/top_right_corner.gif" width="10" height="10" alt="" /></td>
	</tr>
    <tr>
		<td background="<?php echo $mosConfig_live_site;?>/components/com_rsgallery/images/left_line.gif"></td>
		<td align="center">
	<?php
	}

function TableHeaderBottom()
	{
	global $mosConfig_live_site;
	?>
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/components/com_rsgallery/images/right_line.gif"></td>
    </tr>
    <tr>
		<td width="10" height="10" background="<?php echo $mosConfig_live_site;?>/components/com_rsgallery/images/bottom_left_corner.gif"></td>
		<td background="<?php echo $mosConfig_live_site;?>/components/com_rsgallery/images/bottom_line.gif"></td>
		<td width="10" height="10" background="<?php echo $mosConfig_live_site;?>/components/com_rsgallery/images/bottom_right_corner.gif"></td>
    </tr>
  </table>
	<?php
	}

function SpaceToUnderscore($text)
	{
	$text = str_replace(" ", "_",$text);
	$text = explode(".", $text);
	$text[0] = substr($text[0], 0, 25);
	$text = implode(".",$text);
	return $text;
	}

function getPerm($path)
	{
	global $mosConfig_absolute_path;
	$decperms = fileperms($path);
	$octalperms = sprintf("%o",$decperms);
	$perms=(substr($octalperms,1));
	if ($perms !== "0777")
		{
		echo "<font color=\"#FF0000\"><strong>Not writable</strong></font>. Please CHMOD <strong>$mosConfig_absolute_path/uploadfiles</strong> to 0777";
		}
	else
		{
		echo "<strong><font color=\"#008000\">Writable</font></strong>";
		}
	}

//*************************
// Need to rewrite this.
// This does not make sense
//**************************
function checkLogin($my_id)
	{
	global $mosConfig_absolute_path, $acl;
	//Check the login type
	$aro_group = $acl->getAroGroup( $my_id );

        if ( $aro_group == NULL )
        {
           // There is no logged in user!
           return 0;
        }

	$group = $aro_group->name;
	$group_id = $aro_group->group_id;
	switch ($group)
		{
		case "Super Administrator":
			return 1;//Super Administrator
			break;
		case "Administrator":
			return 2;//Administrator
			break;
		case "Editor":
			return 3;//Editor
			break;
		case "Registered":
			return 4;
		default:
			return 0;//Geen geldige status
			break;
		}
	}


function getParentCat($id)
	{
	global $database;
	$database->setQuery("SELECT parent FROM #__rsgallery WHERE id = '$id'");
	$p_id = $database->loadResult();
	if ($p_id == 0)
		{
		return 0;
		}
	else
		{
		$database->setQuery("SELECT catname FROM #__rsgallery WHERE id = '$p_id'");
		$catname = $database->loadResult();
		return $catname."/";
		}
	}

function showSubcats($c_id)
	{
	global $database, $mosConfig_live_site;
	//PDW 17-6-2004
	//Added published=1 to show only published categories
	$database->setQuery("SELECT * FROM #__rsgallery WHERE parent = '$c_id' and published=1");
	$rows = $database->loadObjectList();


	$i = 0;
	if ($rows)
		{
		?>
		<table class="RSTbl" cellspacing=0 cellpadding=0>

		<tr>
			<td class="RSlefttop" ><img src='components/com_rsgallery/images/spacer.gif' class="RSCornerSpacer"></td>
			<td class="RStopline" colspan="2" ></td>
			<td class="RSrighttop" ><img src='components/com_rsgallery/images/spacer.gif' class="RSCornerSpacer"></td>
		</tr>
			<tr>
				<td class="RSleftline" ></td>
				<td class="RSGalDesc" colspan="2"><?php echo _RSGALLERY_SUBCAT; ?></td>
				<td class="RSrightline"></td>
			</tr>
		<tr>
			<td class="RSleftline" ></td>
			<td class="RSGalDesc" colspan="2">

		<?php
		foreach($rows as $row)
			{
			?>
			<tr>
				<td class="RSleftline" ></td>
				<td class="RSGalDesc" colspan="2">
				<A href="index.php?option=com_rsgallery&amp;catid=<?php echo $row->id;?>"><img src="<?php echo $mosConfig_live_site?>/components/com_rsgallery/images/folder.gif" border="0">&nbsp;&nbsp;&nbsp;<?php echo $row->catname."&nbsp;&nbsp;(".getNumber($row->id)."&nbsp;pics)";?></a>
				<td class="RSrightline"></td>
			</tr>
			<?php
			$i++;
			}
		?>
		<tr>
			<td class="RSleftbottom" ><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
			<td class="RSbottomline" colspan="2"></td>
			<td class="RSrightbottom" ><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
		</tr>
		</table>
		<?php

		}
	echo "<br />";
	}

function showRSPath($id)
	{
	global $database,$mosConfig_live_site;
	$database->setQuery("SELECT * FROM #__rsgallery WHERE id = '$id'");
	$rows = $database->loadObjectList();
	foreach($rows as $row)
		{
		if ($row->parent == 0)
			{
			?>
			<a href="index.php?option=com_rsgallery">RSGallery</a>&nbsp;<img src="<?php echo $mosConfig_live_site?>/images/M_images/arrow.png" alt="" border="0" />&nbsp;<?php getCatname($row->id);?>
			<?php
			}
		else
			{
			?>
			<a href="index.php?option=com_rsgallery">RSGallery</a>&nbsp;<img src="<?php echo $mosConfig_live_site?>/images/M_images/arrow.png" alt="" border="0" />&nbsp;<a href="index.php?option=com_rsgallery&amp;catid=<?php echo $row->parent;?>"><?php echo getCatname($row->parent);?></a>&nbsp;<img src="<?php echo $mosConfig_live_site?>/images/M_images/arrow.png" alt="" border="0" />&nbsp;<?php getCatname($row->id);?>
			<?php
			}
		}
	}

function checkParent($id)
	{
	global $database;
	$database->setQuery("SELECT parent FROM #__rsgallery WHERE id = '$id'");
	$p_id = $database->loadResult();
	if ($p_id == 0)
		{
		return 0;
		}
	else
		{
		return 1;
		}
	}

function newImages($xid)
	{
	global $database;
	$lastweek  = mktime (0, 0, 0, date("m"),    date("d") - 7, date("Y"));
	$lastweek = date("Y-m-d H:m:s",$lastweek);
	$database->setQuery("SELECT * FROM #__rsgalleryfiles WHERE date >= '$lastweek' AND gallery_id = '$xid'");
	$rows = $database->loadObjectList();
	if (count($rows) > 0)
		{
		foreach ($rows as $row)
			{
			$gallery_id = $row->gallery_id;
			if ($gallery_id == $xid)
				{
				echo "<font class=\"newpics\">NEW</font>";
				break;
				}
			}
		}
	else
		{
		echo "";
		}
	}
function showUserCategories2($uid)
	{
	global $database, $my, $acl, $mosConfig_live_site;
	/*
	ARO-GROUPS
	ROOT (17)
		|-USERS (28)
			|-Public Frontend (29)
			|	|-Registered (18)
			|		|-Author (19)
			|			|-Editor (20)
			|				|-Publisher (21)
			|-Public Backend (30)
				|-Manager (23)
					|-Administrator (24)
						|-Super Administrator (25)
	*/
	//Check level van ingelogde user
	if ($uid)
		{
		$my_id = $my->id;
		$database->setQuery("SELECT gid FROM #__users WHERE id = $my_id");
		$gid = $database->loadResult();
		if ($gid == 25)//ID for Super Administrator
			{
			//You are superadministrator, show all!!!!
			$database->setQuery("SELECT * FROM #__rsgallery WHERE uid = '0'");
			$rows = $database->loadObjectList();
			if ($rows)
				{
				?>
				<table cellspacing=0 cellpadding=0 >
				<tr>
					<td class="RSGalTitle" colspan="5">	
						<a href="javascript:invi(0)">
						<img src="<?php echo $mosConfig_live_site;?>/components/com_rsgallery/images/minus.gif" alt="" border="0" />
						</a>
						<?php echo _RSGALLERY_USERGAL_HEADER;?>
					</td>
				</tr>
				<tr>
					<td class="RSGalTitle" colspan="5"><?php echo userMenu();?></td>
				</tr>
				<?php
				foreach ($rows as $row)
					{
					?>
					<tr >
						<td class="RSGalTitle" width="85"></TD>
						<td class="RSBetweenCells" ></td>
						<td class="RSGalTitle"><a href="index.php?option=com_rsgallery&amp;catid=<?php echo $row->id;?>">
							<?php echo htmlspecialchars(stripslashes($row->catname), ENT_QUOTES); ?></a><?php echo newImages($row->id);?>
						</td>
						<td class="RSBetweenCells"></td>
						<td class="RSGalTitle" width="50"><?php echo getNumber($row->id);?></td>

					</tr>
					<tr>
						<td class="RSBetweenCells" colspan="5"></td>
					</tr>
					<tr >
						<td class="RSGalDesc" width="75" ><center><a href="index.php?option=com_rsgallery&amp;catid=<?php echo $row->id;?>"><?php echo getThumb($row->id);?></a></center></td>
						<td class="RSBetweenCells"></td>
						<td class="RSGalDesc"> <?php echo htmlspecialchars(stripslashes($row->description), ENT_QUOTES); ?>
						<br/><br/><em><?php echo _RSGALLERY_CREATED_BY;?><strong><?php echo getUserDetails($row->uid);?></strong></em></td>
						<td class="RSBetweenCells"></td>
						<td class="RSGalDesc">&nbsp;</td>
					</tr>
					<tr>
						<td class="RSBetweenCells" colspan="5"></td>
					</tr>
					<?php
					}
				}
			}
		else
			{
			//You are registered, show all categories with user = 1 or 2 and your own categories, marked 0
			//SELECT * FROM #__rsgallery WHERE $published == '1' AND (user == 1 OR user == 2) 
			//SELECT * FROM #__rsgallery WHERE (uid = $my_id AND $user == '0')
			}
		}
	else
		{
		//You are not logged in
		echo "Log in to see your user categories";
		}
	}

function showUserCategories($uid)
	{
	global $database, $my,$mosConfig_live_site;

	if ($uid)
		{
		$xy = checkLogin($uid);
		//This returns:
		//1 for super administrator
		//2 for administrator
		//3 for editor
		//4 for registered
		//0 for quest

		//uid<>0 returns only user galleries
		if ($xy == 1)
			{
			//We are super administrator, show all usergalleries
			$database->setQuery("SELECT * FROM #__rsgallery WHERE published = '1' and uid <> 0");
			$rows = $database->loadObjectList();
			}
		elseif (($xy == 2) or ($xy == 3) or ($xy ==4))
			{
			//If user is registered, editor or administrator
			//user=1 shows all the galleries for registered users
			//user=2 shows all the galleries for all visitors
			$database->setQuery("SELECT * FROM #__rsgallery WHERE uid<>0 and (uid = '$uid' OR ((user=1 or user=2) AND published = '1'))");
			$rows = $database->loadObjectList();
			}
		else
			{
			//user is a ananymous visitor
			//user=2 shows all the galleries for all visitors
			$database->setQuery("SELECT * FROM #__rsgallery WHERE uid<>0 and (user = '2' AND published = '1')");
			$rows = $database->loadObjectList();
			}

		if ($rows)
			{
			?>
			<table cellspacing=0 cellpadding=0 width=100% border=0>
			<tr>
					<td class="sectiontableheader" colspan="5">	
					<a href="javascript:invi(0)">
					<img src="<?php echo $mosConfig_live_site;?>/components/com_rsgallery/images/minus.gif" alt="" border="0" />
					</a>
					<?php echo _RSGALLERY_USERGAL_HEADER;?>
					</td>
			</tr>
			<tr>
					<td class="RSGalTitle2" colspan="5" align="right"><?php echo userMenu();?></td>
			</tr>
			<?php
			foreach ($rows as $row)
				{
				?>
				<tr >
					<td class="RSGalTitle" width="85"></TD>
					<td class="RSBetweenCells" ></td>
					<td class="RSGalTitle"><a href="index.php?option=com_rsgallery&amp;catid=<?php echo $row->id;?>">
						<?php echo htmlspecialchars(stripslashes($row->catname), ENT_QUOTES); ?></a><?php echo newImages($row->id);?>
					</td>
					<td class="RSBetweenCells"></td>
					<td class="RSGalTitle" width="50"><?php echo getNumber($row->id);?></td>

				</tr>
				<tr>
					<td class="RSBetweenCells" colspan="5"></td>
				</tr>
				<tr >
					<td class="RSGalDesc" width="85" ><center><a href="index.php?option=com_rsgallery&amp;catid=<?php echo $row->id;?>"><?php echo getThumb($row->id);?></a></center></td>
					<td class="RSBetweenCells"></td>
					<td class="RSGalDesc"> <?php echo htmlspecialchars(stripslashes($row->description), ENT_QUOTES); ?>
					<br/><br/><em><?php echo _RSGALLERY_CREATED_BY;?><strong><?php echo getUserDetails($row->uid);?></strong></em></td>
					<td class="RSBetweenCells"></td>
					<td class="RSGalDesc">&nbsp;</td>
				</tr>
				<tr>
					<td class="RSGalTitle" colspan="5"></td>
				</tr>
				<?php
				}
			?>
			</table>
			<?php
			}
		else
			{
			?>
			<table width="100%">
				<tr>
					<td align="right"><?php echo UserMenu();?></td>
				</tr>
				<tr>
					<td>No categories for <strong><?php echo getUserDetails($uid);?></strong> available</td>
				</tr>
			</table>

			<?php
			}
		}
	else
		{
		echo "Log in to see your user categories";
		}
	}

function userMenu()
	{
	?>
	[<a href="index.php?option=com_rsgallery&amp;page=newusercat">Add category</a>]
	[<a href="index.php?option=com_rsgallery&amp;page=frontupload">Upload images</a>]
	[<a href="index.php?option=com_rsgallery&amp;page=usercatproperties">Properties</a>]
	<?php
	}

function getUserDetails($uid)
	{
	global $database;
	$database->setQuery("SELECT name FROM #__users WHERE id = '$uid'");
	$name = $database->loadResult();
	return $name;
	}

function getUID($catid)
	{
	global $database, $uid;
	$database->setQuery("SELECT uid FROM #__rsgallery WHERE id = '$catid'");
	$uid = $database->loadResult();
	return $uid;
	}

function checkUserCat($uid)
	{
	global $database;
	$database->setQuery("SELECT count(*) FROM #__rsgallery WHERE user='1' AND uid = '$uid'");
	$count = $database->LoadResult();
	return $count;
	}
function getUsername($uid)
	{
	global $database;
	$database->setQuery("SELECT username FROM #__users WHERE id = '$uid'");
	$name = $database->loadResult();
	return $name;
	}

function getAllowed($catid)
	{
	global $database, $catid;
	$database->setQuery("SELECT allowed FROM #__rsgallery WHERE id = '$catid'");
	//Create usable array to extract user ID-s.
	$allowed = unserialize($database->loadResult());
	//Generate listbox with usernames
	foreach ($allowed as $item)
		{
		echo "<option value=\"$item\">".getUserName($item)."</option>";
		}
	}

function getUsers()
	{
	global $database;
	$database->setQuery("SELECT * FROM #__users ORDER BY username ASC");
	$rows = $database->loadObjectList();

	foreach ($rows as $row)
		{
		echo "<option value=\"$row->id\">$row->username</option>";
		}
	}

/**
* Checks if user is registered or higher
* @param string User Id
* @return string No or Yes (0 or 1)
*/
function checkAccess($id)
	{
	global $acl;
	$aro_group 	= $acl->getAroGroup( $id );
	$group_id = $aro_group->group_id;
	//Get children from grouptype 'registered'
	$group_children = $acl->get_group_children(18, 'ARO', 'RECURSE');
	$is_child = $acl->is_group_child_of( $aro_group->name, 'Registered', 'ARO' );
	if ( is_array( $group_children ) && count( $group_children ) > 0)
		{
		//there are child groups. See if user is in any ot them
		if ($group_id == 18 || $is_child == 1)
			{
			//user is registered or above
			return 1;
			}
		else
			{
			return 0;
			}
		}
	}

// BEGIN: Troozers Modification

function resizePicture($type, $fname, $option, $maxwidth)
{
  $conversionFunction = array( 1=>'ResizePicIM', 2=>'ResizePicNETPBM', 3=>'ResizePicGD1', 4=>'ResizePicGD2' );
  $img_info = getimagesize($fname);
  $imgwidth = $img_info[0];
  $resize   = false;

  switch( $option )
  {
    case 4: // Resize up on upload
      if( $imgwidth < $maxwidth )
      {
        $resize = true;
      }
      break;
   case 5: // Resize down on upload
     if( $imgwidth > $maxwidth )
     {
       $resize = true;
     }
     break;
  case 6: // Resize up or down on upload
    if( $imgwidth != $maxwidth ) 
    {
      $resize = true;
    }
    break;
  }

  if( $resize )
  {
    $conversionFunction[$type]($fname, 100, $maxwidth);
  }
}


####################################
#      Function ResizePicIM        #
#----------------------------------#
#     Created by Andy Stewart      #
#        Modified from code        #
#         by Ronald Smit           #
#----------------------------------#
#      http://www.troozers.net     #
####################################
function ResizePicIM($img_source, $img_quality, $reqd_width)
{
   $cmd = $IM_path."convert -resize $reqd_width $img_source $img_source";
   @exec($cmd);
}


####################################
#     Function ResizePicNETPBM     #
#----------------------------------#
#     Created by Andy Stewart      #
#        Modified from code        #
#         by Ronald Smit           #
#----------------------------------#
#      http://www.troozers.net     #
####################################
function ResizePicNETPBM($img_source, $quality, $reqd_width) 
{ 
   global $NETPBM_path; 
   $pth = pathinfo($img_source);
   $tempfile = $pth["dirname"]."/temp.".$pth["extension"];
   echo $tempfile;

   if($NETPBM_path) 
   { 
      if(!is_dir($NETPBM_path))
      { 
         echo "NetPbm path not correct";
         die; 
      }
   } 

   if (eregi("\.png", $img_source))
   { 
      $cmd = $NETPBM_path . "pngtopnm $img_source | " . $NETPBM_path . "pnmscale -xysize $reqd_width $reqd_width | " . $NETPBM_path . "pnmtopng > $tempfile" ; 
   }
   else if (eregi("\.(jpg|jpeg)", $img_source))
   { 
      $cmd = $NETPBM_path . "jpegtopnm $img_source | " . $NETPBM_path . "pnmscale -xysize $reqd_width $reqd_width | " . $NETPBM_path . "ppmtojpeg -quality=$quality > $tempfile" ;
   }
   else if (eregi("\.gif", $img_source))
   { 
      $cmd = $NETPBM_path . "giftopnm $img_source | " . $NETPBM_path . "pnmscale -xysize $reqd_width $reqd_width | " . $NETPBM_path . "ppmquant 256 | " . $NETPBM_path . "ppmtogif > $tempfile" ; 
   }//end if.. 

   @exec($cmd); 

   // Delete the full sized original and rename resized temp
   // to the originals filename
   unlink($img_source);
   rename($tempfile, $img_source);
}

####################################
#     Function ResizePicGD2        #
#----------------------------------#
#     Created by Andy Stewart      #
#        Modified from code        #
#         by Ronald Smit           #
#----------------------------------#
#      http://www.troozers.net     #
####################################

function ResizePicGD2($img_source, $img_quality, $reqd_width)
{
   //debugbreak();
   $imagemethod = 'gd2';   //<-- Need to find out what this is used for!
                           //    could be a holder for possible GD1 
                           //    conversions as CreateThumbGD1 does not 
                           //    exist!

   if (!file_exists($img_source))
   {
     return(1); //file not found return 1
   }

   //load the original image and put its height/width in $img_info
   $img_info    = GetImageSize($img_source);
   $orig_height = $img_info[1]; //source height from $img_info
   $orig_width  = $img_info[0]; //source width from $img_info
   $type        = $img_info[2];

   $newwidth = $reqd_width;

   // lets get proportional here
   $scale = ($orig_width / $newwidth);
   $newheight  = ($orig_height / $scale);


   // debugbreak();

   if ($im = ImageCreateFromJPEG($img_source)) {
      if ($imagemethod == "gd2") {
         $im2 = ImageCreateTrueColor($newwidth, $newheight);
      }  else {
         $im2 = ImageCreate($newwidth, $newheight);
      }

      if ($imagemethod == "gd2") {
          ImageCopyResampled($im2,$im,0,0,0,0,$newwidth,$newheight,$orig_width,$orig_height);
      } else {
          ImageCopyResized($im2,$im,0,0,0,0,$newwidth,$newheight,$orig_width,$orig_height);
      }

      if (ImageJpeg($im2, $img_source, $img_quality)) {
          return(2);
      }
   }
   return(3);
}

//PDW 19-6-2004
//moved makethumb from rsgallery.php to here
//moved makethumb from admin.rsgallery.php to here
//makes no sense to have the same function on two places
function makeThumb($type, $file_in, $file_out, $maxsize, $origname, $quality, $ext)
    {

    global $IM_path;
	//Make thumbnail and copy to right location
	switch($type)
		{

		case 1:  //ImageMagick
			$cmd = $IM_path."convert -resize $maxsize $file_in $file_out";
			@exec($cmd);
			break;

		case 2:  //NETPBM
			CreateThumbNETPBM($file_in,$file_out,$maxsize,$origname,$quality);
					break;

		case 3:  //GD1
			if (CreateThumbGD2($ext, $file_in, $file_out, $quality, $maxsize, 'gd1') == 2)
						{
						//19-6-2004 PDW TODO
						//This alert should move to the calling program
						//Only return status of thumb creation
						?>
						<script language="Javascript" type="text/javascript">
							alert("<?php echo _RSGALLERY_ALERT_UPLOADOK;?>");
							location = 'index2.php?option=com_rsgallery&amp;task=batchupload';
						</script>
						<?php
						}
					else
						{
						?>
						//19-6-2004 PDW TODO
						//This alert should move to the calling program
						//Only return status of thumb creation
						<script language="Javascript" type="text/javascript">
						alert("<?php echo _RSGALLERY_ALERT_WRONGFORMAT;?>");
							location = 'index2.php?option=com_rsgallery&amp;task=batchupload';
						</script>
						<?php
						}
					break;

		case 4:  //GD2

			//PDW 18-6-2004.
			//We don't want a message from the thumb maker to say the gallery is uploaded.


			//if (CreateThumbGD2($ext, $file_in, $file_out, $quality, $maxsize) == 2)
			//	{
			//	?>
			//	<script>
			//		alert("<?php echo _RSGALLERY_ALERT_UPLOADOK;?>");
			//		location = 'index2.php?option=com_rsgallery';
			//	</script>
			//	<?php
			//	}
			//else


			if (!CreateThumbGD2($ext, $file_in, $file_out, $quality, $maxsize) == 2)
				{
				?>
				//19-6-2004 PDW TODO
				//This alert should move to the calling program
				//Only return status of thumb creation
				<script language="Javascript" type="text/javascript">
					alert("<?php echo _RSGALLERY_ALERT_WRONGFORMAT;?>");
					location = 'index2.php?option=com_rsgallery';
				</script>
				<?php
				}
			break;
	    default:
		    break;
	} //switch dus
    }


function ImportImage($p_image_name, $p_cat_id, $p_title, $p_desc)
	{
	global $i_file, $mosConfig_absolute_path,$imagepath,$database;
	include($mosConfig_absolute_path.'/administrator/components/com_rsgallery/settings.rsgallery.php');

	//Return values
	//1 import ok
	//2 wrong image_type
	//3 file copy failed
	//4 query failed

	//Get filetype
	//Check for right format

        $p_image_type = getmimeType($mosConfig_absolute_path."/uploadfiles/".$p_image_name);

	if (($p_image_type == "image/jpeg") || ($p_image_type == "image/pjpeg") || ($p_image_type == "image/gif") || ($p_image_type == "image/png") || ($p_image_type == "image/x-png"))
		{
		//PDW 17-6-2004
		//Give image new name to make sure its unique
		//Images with extension like Jpef or ping (4 length extension) are not supported (yet)
		$timestamp = gettimeofday();
//		if (substr($p_image_name,strlen($p_image_name)-4,1) == ".")
//			{
			$filename = substr( $p_image_name,0, strlen($p_image_name)-4);
			$filename = SpaceToUnderscore($filename);
			$filename = $filename."_".$timestamp["usec"].".";
			$filename = $filename.substr( $p_image_name,strlen($p_image_name)-3,3);
//			}

		if (copy($mosConfig_absolute_path."/uploadfiles/".$p_image_name, $mosConfig_absolute_path.$imagepath.$filename))
       			{
			//Addslashes to description

			//Ordering should be done here
			$database->setQuery("SELECT COUNT(*) FROM #__rsgalleryfiles WHERE gallery_id = '$p_cat_id'");
			$ordering = $database->loadResult() + 1;


			//Naam opslaan in database
			//PDW 18-6-2004
			//$database->setQuery("INSERT INTO #__rsgalleryfiles (title, name, descr, gallery_id, date, ordering) VALUES ('$title', '$image_name[$t]', '$descr', '$xx', now(), '$ordering++')");
			$database->setQuery("INSERT INTO #__rsgalleryfiles (title, name, descr, gallery_id, date, ordering) VALUES ('$p_title', '$filename', '$p_desc', '$p_cat_id', now(), '$ordering')");

			if ($database->query())
			  	{
				//Return insert OK
				$return_value=1;
				}
			//PDW Else branch added to show error
			else
				{
				//Return INSERT failed
				$return_value=4;
				}
       			}
		else
			{
			//Return copy failed
			$return_value=3;
			}
		}
	else
		{
		//Return wrong filetype
		$return_value=2;

                echo "Type of file : ".$p_image_type;
		}


        if ( $return_value == 1 )
        {
        	$file_in    = $mosConfig_absolute_path.$imagepath.$filename;
        	$file_out   = $mosConfig_absolute_path.$imagepath."thumbs/".$filename;
        	$maxsize    = $size;
        	$origname   = $filename;
        	$quality    = $JPEGquality;
        	$ext        = explode(".", $filename);
        	$ext        = strtolower(trim($ext[1]));

        	//Make thumbnail and copy to right location
        	if($conversiontype == 0)
        		{
        		//No autothumb, upload thumbnail seperately
        		move_uploaded_file("$thumb[$t]", $mosConfig_absolute_path.$imagepath."thumbs/".$thumb_name[$t]);
        		chmod($imagepath."thumbs/".$thumb_name[$t],0755);
        		}
        	else
        		{
        	        makeThumb($conversiontype, $file_in, $file_out, $maxsize, $origname, $quality, $ext);
        		resizePicture($conversiontype, $file_in, $ResizeOption, $PicWidth);
                	}
        }

	return $return_value;
	} //End of function

//TEMPORARY, UNTIL FUNCTION IS INTEGRATED IN CORE [Integrated as of Mambo 4.5.2]
/**
* Utility function to provide ToolTips
* @param string ToolTip text
* @param string Box title
* @returns HTML code for ToolTip
*/
if (!function_exists('mosToolTip')) {
  function mosToolTip($tooltip, $title='MOS ToolTip') {
  	global $_CONFIG, $_LANG, $mosConfig_live_site;

  	//echo "<a href=\"#\" onMouseOver=\"return overlib('" . $tooltip . "', CAPTION, '$title', BELOW, RIGHT);\" onmouseout=\"return nd();\"><img src=\"" . $_CONFIG->SITEURL . "/includes/js/ThemeOffice/tooltip.png\" align=\"center\" border=\"0\" alt=\"\" /></a>";
  	echo "<a href=\"#\" onMouseOver=\"return overlib('" . $tooltip . "', CAPTION, '$title', BELOW, RIGHT);\" onmouseout=\"return nd();\"><img src=\"" . $mosConfig_live_site . "/includes/js/ThemeOffice/help.png\" align=\"center\" border=\"0\" alt=\"\" /></a>";
  }
}

if (!function_exists('html_entity_decode')) {
	/**
	* html_entity_decode function for backward compatability in PHP
	* @param string
	* @param string
	*/
	function html_entity_decode ($string, $opt = ENT_COMPAT) {

		$trans_tbl = get_html_translation_table (HTML_ENTITIES);
		$trans_tbl = array_flip ($trans_tbl);

		if ($opt & 1) { // Translating single quotes
		// Add single quote to translation table;
		// doesn't appear to be there by default
		$trans_tbl["&apos;"] = "'";
		}

		if (!($opt & 2)) { // Not translating double quotes
		// Remove double quote from translation table
		unset($trans_tbl["&quot;"]);
		}

		return strtr ($string, $trans_tbl);
	}
}

function RSToolTip($title = "Title RSTooltip", $text = "Text goes in here")
	{
	global $mosConfig_live_site;
	?>
	<div id="overDiv" style="position:absolute; visibility:hidden; z-index:1000;"></div>
		<script language="javascript" src="../includes/js/overlib_mini.js"></script>
		<script language="Javascript" type="text/javascript">
		// following overlib functions are redefined with a kludge added to
		// hide any overlapping form select fields that may be under the overlay window
		// for IE.  The existing JSCookMenu functions are called to support this.
				if(document.all) var divref=oframe.document.all['overDiv'];
				function showObject(obj){
					if(ns4)obj.visibility="show";
					else if(ie4)obj.visibility="visible";
					else if(ns6)obj.style.visibility="visible";
					if (document.all){
					    divref.cmOverlap = new Array ();
						cmHideControl ('SELECT', divref);
                    }
				}
				function hideObject(obj){
					if(ns4)obj.visibility="hide";
					else if(ie4)obj.visibility="hidden";
					else if(ns6)obj.style.visibility="hidden";
					if(otimerid > 0)clearTimeout(otimerid);
					if(odelayid > 0)clearTimeout(odelayid);
					otimerid=0;
					odelayid=0;
					self.status="";
				    if (document.all){
				        cmShowControl(divref);
                    }
				}
				var overlibTable = new Array();
				var tabletext = '<table cellspacing=0 cellpadding=2 style="border:thin solid black;" bgcolor=#ff9900; width=150><tr><td bgcolor=black><b><font color=#FFFFFF><?php echo $title;?></font></b></td></tr><tr><td><?php echo $text;?></td></tr></table>';

		</script>
		<a href="#" 
			onmouseover='return overlib(tabletext,FULLHTML, VAUTO, DELAY, 700);'
			onmouseout="return nd();"><img src="<?php echo $mosConfig_live_site;?>/includes/js/ThemeOffice/help.png" alt="" width="16" height="16" border="0"></a>
		<?php
	}
?>