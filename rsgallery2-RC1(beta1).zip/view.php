<?php
//RSGallery//
############################################
# RSGallery - A Mambo Gallery Component!   #
# Copyright (C) 2003  by  Ronald Smit      #
# Homepage   : www.rsdev.nl	           #
# Version    : 2.0 RC1	                   #
# License    : Released under GPL          #
############################################

include('../../configuration.php');

//PDW 3-8-2004
//Added language selection based on available language.

if (file_exists($mosConfig_absolute_path.'/administrator/components/com_rsgallery/language/'.$mosConfig_lang.'.php'))
	{
	include($mosConfig_absolute_path.'/administrator/components/com_rsgallery/language/'.$mosConfig_lang.'.php');
	}
else
	{
	include($mosConfig_absolute_path.'/administrator/components/com_rsgallery/language/english.php');
	}

//When config.rsgallery.php is included we get a message
//include_once($mosConfig_absolute_path.'/administrator/components/com_rsgallery/config.rsgallery.php');
include_once($mosConfig_absolute_path.'/administrator/components/com_rsgallery/settings.rsgallery.php');



$picdir 	= $_GET['picdir'];
$name 		= $_GET['name'];
$xwidth 	= $_GET['xwidth'];
$ywidth 	= $_GET['ywidth'];
$id 		= $_GET['id'];

?>
<html>
<head>
<title>RSGallery - <?php echo $name; ?></title>
<link rel="stylesheet" href="<?php echo $mosConfig_live_site;?>/components/com_rsgallery/rsgallery.css" type="text/css" />

</head>
<body class="popup">
<center><a href="javascript:window.close()">Close</a><br /><br />
<?php
if ($name)
	{
	if ($xwidth > $ywidth)
		{
		if ($xwidth > $MaxWidthPopup)
			{
			?>
			<img src="<?php echo $mosConfig_live_site; ?>/images/gallery/<?php echo $name; ?>" alt="" border="1" width="<?php echo $MaxWidthPopup; ?>" />	
			<?php
			}
		else
			{
			?>
			<img src="<?php echo $mosConfig_live_site; ?>/images/gallery/<?php echo $name; ?>" alt="" border="1" />
			<?php
			}
		}
	else
		{
		if ($ywidth > 450)
			{
			?>
			<img src="<?php echo $mosConfig_live_site; ?>/images/gallery/<?php echo $name; ?>" alt="" border="1" height="450" />	
			<?php
			}
		else
			{
			?>
			<img src="<?php echo $mosConfig_live_site; ?>/images/gallery/<?php echo $name; ?>" alt="" border="1" />
			<?php
			}
		}


	
	?>
	<center>
	<table width="300" border="0" class="popup">
		<tr bgcolor="#808080">
			<td width="75"><strong><font color="#FFFFFF">Properties</font></strong></td><td>&nbsp;</td>
		</tr>
		<tr>
			<td width="75"><?php echo _RSGALLERY_FILENAME; ?>:</td><td width="250"><strong><?php echo $name; ?></strong></td>
		</tr>
	</table>
	</center>
	<?php
	}
?>
</center>
</body>
</html>
