<?php
/**
* Main file for the RSGallery Component
* @version $ 2.0 RC-1 $
* @package RSGallery_2.0
* @copyright (C) 2003 - 2004 RSDevelopment
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* RSGallery is Free Software
**/
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
?>
<link href="<?php echo $mosConfig_live_site; ?>/components/com_rsgallery/rsgallery.css" rel="stylesheet" type="text/css" />
<?php
error_reporting(E_ALL);//For debugging purposes only, comment this line out on production sites.

// ################################################################
// Stop conflict with ComboLITE/MAX
$pt_show = mosGetParam( $_REQUEST, 'pt_show', "" );
$id = mosGetParam( $_REQUEST, 'id', "" );
//#################################

require_once( $mainframe->getPath( 'front_html' ) );
include($mosConfig_absolute_path.'/configuration.php');
//Check for language files, if not found, default to english
if (file_exists($mosConfig_absolute_path.'/administrator/components/com_rsgallery/language/'.$mosConfig_lang.'.php'))
	{
	include($mosConfig_absolute_path.'/administrator/components/com_rsgallery/language/'.$mosConfig_lang.'.php');
	}
else
	{
	include($mosConfig_absolute_path.'/administrator/components/com_rsgallery/language/english.php');
	}

include($mosConfig_absolute_path.'/administrator/components/com_rsgallery/settings.rsgallery.php');
include_once($mosConfig_absolute_path.'/administrator/components/com_rsgallery/config.rsgallery.php');



require_once($mosConfig_absolute_path.'/includes/pageNavigation.php');
$my_id = $my->id;
// here we remove slashes around post vars we know can potentially contain quotes or backslashes
$postVars = array('comment','name', 'search', 'descr');

if (get_magic_quotes_gpc())
	{
	reset($postVars);
	foreach($postVars as $var)
		if(isset($_POST[$var])) $_POST[$var] = stripslashes($_POST[$var]);
	}

//-----------
function RSGalleryInline($id, $catid)
	{
	global $database, $imagepath;
	//HTML_RSGALLERY::RSGalleryHeader();
	HTML_RSGALLERY::RSGalleryInline($id, $catid);
//	HTML_RSGALLERY::RSGalleryFooter();
	}
//-----------
if(isset ($_GET['page'])) $page = $_GET['page'];
if(!(isset($page))) $page = '';

function RSGalleryVote()
	{
	global $database, $vote, $picid, $picdir;
	if ($vote)
		{
		//Retrieve values
		$database->setQuery("SELECT * FROM #__rsgalleryfiles WHERE id = '$picid'");
		$rows = $database->loadObjectList();
		foreach ($rows as $row)
			{
			$votes = $row->votes +1;
			$rating = $row->rating + $vote;
			$ordering = $row->ordering - 1;
			//Store new values
			$database->setQuery("UPDATE #__rsgalleryfiles SET votes = '$votes', rating = '$rating' WHERE id = '$row->id'");
			if ($database->query())
				{
				?>
				<script type="text/javascript">
					alert("<?php echo _RSGALLERY_THANK_VOTING; ?>");
					location = '<?php echo sefRelToAbs("index.php?option=com_rsgallery&page=inline&id=".$row->id."&catid=".$row->gallery_id."&limitstart=".$ordering); ?>';
				</script>
				<?php
				}
			else
				{
				?>
				<script type="text/javascript">
					alert("<?php echo _RSGALLERY_VOTING_FAILED; ?>");
					location = '<?php echo sefRelToAbs("index.php?option=com_rsgallery&page=inline&id=".$row->id."&catid=".$row->gallery_id."&limitstart=".$ordering); ?>';
				</script>
				<?php
				}
			}
		}
	else
		{
		?>
		<script type="text/javascript">
			alert("<?php echo _RSGALLERY_RATING_NOTSELECT; ?>");
			location = '<?php echo sefRelToAbs("index.php?option=com_rsgallery&page=inline&id=".$row->id."&catid=".$row->gallery_id."&limitstart=".$ordering); ?>';
		</script>
		<?php
		}
	}

function addComment()
	{
	global $database, $picdir, $picid, $name, $comment;
	$database->setQuery("SELECT * FROM #__rsgalleryfiles WHERE id = '$picid'");
	$rows = $database->loadObjectList();
	foreach ($rows as $row)
		{
		$id = $row->id;
		$catid= $row->gallery_id;
		$l_start = $row->ordering - 1;
		}
	if (!isset($comment) || !isset($name))
		{
		//Back to image
		?>
		<script type="text/javascript">
			alert("<?php echo _RSGALLERY_COMMENT_FIELD_CHECK; ?>");
			location = '<?php echo sefRelToAbs("index.php?option=com_rsgallery&page=inline&id=".$id."&catid=".$catid."&limitstart=".$l_start); ?>';
		</script>
		<?php
		}
	else
		{
		$name = addslashes($name);
		$comment = addslashes($comment);
		$database->setQuery("INSERT INTO #__rsgallery_comments (name, comment, picid, date) VALUES ('$name','$comment','$picid', now())");
		if ($database->query())
			{
			?>
			<script type="text/javascript">
				alert("<?php echo _RSGALLERY_COMMENT_ADDED; ?>");
				location = '<?php echo sefRelToAbs("index.php?option=com_rsgallery&page=inline&id=".$id."&catid=".$catid."&limitstart=".$l_start); ?>';
			</script>
			<?php
			//Retrieve comment count and increment it, thanks to Allan Kissack
			$database->setQuery("SELECT * FROM #__rsgalleryfiles WHERE id = '$picid'");
			$rows = $database->loadObjectList();
			foreach ($rows as $row)
				{
				$comments = $row->comments +1;
				$database->setQuery("UPDATE #__rsgalleryfiles SET comments = '$comments' WHERE id = '$row->id'");
				if (!$database->query()) 
					{
					?>
					<script type="text/javascript">
						alert("<?php echo _RSGALLERY_COMMENT_COUNT_NOT_ADDED; ?>");
						location = '<?php echo sefRelToAbs("index.php?option=com_rsgallery&page=inline&id=".$row->id."&catid=".$row->gallery_id."&limitstart=".$ordering); ?>';
					</script>
					<?php
					}
				}
			}
		else
			{
			?>
			<script type="text/javascript">
				alert("<?php echo _RSGALLERY_COMMENT_NOT_ADDED; ?>");
				location = '<?php echo sefRelToAbs("index.php?option=com_rsgallery&page=inline&id=".$id."&catid=".$catid."&limitstart=".$l_start); ?>';
			</script>
			<?php
			}
		}
	}

function slideshow($id,$catid)
	{
	global $database, $mosConfig_live_site, $mosConfig_absolute_path;
	$database->setQuery("SELECT * FROM #__rsgalleryfiles WHERE gallery_id = '$catid' ORDER BY ordering ASC");
	$rows = $database->LoadObjectList();
	include($mosConfig_absolute_path."/components/com_rsgallery/slideshow.rsgallery.php");
	}

function frontUpload($p_catid)
	{
	//TODO check if userupload is allowed.
	//TODO check if userupload is allowed for this category
	global $my_id;
	if ($my_id == 0)
		{
		mosRedirect( sefRelToAbs("index.php?option=com_rsgallery") );
		}
	else
		{
		HTML_RSGALLERY::ShowFrontUpload($p_catid);
		}
	}



function doFrontUpload()
	{
	global $database, $mosConfig_absolute_path, $zipfile, $i_file, $i_thumb, $i_cat, $imagepath, $conversiontype, $JPEGquality, $title, $descr;

        // Depending on the version of Mambo, this could be in one of two places.
        if (file_exists($mosConfig_absolute_path.'/administrator/classes/pclzip.lib.php'))
        {
	   include($mosConfig_absolute_path.'/administrator/classes/pclzip.lib.php');
        }
        else
        {
	   include($mosConfig_absolute_path.'/administrator/includes/pcl/pclzip.lib.php');
        }

	include($mosConfig_absolute_path.'/administrator/components/com_rsgallery/settings.rsgallery.php');
	$allowed = array("jpg","png","gif");
	//Check of het een ZIP of een gewone file is
//	$thumb_name = $_FILES['i_thumb']['name'];
	$file_name = $_FILES['i_file']['name'];
	$file_title = 
	$file_array = array_reverse(explode(".", $file_name));
	$file_ext = strtolower($file_array[0]);

	if ($file_ext == "zip")
		{
		function myPreExtractCallBack($p_event, &$p_header)
		{
		if ($p_header['folder'] == 1)
			{
			return 0;
			}
		else
			{
			return 1;
			}
		}

		//New zipfile
		$zipfile = new PclZip($i_file);
		//List contents in array
		$ziplist = $zipfile->listContent();
		//Unzip to /uploadfiles, removing all path info
		$list = $zipfile->extract(	PCLZIP_OPT_PATH, $mosConfig_absolute_path."/uploadfiles", 
									PCLZIP_OPT_REMOVE_ALL_PATH, 
									PCLZIP_CB_PRE_EXTRACT, "myPreExtractCallBack");
		if ($list == 0)
			{
    		die ("Error message :".$zipfile->errorInfo(true));
			}
		for ($i=0; $i<sizeof($ziplist); $i++)
			{
			//No spacetounderscore here, zipfile can contain filenames with spaces.
			ImportImage($ziplist[$i]['filename'], $i_cat);
/*
the next part has been moved to importimage in config.rsgallery
this to solve the not unique name problem
its also not very effective to have the same code about 4 times

			if (copy($mosConfig_absolute_path."/uploadfiles/".$ziplist[$i]['filename'], $mosConfig_absolute_path.$imagepath.$i_name))
				{
				//Make thumbnail
				$file_in = $mosConfig_absolute_path.$imagepath.$i_name;
				$file_out = $mosConfig_absolute_path.$imagepath."thumbs/".$i_name;
				$maxsize    = $size;
				$origname   = $i_name;
				$quality    = $JPEGquality;
				$ext		= explode(".", $i_name);
				$ext        = strtolower(trim($ext[1]));

				if($conversiontype == 0)
					{
					//No autothumb, upload thumbnail seperately
					copy("$thumb[$t]", "$imagepath$thumbs/$thumb_name[$t]");
					}
				else
					{
        		        	makeThumb($conversiontype, $file_in, $file_out, $maxsize, $origname, $quality, $ext);
					}
				//Opslaan in DB
				$database->setQuery("SELECT COUNT(*) FROM #__rsgalleryfiles WHERE gallery_id = '$i_cat'");
				$ordering = $database->loadResult() + 1;

				$database->setQuery("INSERT INTO #__rsgalleryfiles". 
					"(title, name, descr, gallery_id, date, ordering) VALUES ".
					"('$i_name', '$i_name', '', '$i_cat', now(), '$ordering')");

				//if ($database->query())

				//email naar gebruiker en admin

				//Verwijder upload
				//unlink($mosConfig_absolute_path."/uploadfiles/".$ziplist[$i]['filename']);

				}
			else
				{
				//File not copfied
				echo "Upload not succesful";
				}
*/

			//Here comes errorhandling for importimage
			}  //End for
		} //End if zip
	else
		{
		//This part is for single images, not in a zipfile.
		if (in_array($file_ext, $allowed))
			{
			$i_name = SpaceToUnderscore($file_name);
			echo $i_name;
			if (copy($i_file, $mosConfig_absolute_path."/uploadfiles/".$i_name))
				{
/* This part can be removed. Now handled by importimage in config.rsgallery		
				//Make thumbnail
				$file_in = $mosConfig_absolute_path.$imagepath.$i_name;
				$file_out = $mosConfig_absolute_path.$imagepath."thumbs/".$i_name;
				$maxsize    = $size;
				$origname   = $i_name;
				$quality    = $JPEGquality;
				$ext		= array_reverse(explode(".", $i_name));
				$ext        = strtolower(trim($ext[0]));

				if($conversiontype == 0)
					//No autothumb, upload thumbnail seperately
					copy($i_thumb, $mosConfig_absolute_path.$imagepath.$i_name);
				else
			               	makeThumbfront($conversiontype, $file_in, $file_out, $maxsize, $origname, $quality, $ext);
				//Opslaan in DB
				$database->setQuery("SELECT COUNT(*) FROM #__rsgalleryfiles WHERE gallery_id = '$i_cat'");
				$ordering = $database->loadResult() + 1;

				$database->setQuery("INSERT INTO #__rsgalleryfiles". 
					"(title, name, descr, gallery_id, date, ordering) VALUES ".
					"('$i_name', '$i_name', '', '$i_cat', now(), '$ordering')");
				if ($database->query())
					{

					}

				//email naar gebruiker en admin
*/

				$imported=ImportImage($i_name,  $i_cat, $title, $descr);

				if ($imported==1)
					{
					?>
					<script type="text/javascript">
					alert("<?php echo _RSGALLERY_ALERT_UPLOADOK; ?>");
					location = 'index.php?option=com_rsgallery';
					</script>
					<?php
					}
				}
			else
				{
				?>
				<script type="text/javascript">
					alert("<?php echo _RSGALLERY_ALERT_NOWRITE;?>");
					location = 'index.php?option=com_rsgallery';
				</script>
				<?php
				}
			} // in array
		else
			{
			?>
			<script type="text/javascript">
			Alert ("Upload not sucessfull");
			</script>
			<?php
			}
		} //end else if zip
	} //end frontupload



function Download($filename)
	{
	global $mosConfig_live_site, $mosConfig_absolute_path, $imagepath, $filename, $file, $att;
	if ($filename)
		{
		//$filename = $file;
		if (strstr($_SERVER["HTTP_USER_AGENT"],"MSIE 5.5")) 
			{
	    	$att = "";
	    	} 
		else
			{
	    	$att = " attachment;";
	    	}
		//Iets regelen waardoor altijd een downloadbox verschijnt
		$file = $mosConfig_absolute_path.$imagepath.$filename;

		//echo $file;
		header("Cache-control: private"); // fix for IE
		header("Content-Disposition: ".$att." filename=$filename");
		header("Content-type: application/octet-stream");
		header("Content-Type: image/jpg");
		header("Content-Transfer-Encoding: binary");
        //header("Content-length: " . filesize($file));
		header("Pragma: no-cache");
		header("Expires: 0");


		$fp=fopen($file,"rb");
        //readfile($file);
		set_magic_quotes_runtime(0); 
		while($fp && !feof($fp))
			{
			$buffer = fread($fp, 4096);
			print $buffer;
			}
		set_magic_quotes_runtime(get_magic_quotes_gpc());
		fclose($fp);
		}
	else
		{
		//
		}
	}

function userCat($uid, $catid)
	{
	global $database, $mosConfig_absolute_path, $max_user_cat,$rows;
	include_once($mosConfig_absolute_path.'/administrator/components/com_rsgallery/settings.rsgallery.php');
	//Check number of usercats

	if ($catid != 0)
		{
		//Edit category
		$database->setQuery("SELECT * FROM #__rsgallery WHERE id ='$catid'");
		$rows = $database->LoadObjectList();
		echo "Aantal rijen: ".count($rows);
		HTML_RSGALLERY::userCat($rows);
		}
	else
		{
		if (checkUserCat($uid) < $max_user_cat || $max_user_cat == 0)
			{
			//New category
			HTML_RSGALLERY::usercat(0);
			}
		else
			{
			?>
			<script type="text/javascript">
				alert('<?php echo _RSGALLERY_MAX_USERCAT_ALERT; ?>');
				location = '<?php echo sefRelToAbs("index.php?option=com_rsgallery"); ?>';
			</script>
			<?php
			}
		}
	}

function makeusercat()
	{
	global $database, $my, $id;
	$id 			= $_POST['catid'];
	$catname1 		= $_POST['catname1'];
	$description		= $_POST['description'];
	$published		= $_POST['published'];

	if ($id)
		{
		$ordering = $_POST['ordering'];
		$database->setQuery("UPDATE #__rsgallery SET ".
			"catname = '$catname1', ".
			"description = '$description', ".
			"published = '$published' ".
			"WHERE id='$id'");
		if ($database->query())
			{
			echo "Query gelukt";
			}
		else
			{
			echo "Query failed: ".mysql_error();
			}
		}
	else
		{
		//New category
		$database->setQuery("SELECT MAX(ordering) FROM #__rsgallery WHERE uid = '$my->id'");
		$ordering = $database->loadResult() + 1;
		$database->setQuery("INSERT INTO #__rsgallery ".
			"(catname   ,description   ,ordering   ,parent ,published   ,user,uid) VALUES ".
			"('$catname1','$description','$ordering','0'    ,'$published','1' ,'$my->id')");
		if ($database->query())
			{
			?>
			<script type="text/javascript">
				alert('<?php echo _RSGALLERY_ALERT_NEWCAT; ?>');
				location = '<?php echo sefRelToAbs("index.php?option=com_rsgallery"); ?>';
			</script>
			<?php
			}
		else
			{
			?>
			<script type="text/javascript">
				alert('<?php echo _RSGALLERY_ALERT_NONEWCAT; ?>');
				location = '<?php echo sefRelToAbs("index.php?option=com_rsgallery"); ?>';
			</script>
			<?php
			}
		}
	mosRedirect( sefRelToAbs("index.php?option=com_rsgallery") );
	}

function userCatProperties()
	{
	global $database, $my, $rows;
	$my_id = $my->id;
	$database->setQuery("SELECT * FROM #__rsgallery WHERE uid = '$my_id'");
	$rows = $database->LoadObjectList();
	//echo "ID is: ".$my->id;
	HTML_RSGALLERY::userCatProperties($rows);
	}

function delusercat($catid)
	{
	global $database, $my, $mosConfig_absolute_path, $imagepath;
	$database->setQuery("SELECT uid FROM #__rsgallery WHERE id = '$catid'");
	$uid = $database->LoadResult();
	if ($uid == $my->id)
		{
		//User is gallery owner, continue
		$database->setQuery("DELETE FROM #__rsgallery WHERE id = '$catid'");
		if ($database->query())
			{
			//Delete all images from images and images/thumbs
			echo $catid;
			$database->setQuery("SELECT name,id FROM #__rsgalleryfiles WHERE gallery_id = '$catid'");
			$files = $database->loadObjectList();
			foreach($files as $file)
				{
				//Delete corresponding files
				unlink($mosConfig_absolute_path.$imagepath.$file->name);
				unlink($mosConfig_absolute_path.$imagepath."thumbs/".$file->name);
				//Delete corresponding database entry
				$database->setQuery("DELETE FROM #__rsgalleryfiles WHERE id = '$file->id'");
				$database->query();
				}
			mosRedirect( sefRelToAbs("index.php?option=com_rsgallery&page=usercatproperties"),_RSGALLERY_ALERT_CATDELOK);
			}
		else
			{
			//echo "Categorie niet verwijderd";
			mosRedirect( sefRelToAbs("index.php?option=com_rsgallery&page=usercatproperties"),_RSGALLERY_ALERT_CATDELNOTOK);
			}
		}
	else
		{
		//User is not gallery owner, abort
		mosRedirect(sefRelToAbs("index.php?option=com_rsgallery"),_RSGALLERY_USERCAT_NOTOWNER);
		}
	}


function accessControl($catid)
	{
	global $database, $my;
	$database->setQuery("SELECT * FROM #__rsgallery WHERE id='$catid'");
	$rows = $database->loadObjectList();
	HTML_RSGALLERY::accessControl($rows, $catid);
	}

function save_acl()
	{
	global $database;
	//Write new value of $user to database
	$catid = $_POST['catid'];
	$v_acceslevel = $_POST['v_acceslevel'];
	if (isset($_POST['list2']))
		$list2 = $_POST['list2'];
	else
		$list2 = "";
	if ($v_acceslevel == 3)
		{
		//Serialize array to store in database
		$userlist = serialize($list2);
		//$nr = count($userlist);
		//echo "Aantal in ".$userlist." is: ".$nr;
		//break;
		$database->setQuery("UPDATE #__rsgallery SET ".
				"user = '$v_acceslevel', ".
				"allowed = '$userlist' ".//RS, 13-08-04: 'allowed' is new field to store uid from allowed users
				"WHERE id='$catid'");
		if ($database->query())
			{
			echo "Updated DB with ARRAY";
			}
		else
			{
			echo "Database NOT updated with ARRAY information!";
			echo "Error: ".mysql_error();
			}
		}
	else
		{
		//echo $catid."--".$v_acceslevel;
		$database->setQuery("UPDATE #__rsgallery SET ".
				"user = '$v_acceslevel' ".
				"WHERE id='$catid'");
		if ($database->query())
			{
			echo "Database updated!($v_acceslevel)";
			//mosRedirect( sefRelToAbs("index.php?option=com_rsgallery&page=usercatproperties") );
			}
		else
			{
			echo "Database NOT updated!($v_acceslevel,$catid)";
			echo "Error: ".mysql_error();
			//mosRedirect( sefRelToAbs("index.php?option=com_rsgallery&page=usercatproperties") );
			}
		}
	}

function edit_image($id)
	{
	global $database;
	if ($id)
		{
		$database->setQuery("SELECT * FROM #__rsgalleryfiles WHERE id = '$id'");
		$rows = $database->loadObjectList();
		HTML_RSGALLERY::edit_image($rows, $id);
		}
	}

function save_image($id)
	{
	global $database;
	$title = $_POST['title'];
	$description = $_POST['descr'];
	$catid = $_POST['catid'];
	//echo "CATID is: ".$catid;
	$database->setQuery("UPDATE #__rsgalleryfiles SET ".
			"title = '$title', ".
			"descr = '$description' ".
			"WHERE id='$id'");
	//catid, inline, id, limitstart
	if ($database->query())
		{
		mosRedirect( sefRelToAbs("index.php?option=com_rsgallery") );
		}
	else
		{
		echo "Error: ".mysql_error();
		}
	}

function delete_image($id)
	{
	//TODO PDW 20-6-2004
	//Check if deleting user is allowed to delete
	//Otherwise log him out or something drastic
	//Should this not be a function for both backend and frontend?
	global $database, $mosConfig_absolute_path, $imagepath;
	if ($id)
		{
		$database->setQuery("SELECT name, gallery_id FROM #__rsgalleryfiles WHERE id = '$id'");
		$results = $database->loadObjectList();
		foreach($results as $result)
			{
			$catid 		= $result->gallery_id;
			$filename	= $result->name;
			}
		//echo $catid;
		//echo "--index.php?option=com_rsgallery&catid=$catid";
		//break;
		$database->setQuery("DELETE FROM #__rsgalleryfiles WHERE id = '$id'");
		if ($database->query())
			{
			unlink($mosConfig_absolute_path.$imagepath.$filename);
			unlink($mosConfig_absolute_path.$imagepath."thumbs/".$filename);
			}
		mosRedirect( sefRelToAbs("index.php?option=com_rsgallery&catid=$catid"),_RSGALLERY_DELIMAGE_OK);
		}
	else
		{
		mosRedirect( sefRelToAbs("index.php?option=com_rsgallery") );
		}
	}

function test()
	{
	/*
	ARO-GROUPS
	ROOT (17)
		|-USERS (28)
			|-Public Frontend (29)
			|	|-Registered (18)
			|		|-Author (19)
			|			|-Editor (20)
			|				|-Publisher (21)
			|-Public Backend (30)
				|-Manager (23)
					|-Administrator (24)
						|-Super Administrator (25)
	*/
	global $database, $my, $acl;
	$my_id = $my->id;
	//Get group id from logged in user
	$database->setQuery("SELECT gid FROM #__users WHERE id = $my_id");
	$gid = $database->loadResult();
	//
	$group = $acl->get_group_children('18', $group_type = 'ARO', $recurse = 'RECURSE');
	//echo var_dump($group);
	if (in_array($gid, $group))
		{
		echo "Is part of registered";
		}
	else
		{
		echo "Is NOT part of registered";
		}
	}

//-----------
switch ($page)
{
case "test":
	test();
	break;
case 'inline':
	RSGalleryInline($id, $catid);
	break;
case 'vote':
	RSGalleryVote();
	break;
case 'addcomment':
	addComment();
	break;
case "slideshow":
	slideshow($id,$catid);
	break;
case "newusercat":
	userCat($my_id, 0);
	break;
case "editusercat":
	usercat($my_id, $catid);
	break;
case "makeusercat":
	makeusercat();
	break;
case "delusercat":
	delusercat($catid);
	break;
case "usercatproperties":
	userCatProperties();
	break;
case "edit_image":
	edit_image($id);
	break;
case "delete_image":
	delete_image($id);
	break;
case "save_image":
	save_image($id);
	break;
case "accessctl":
	accessControl($catid);
	break;
case "save_acl":
	save_acl();
	break;
case "frontupload":
	if (!isset($catid))
		$catid=null;
	frontUpload($catid);
	break;
case "doFrontUpload":
	doFrontUpload();
	break;
case "download":
	Download($filename);
	break;
default:
##############################################################
	//This is the main function when there is no function specified.
	//Each function called here to show something makes his/her own table
	//functions that start with HTML_RSGALLERY can be found in rsgallery.html.php


	if (isset($catid))
		{
		showRSPath($catid);						//Show the breadcrumbs.
		HTML_RSGALLERY::RSGalleryTitleblock($catid, null);		//Show the titleblock for $catid
		ShowSubcats($catid);						//This show the subcats if they are available
		if (!isset($limit))
			$limit=$PageSize;
		if (!isset($limitstart))
			$limitstart=0;

		HTML_RSGALLERY::RSShowPictures ($catid, $columns, $PageSize, $limit, $limitstart);	//Show the pictures
		echo "<br />";
		}
	else
		{
		HTML_RSGALLERY::RSGalleryTitleblock(null, $intro_text);	//Show the titleblock for RSGallery
		HTML_RSGALLERY::RSGalleryList($dropdown);		//Show the galleries
		//TODO check if user_cat is what Ronald wanted to use for this.
		if ($user_cat==1)		
			echo HTML_RSGALLERY::RSUserGalleryList();	//This row shows the user galleries, if set in the administrator
		if ($displayRandom==1)
			echo showRandom();				//This row shows the random pictures, if set in the administrator
		if ($displayLatest==1)
			echo ShowLatest();				//Show the random pictures, if set in the administrator
		}

	  HTML_RSGALLERY::RSGalleryFooter(); 
}

?>
