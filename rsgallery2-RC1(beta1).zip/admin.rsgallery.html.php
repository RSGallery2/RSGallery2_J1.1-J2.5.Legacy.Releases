<?php
/**
* This file handles the HTML processing for the Admin section of RSGallery.
*
* @version $ 2.0 RC-1 $
* @package RSGallery_2.0
* @copyright (C) 2003 - 2004 RSDevelopment
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* RSGallery is Free Software
**/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

/**
* The HTML_RSGALLERY class is used to encapsulate the HTML processing for RSGallery.
**/
class HTML_RSGALLERY
	{
	/**
	 * Inserts the HTML for the top menu in the admin view.
	 */
	function RSGalleryTopMenu()
		{
		?>
        <table border="0" width="100%">
			<tr>
				<td colspan="2" align="center">
					<a href="index2.php?option=com_rsgallery&task=settings">Settings</a> | 
					<a href="index2.php?option=com_rsgallery&task=view_categories">Categories</a> | 
					<a href="index2.php?option=com_rsgallery&task=upload">Upload</a> | 
					<a href="index2.php?option=com_rsgallery&task=batchupload">Batch Upload Wizard</a> | 
					<a href="index2.php?option=com_rsgallery&task=view_images">View Images</a> | 
<?php
/* PDW 20-6-2005 Don't show the links if they don't work
					<a href="index2.php?option=com_rsgallery&task=regen_thumbs">Regenerate Thumbs</a> | 
					<a href="index2.php?option=com_rsgallery&task=consolidate_db">Consolidate Database</a> | 
					<a href="index2.php?option=com_rsgallery&task=import_captions">Import Captions</a>
*/
?>
				</td>
			</tr>
		</table>
		<?php
		}

	/**
	 * Inserts the HTML placed at the top of all RSGallery Admin pages.
	 */
	function RSGalleryHeader()
		{
		?>
        <table border="0" width="100%">
        	<tr>
            	<td width="200"><img src="../administrator/components/com_rsgallery/images/logo_rsgallery.gif" alt="" border="0" /></td>
				<td class="sectionname"><?php echo _RSGALLERY_ADMIN_TITLE;?></td>
            </tr>
			<tr>
				<td colspan="2"><hr></td>
			</tr>
		</table>
		<?php
		}

	/**
	 * Inserts the HTML placed at the bottom of all RSGallery Admin pages.
	 */		
	function RSGalleryFooter()
		{
		?>
		<table border="0" width="100%">
        	<tr>
				<td align="center">
				    <br /><br /><p><font class="smalldark"><b><?php echo _RSGALLERY_VERSION;?></b><br />
					&copy Copyright 2003 by Ronald Smit<br />
					<a href="http://mamboforge.net/projects/rsgallery2" target="_blank">Project home</a></font></p>
				</td>
            </tr>
		</table>
		<?php
		}

	/**
	 * Inserts the HTML content for the first screen of the batch upload process.
	 */		
	function batch_upload()
		{
		global $database, $selcat, $xcat, $option, $submit, $zip_file, $mosConfig_absolute_path, $FTP_path;
		// BEGIN: Troozers Modification
		include($mosConfig_absolute_path.'/administrator/components/com_rsgallery/settings.rsgallery.php');
		// END: Troozers Modification
		?>
                <script>
                function submitbutton(pressbutton){
                    if (pressbutton != 'cancel'){
                        submitform( pressbutton );
                        return;
                    } else {
                        window.history.go(-1);
                        return;
                    }
                }
                </script>
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		<tr>
			<td>
				<table>
					<tr>
						<td class="sectionname" align="left">Batch Upload Wizard</td>
					</tr>
				</table>
				<table class="adminForm" border="0" width="100%">
				<form action="index2.php?option=com_rsgallery&task=batchupload" method="post" name="adminForm" enctype="multipart/form-data">
				<tr>
					<td colspan="2" class="sectionname" align="center"><font size="4">Step 1</font></td>
				</tr>
				<tr>
					<td colspan="2" class="sectionname" align="left">&nbsp;</td>
				</tr>
				<!-- BEGIN: Troozers Modification -->
				<tr>
					<td>Specify upload method</td>
					<td>
						<input type="radio" value="zip" name="batchmethod" />
						Image ZIP-file : 
						<input type="file" name="zip_file" size="20" />
					</td>
				</tr>

				<tr>
					<td>&nbsp;</td>
					<td>
						<input type="radio" value="ftp" name="batchmethod" />
						FTP Path :  
						<input type="text" name="ftppath" value="<?php echo $FTP_path; ?>" size="30" />
					</td>
				</tr>
				<tr>
					<td>&nbsp;<br /></td>
					<td>&nbsp;<br /></td>
				</tr>
				<!-- END: Troozers Modification -->
				<tr>
					<td>Specify category</td>
					<td><input type="radio" name="selcat" value="1" />&nbsp;&nbsp;Yes, all images in:&nbsp;<select name="xcat" size="1">
							<?php echo showCategories2();?>
						</select></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><input type="radio" name="selcat" value="" />&nbsp;&nbsp;No, specify category per image in step 2</td>
				</tr>
				<tr>
					<td colspan="2" align="center"<br /><br /><br /><input type="submit" name="submit" value="Next -->" /><br /><br /></td>
				</tr>
				<input type="hidden" name="submit" value="submit" />
				<!--<input type="hidden" name="option" value="<?php echo $option; ?>" />
				<input type="hidden" name="task" value="batchupload" />
				<input type="hidden" name="boxchecked" value="0" />-->
				</form>
				</table>
			</td>
		</tr>
		</table>

		<?php
		}

	/**
	 * Inserts the HTML content for the second screen of the batch upload process.
	 */				
	function batch_upload_2($ziplist, $mosConfig_live_site, $mosConfig_absolute_path)
		{
		global $zip_list, $database, $ftppath;
		?>
                <script>
                function submitbutton(pressbutton){
                    if (pressbutton != 'cancel'){
                        submitform( pressbutton );
                        return;
                    } else {
                        window.history.go(-1);
                        return;
                    }
                }
                </script>
		<table border="0" class="adminForm" width="90%" border="1" cellpadding="2" cellspacing="2">
		<tr>
			<td colspan="3" class="sectionname" align="center"><font size="4">Batch Upload Wizard</font></td>
		</tr>
		<tr>
			<td colspan="3" class="sectionname"><font size="4">Step 2</font></td>
		</tr>
		<form name="adminForm" method="post" action="index2.php?option=com_rsgallery&task=save_batchupload">
		<tr>
		<?php
                // Initialize k (the column reference) to zero.
                $k = 0;

		for ($i=0; $i<sizeof($ziplist); $i++)
			{
			$k++;
			//Get array with parts of filename, reverse to get extension at pos 0
			$ext = array_reverse(explode(".", $ziplist[$i]['filename']));
			$filename = array_reverse(explode("/",$ziplist[$i]['filename']));
			$filename = $filename[0];
			//Make lowercase to include all extensions case insensitive
			$ext = strtolower($ext[0]);
			//Array with allowed extensions
			$allowed_ext = array("gif","jpg","png");
			if (!in_array($ext, $allowed_ext))
				continue;
			?>
			<td align="center" valign="top" bgcolor="#CCCCCC">
				<table border="0" cellspacing="2" cellpadding="2">
					<tr>
						<td colspan="2" align="right">Delete #<?php echo $i;?>: <input type="checkbox" name="delete[<?php echo $i;?>]" value="true" /></td>
					</tr>
					<tr>
						<td align="center" colspan="2"><img src="<?php echo $mosConfig_live_site.$ftppath.$filename;?>" alt="" border="1" width="100" align="center" /></td>
					</tr>
					<input type="hidden" value="<?php echo $filename;?>" name="filename[]" />
					<tr>
						<td>Title</td>
						<td>
							<input type="text" name="ptitle[]" size="15" />
						</td>
					</tr>
					<tr>
						<td>Category</td>
						<td><?php
							if ($_POST['selcat'] == 1 && $_POST['xcat'] !== 'xx')
								{
								?>
								<input type="text" name="cat_text" value="<?php echo htmlspecialchars(stripslashes(getcatName($_POST['xcat'])));?>" readonly />
								<input type="hidden" name="category[]" value="<?php echo $_POST['xcat'];?>" />
								<?php
								}
							else
								{?>
								<select name="category[]" size="1">
								<?php echo showCategories2();?>	
								</select>
								<?php
								}
								?>
						</td>
					</tr>
				</table>
			</td>
			<?php
			if ($k == 3)
				{
				echo "</tr><tr>";
				$k = 0;
				}
			}
			?>
			<input type="hidden" name="teller" value="<?php echo $i;?>" />
			<tr>
				<td colspan="3" align="center"><input type="submit" name="submit" value="upload" /></td>
			</tr>
			</table></form>
		<?php
		}

	/**
	 * Inserts the HTML content for the image information editing screen.
	 */				
	function editImage($option, $e_id, &$rows)
		{
		global $database, $catid, $imagepath, $option, $e_id, $descr, $cid, $mosConfig_live_site;
   		?>
                <script>
                function submitbutton(pressbutton){
                    if (pressbutton != 'cancel'){
                        submitform( pressbutton );
                        return;
                    } else {
                        window.history.go(-1);
                        return;
                    }
                }
                </script>
		<form name="adminForm" method="post" action="index2.php">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<td>
				<table>
					<tr>
						<td class="sectionname"><?php echo _RSGALLERY_PROP_TITLE;?></td>
					</tr>
				</table>
				<?php
				foreach($rows as $row)
					{
					?>
					<table class="adminForm" border="0" width="100%">
						<tr>
							<td colspan="2" width="200" class="sectionname">&nbsp;</td>
							<td rowspan="3"><img src="<?php echo $mosConfig_live_site.$imagepath."thumbs/".$row->name;?>" alt="<?php echo htmlspecialchars(stripslashes($row->descr), ENT_QUOTES);?>" border="1" /></td>
						</tr>
						<tr>
							<td><?php echo _RSGALLERY_TITLE;?>:</td>
							<td width="100"><input type="text" name="xtitle" size="40" value="<?php echo htmlspecialchars(stripslashes($row->title), ENT_QUOTES);?>" /></td>
						</tr>
                        <tr>
                           <td><?php echo _RSGALLERY_FILENAME;?>:</td>
                           <td><strong><?php echo $row->name;?></strong></td>
                        </tr>
                        <!--<tr>
                           <td><?php echo _RSGALLERY_ID;?>:</td>
                           <td><strong><?php echo $e_id;?></strong></td>
                        </tr>-->
                        <tr>
                           <td><?php echo _RSGALLERY_DESCR;?>:</td>
                           <td colspan="2"><textarea cols="30" rows="5" name="descr"><?php echo htmlspecialchars(stripslashes($row->descr));?></textarea></td>
                        </tr>
					</table>
					<?php
					}
					?>
					<input type="hidden" name="id" value="<?php echo $e_id; ?>" />
					<input type="hidden" name="option" value="<?php echo $option;?>" />
					<input type="hidden" name="task" value="" />
				</form>
				</td>
			</tr>
		</table>
		<?php
   		}

		function showSettings($option, $rows, $conf_style, &$imageLibs, $thumbConverType)
   		{
		global $mosConfig_absolute_path, $mosConfig_editor, $option, $task;
		include($mosConfig_absolute_path . '/administrator/components/com_rsgallery/settings.rsgallery.php');
                if(!isset($conversiontype) || $conversiontype=='') $conversiontype = $thumbConverType;
		?>
                <script>
                function submitbutton(pressbutton){
                    submitform( pressbutton );
                    return;
                }
                </script>
		<br />
		<form action="index2.php" method="POST" name="adminForm">
		<script language="javascript" src="js/dhtml.js"></script>
		<table cellpadding="3" cellspacing="0" border="0" width="100%">
		<tr>
			<td width="5" class="tabpadding">&nbsp;</td>
			<td id="tab1" nowrap="nowrap" class="offtab" onclick="dhtml.cycleTab(this.id)"><?php echo _RSGALLERY_TAB1_SETTINGS;?></td>
			<td id="tab2" nowrap="nowrap" class="offtab" onclick="dhtml.cycleTab(this.id)"><?php echo _RSGALLERY_TAB2_SETTINGS;?></td>
			<td id="tab3" nowrap="nowrap" class="offtab" onclick="dhtml.cycleTab(this.id)"><?php echo _RSGALLERY_TAB3_SETTINGS;?></td>
			<td id="tab4" nowrap="nowrap" class="offtab" onclick="dhtml.cycleTab(this.id)"><?php echo _RSGALLERY_TAB4_SETTINGS;?></td>
			<td width="50%" class="tabpadding">&nbsp;</td>
		</tr>
		</table>

		<div id="page1" class="pagetext">
		<table width="100%" border="0" cellpadding="4" cellspacing="2" class="adminForm">
		<tr>
			<td>
				<table border="0" width="100%">
				<tr>
					<td width="200" valign="top"><?php RSToolTip(_RSGALLERY_THUMB_GEN, "This is the part where I tell you about the great possibilities in choosing different kinds of Thumbnail creation.");echo _RSGALLERY_THUMB_GEN;?>:</td>
					<td width="100" valign="top">
					<select name="conversiontype" size="5">
						<option value="0"<?php if ($conversiontype == 0) echo " selected";?>>Manual Upload</option>
						<option value="1"<?php if ($conversiontype == 1) echo " selected";?>>ImageMagick</option>
						<option value="2"<?php if ($conversiontype == 2) echo " selected";?>>NETPBM</option>
						<option value="3"<?php if ($conversiontype == 3) echo " selected";?>>GD1</option>
						<option value="4"<?php if ($conversiontype == 4) echo " selected";?>>GD2</option>
					</select>
					</td>
                    <td valign="top" style='color:green;font-weight:bold;text-align:left;'>
                        <br />
                        <?php if(array_key_exists('imagemagick',$imageLibs)) {echo _RSGALLERY_AUTO_DETECTED . $imageLibs['imagemagick']; } ?><br />
                        <?php If(array_key_exists('netpbm',$imageLibs)) {echo _RSGALLERY_AUTO_DETECTED . $imageLibs['netpbm']; } ?><br />
                        <?php If(array_key_exists('gd1',$imageLibs)) {echo _RSGALLERY_AUTO_DETECTED . $imageLibs['gd1']; } ?><br />
                        <?php If(array_key_exists('gd2',$imageLibs)) {echo _RSGALLERY_AUTO_DETECTED . $imageLibs['gd2']; } ?><br />
                    </td>
				</tr>
				</table>
				<table border="0" width="100%">
				<tr>
					<td width="200" valign="top"><?php echo _RSGALLERY_THUMB_WIDTH;?>:</td>
					<td valign="top"><input type="text" name="size" size="4" maxlength="4" value="<?php echo $size;?>" /></td>
				</tr>
				<tr>
					<td width="200" valign="top"><?php echo _RSGALLERY_THUMB_QUAL;?>:</td>
					<td valign="top"><input type="text" name="JPEGquality" size="3" maxlength="3" value="<?php echo $JPEGquality;?>" /><strong>%</strong></td>
				</tr>
				<tr>
					<td width="200" valign="top"><?php echo _RSGALLERY_INLINE;?>:</td>
					<td valign="top">
					<select name="inline" size="2">
						<option value="0" <?php if ($inline == 0) echo "SELECTED";?>>Popup</option>
						<option value="1" <?php if ($inline == 1) echo "SELECTED";?>>Inline</option>
					</select>
					</td>
				</tr>
				<tr>
					<td width="200" valign="top"><?php echo _RSGALLERY_MAXWIDTHPOPUP;?>:</td>
					<td valign="top"><input type="text" name="MaxWidthPopup" size="4" maxlength="4" value="<?php echo $MaxWidthPopup;?>" /></td>
				</tr>
				<tr>
					<td width="200" valign="top"><?php echo _RSGALLERY_IMAGEPATH;?>:</td>
					<td valign="top">
						<input type="text" name="imagepath" value="<?php echo $imagepath;?>" size="45" />
					</td>
				</tr>
				<!-- BEGIN: Troozers Modification -->
				<tr>
					<td width="200" valign="top"><?php echo _RSGALLERY_FTPPATH;?>:</td>
					<td valign="top">
						<input type="text" name="FTP_path" value="<?php echo $FTP_path; ?>" size="45" />
					</td>
				</tr>
				<!-- END: Troozers Modification -->
				<tr>
					<td width="200" valign="top"><span style='width:180'><?php echo _RSGALLERY_NETPBMPATH;?>:</span><span style='width:20;text-align:right;vertical-align:top;color:red;font-weight:bold'>*</span></td>
					<td valign="top">
						<input type="text" name="NETPBM_path" value="<?php echo $NETPBM_path;?>" size="30" /><span style='vertical-align:top;'>&nbsp;(path should begin with drive letter like 'c:' for Windows)</span>
					</td>
				</tr>
				<tr>
					<td width="200" valign="top"><span style='width:180'><?php echo _RSGALLERY_IMAGEMAGICKPATH;?>:</span><span style='width:20;text-align:right;color:red;font-weight:bold'>*</span></td>
					<td valign="top">
						<input type="text" name="IM_path" value="<?php echo $IM_path;?>" size="30" /><span style='vertical-align:top;'>&nbsp;(path should begin with drive letter like 'c:' for Windows)</span>
					</td>
				</tr>
				<tr>
					<td colspan="2" valign="top" style='color:red'><br />* Note: Leave paths of auto-detected ImageMagick or NETPBM programs blank unless they are necessary to resolve problems
					</td>
				</tr>
				</table>
			</td>
		</tr>
		</table>
		</div>
		<div id="page2" class="pagetext">
		<table width="100%" border="0" cellpadding="4" cellspacing="2" class="adminForm">
		<tr>
			<td>
			<table width="100%">
			<tr>
					<td width="200" valign="top"><?php echo _RSGALLERY_NUMCOLUMNS;?>:</td>
					<td valign="top">
						<input type="text" name="columns" value="<?php echo $columns;?>" size="3" />
					</td>
				</tr>
				<tr>
					<td width="200" valign="top"><?php echo _RSGALLERY_NUMPICS;?>:</td>
					<td valign="top">
						<input type="text" name="PageSize" value="<?php echo $PageSize;?>" size="3" />
					</td>
				</tr>
				<tr>
					<td width="200" valign="top"><?php echo _RSGALLERY_PICWIDTH;?>:</td>
					<td valign="top">
						<input type="text" name="PicWidth" value="<?php echo $PicWidth;?>" size="4" />
					</td>
				</tr>
				<!-- BEGIN: Troozers Modification -->
				<tr>
					<td width="200" valign="top"><?php echo _RSGALLERY_RESIZEPIC;?>:</td>
					<td valign="top">
					<select name="ResizeOption" size="7">
						<option value="0" <?php if ($ResizeOption == 0) echo "selected";?>>No resizing</option>
						<option value="1" <?php if ($ResizeOption == 1) echo "selected";?>>Resize down only</option>
						<option value="2" <?php if ($ResizeOption == 2) echo "selected";?>>Resize up only</option>
						<option value="3" <?php if ($ResizeOption == 3) echo "selected";?>>Resize up and down</option>

						<option value="4" <?php if ($ResizeOption == 4) echo "selected";?>>Resize up on upload</option>
						<option value="5" <?php if ($ResizeOption == 5) echo "selected";?>>Resize down on upload</option>

						<option value="6" <?php if ($ResizeOption == 6) echo "selected";?>>Resize up and down on upload</option>
					</select>
					</td>
				</tr>
				<!-- END: Troozers Modification -->

				<tr>
					<td width="200" valign="top"><?php echo _RSGALLERY_FRONTMENU;?>:</td>
					<td valign="top">
					<select name="dropdown" size="4">
						<option value="0" <?php if ($dropdown == 0) echo "selected";?>>List</option>
						<option value="1" <?php if ($dropdown == 1) echo "selected";?>>Dropdown</option>
						<option value="2" <?php if ($dropdown == 2) echo "selected";?>>Master/detail</option>
						<option value="3" <?php if ($dropdown == 3) echo "selected";?>>Columns</option>
					</select>
					</td>
				</tr>
				<!--<tr>
					<td width="200" valign="top"><?php echo _RSGALLERY_SHOWDETAILS;?>:</td>
					<td valign="top">
					<select name="img_details" size="2">
						<option value="0" <?php if ($img_details == 0) echo "selected";?>>No</option>
						<option value="1" <?php if ($img_details == 1) echo "selected";?>>Yes</option>
					</select>
					</td>
				</tr>-->


				<!-- BEGIN : PDW 18-6-2004 -->



				<tr>
					<td colspan="2">
						<table cellpadding="0" cellspacing="0">
							<tr>
								<td>&nbsp;</td>
								<td width="50" align="left"><?php echo _RSGALLERY_NO;?></td>
								<td width="50" align="left"><?php echo _RSGALLERY_YES;?></td>
							</tr>
							<tr>
								<td width="200">Show random images</td>
								<td align="left"><input type="radio" name="displayRandom" value="0" <?php if ($displayRandom == 0) echo "checked";?> /></td>
								<TD align="left"><input type="radio" name="displayRandom" value="1" <?php if ($displayRandom == 1) echo "checked";?> /></td>
							</tr>
						</table>
					</td>
				</tr>

				<!-- BEGIN : PDW 21-8-2004 -->
				<tr>
					<td colspan="2">
						<table cellpadding="0" cellspacing="0">
							<tr>
								<td>&nbsp;</td>
								<td width="50" align="left"><?php echo _RSGALLERY_NO;?></td>
								<td width="50" align="left"><?php echo _RSGALLERY_YES;?></td>
							</tr>
							<tr>
								<td width="200">Show latest images</td>
								<td align="left"><input type="radio" name="displayLatest" value="0" <?php if ($displayRandom == 0) echo "checked";?> /></td>
								<TD align="left"><input type="radio" name="displayLatest" value="1" <?php if ($displayRandom == 1) echo "checked";?> /></td>
							</tr>
						</table>
					</td>
				</tr>
				<!-- END : PDW 21-8-2004 -->

				<tr>
					<td colspan="2">
						<table cellpadding="0" cellspacing="0">
							<tr>
								<td>&nbsp;</td>
								<td width="50" align="left"><?php echo _RSGALLERY_NO;?></td>
								<td width="50" align="left"><?php echo _RSGALLERY_YES;?></td>
							</tr>
							<tr>
								<td width="200">Show Image details (TAB 1)</td>
								<td align="left"><input type="radio" name="displayDesc" value="0" <?php if ($displayDesc == 0) echo "checked";?> /></td>
								<TD align="left"><input type="radio" name="displayDesc" value="1" <?php if ($displayDesc == 1) echo "checked";?> /></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<table cellpadding="0" cellspacing="0">
							<tr>
								<td>&nbsp;</td>
								<td width="50" align="left"><?php echo _RSGALLERY_NO;?></td>
								<td width="50" align="left"><?php echo _RSGALLERY_YES;?></td>
							</tr>
							<tr>
								<td width="200">Show Voting Details (TAB 2)</td>
								<td align="left"><input type="radio" name="displayVoting" value="0" <?php if ($displayVoting == 0) echo "checked";?> /></td>
								<td align="left"><input type="radio" name="displayVoting" value="1" <?php if ($displayVoting == 1) echo "checked";?> /></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<table cellpadding="0" cellspacing="0">
							<tr>
								<td>&nbsp;</td>
								<td width="50" align="left"><?php echo _RSGALLERY_NO;?></td>
								<td width="50" align="left"><?php echo _RSGALLERY_YES;?></td>
							</tr>
							<tr>
								<td width="200">Show Comment Details (TAB 3)</td>
								<td align="left"><input type="radio" name="displayComments" value="0" <?php if ($displayComments == 0) echo "checked";?> /></td>
								<TD align="left"><input type="radio" name="displayComments" value="1" <?php if ($displayComments == 1) echo "checked";?> /></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<table cellpadding="0" cellspacing="0">
							<tr>
								<td>&nbsp;</td>
								<td width="50" align="left"><?php echo _RSGALLERY_NO;?></td>
								<td width="50" align="left"><?php echo _RSGALLERY_YES;?></td>
							</tr>
							<tr>
								<td width="200">Show EXIF details (TAB 4)</td>
								<td align="left"><input type="radio" name="displayEXIF" value="0" <?php if ($displayEXIF == 0) echo "checked";?> /></td>
								<td align="left"><input type="radio" name="displayEXIF" value="1" <?php if ($displayEXIF == 1) echo "checked";?> /></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td width="200" valign="top"><?php echo _RSGALLERY_INTROTEXT;?>:</td>
					<td valign="top">
					<?php 
					// parameters : areaname, content, hidden field, width, height, rows, cols
					//editorArea( 'editor1',  $row->introtext , 'introtext', 500, 200, '70', '15' );

					// parameters : areaname, content, hidden field, width, height, rows, cols
					//editorArea( 'intro_text',  $intro_text , 'introtext', 500, '200', '50', '5' ) ; ?>
					<textarea cols="30" rows="5" name="intro_text"><?php echo htmlspecialchars(stripslashes($intro_text));?></textarea>
					</td>
				</tr>
			</table>
			</td>
		</tr>
		</table>
		</div>
		<div id="page3" class="pagetext">
		<table width="100%" border="0" cellpadding="4" cellspacing="2" class="adminForm">
		<tr>
			<td>
			<table width="100%">
                <tr align="center" valign="top">
                    <td align="left" valign="middle">
                            <textarea cols="100%" rows="20" name="conf_style"><?php echo $conf_style;?></textarea><br />
                    </td>
			    </tr>
			</table>
                    </td>
			    </tr>
		</table>
		</div>
		<div id="page4" class="pagetext">
		<table width="100%" border="0" cellpadding="4" cellspacing="2" class="adminForm">
		<tr>
			<td>
				<table border="0">
					<tr>
						<td width="200">&nbsp;</td>
						<td width="50" align="left"><?php echo _RSGALLERY_NO;?></td>
						<td width="50" align="left"><?php echo _RSGALLERY_YES;?></td>
					</tr>
					<tr>
						<td width="200">Enable User Uploads</td>
						<td align="left"><input type="radio" name="userupload" value="0" <?php if ($userupload == 0) echo "checked";?> /></td>
						<td align="left"><input type="radio" name="userupload" value="1" <?php if ($userupload == 1) echo "checked";?> /></td>
					</tr>
					<tr>
						<td width="200">&nbsp;</td>
						<td width="50" align="left"><?php echo _RSGALLERY_NO;?></td>
						<td width="50" align="left"><?php echo _RSGALLERY_YES;?></td>
					</tr>
					<tr>
						<td width="200">Only Registered users</td>
						<td align="left"><input type="radio" name="reg_upload" value="0" <?php if ($reg_upload == 0) echo "checked";?> /></td>
						<td align="left"><input type="radio" name="reg_upload" value="1" <?php if ($reg_upload == 1) echo "checked";?> /></td>
					</tr>
					<tr>
						<td width="200">&nbsp;</td>
						<td width="50" align="left"><?php echo _RSGALLERY_NO;?></td>
						<td width="50" align="left"><?php echo _RSGALLERY_YES;?></td>
					</tr>
					<tr>
						<td width="200">Allow user creation of categories</td>
						<td align="left"><input type="radio" name="user_cat" value="0" <?php if ($user_cat == 0) echo "checked";?> /></td>
						<td align="left"><input type="radio" name="user_cat" value="1" <?php if ($user_cat == 1) echo "checked";?> /></td>
					</tr>
					<tr>
						<td width="200"><?php echo _RSGALLERY_MAX_USERCAT;?></td>
						<td align="left" colspan="2"><input type="text" name="max_user_cat" value="<?php echo $max_user_cat;?>" size="4" />(0 is unlimited)</td>
					</tr>
					<tr>
						<td width="200"><?php echo _RSGALLERY_MAX_IMAGES;?></td>
						<td align="left" colspan="2"><input type="text" name="max_images" value="<?php echo $max_images;?>" size="4" />(0 is unlimited)</td>
					</tr>
				</table>
			</td>
		</tr>
		</table>
		</div>
		<script language="javascript" type="text/javascript">dhtml.cycleTab('tab1');</script>
		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		</form>
		<?php
   		}


function viewCategories( $rows, $pageNav, $option )
	{
	global $cid, $option;
	?>
	<form action="index2.php" method="post" name="adminForm">
	<table cellpadding="4" cellspacing="0" border="0" width="100%">
	<tr>
		<td width="100%" class="sectionname">View Categories</td>
		<td nowrap>Display #</td>
		<td><?php echo $pageNav->writeLimitBox(); ?></td>
	</tr>
	</table>
	<table cellpadding="4" cellspacing="0" border="0" width="100%" class="adminlist">
		<tr>
			<th width="20">#</th>
			<th width="20"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $rows ); ?>);" /></th>
			<th class="title">Category / Subcategory</td>
			<th><small>Published</small></td>
			<th><small>Public Access</small></td>
			<th colspan="2"><small>Reorder</small></th>
		</tr>
		<?php
		$k = 0;
		$i = 0;
		for ($i=0, $n=count( $rows ); $i < $n; $i++)
			{
			$row = $rows[$i];
			if($row->parent==0)
				{
				?>
				<tr bgcolor="#D4D4D4">
				<?php
				}
			else
				{
				?>
				<tr class="row<?php echo $k; ?>">
				<?php
				}
				?>
				<td width="20" align="right"><?php echo $i+$pageNav->limitstart+1;?></td>
				<td width="20"><input type="checkbox" id="cb<?php echo $i;?>" name="cid[]" value="<?php echo $row->id; ?>" onClick="isChecked(this.checked);" /></td>
				<td width="70%"><a href="index2.php?option=com_rsgallery&task=edit_category&amp;cid=<?php echo $row->id;?>"><?php echo ($row->category ? "<img src=\"components/com_rsgallery/images/sub_arrow.png\" alt=\"\" border=\"0\">$row->category/$row->catname" : "$row->catname"); ?></a></td>
				<?php
				$task = $row->published ? 'unpublish' : 'publish';
				$img = $row->published ? 'publish_g.png' : 'publish_x.png';
				if ($row->user==0)
					{
					$groupname='Public';
					}
				else
					{
					$groupname='Private';
					}
				?>
				<td width="10%" align="center"><a href="javascript: void(0);" onclick="return listItemTask('cb<?php echo $i;?>','<?php echo $task;?>')"><img src="images/<?php echo $img;?>" width="12" height="12" border="0" alt="" /></a></td>
				<td width="" align="center"><?php echo $groupname;?></td>
				<td>
					<?php
					if ($i > 0 || ($i+$pageNav->limitstart > 0))
						{
						?>
						<a href="#reorder" onClick="return listItemTask('cb<?php echo $i;?>','orderup')">
						<img src="images/uparrow.png" width="12" height="12" border="0" alt="Move Up" />
						</a>
						<?php
						}
						?>
				</td>
				<td>
					<?php
					if ($i < $n-1 || $i+$pageNav->limitstart < $pageNav->total-1)
						{
						?>
						<a href="#reorder" onClick="return listItemTask('cb<?php echo $i;?>','orderdown')">
						<img src="images/downarrow.png" width="12" height="12" border="0" alt="Move Down" />
						</a>
						<?php
						}
						?>
				</td>
				<?php
				$k = 1 - $k;
				}?>
			</tr>
			<tr>
				<th align="center" colspan="12"><?php echo $pageNav->writePagesLinks(); ?></th>
			</tr>
			<tr>
				<td align="center" colspan="12"><?php echo $pageNav->writePagesCounter(); ?></td>
			</tr>
		</table>
		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
	</form>
	<?php
	}

        /**
        * This function is used to present the appropriate interface to either add a new gallery category, or edit an existing one.
        * In the case where $rows has no entries, a new category is being created.
        **/
	function newCategory($option, $rows)
		{
		global $database, $option, $task, $rows, $id, $descr, $catname, $parent, $publ, $show_full_description, $published;

        // Make sure variables are initialized to appropriate defaults.
		$catname = "";
		$descr = "";
		$p_id = 0;
		$published = False;
		$show_full_description = True;

		if ($rows)
			{
			foreach($rows as $row)
				{
				$catname = $row->catname;
				$descr = $row->description;
				$id = $row->id;
				$p_id = $row->parent;
				$published = $row->published;
				$show_full_description = $row->show_full_description;
				}
			}
		?>
                <script>
                function submitbutton(pressbutton){
                    if (pressbutton != 'cancel'){
                        submitform( pressbutton );
                        return;
                    } else {
                        window.history.go(-1);
                        return;
                    }
                }
                </script>
		<table cellpadding="4" cellspacing="0" border="0" width="100%">
    		<tr>
      			<td width="100%"><span class="sectionname"><?php echo _RSGALLERY_NEWCAT;?></span></td>
    		</tr>
  		</table>
		<table cellpadding="4" cellspacing="1" border="0" width="100%" class="adminform">
		<form action="index2.php" method="post" name="adminForm" id="adminForm">
		<input type="hidden" name="id" value="<?php echo $id;?>" />
			<tr>
				<td width="20%" align="right"><?php echo _RSGALLERY_CATLEVEL;?>:</td>
				<td width="80%">
					<select name="parent" size="1">
					<!--<option value="0">- Top category -</option>-->
					<?php //echo showParentCat($p_id);?>
					<?php echo showCategories2($p_id);?>
					</select>
				</td>
			</tr>
			<tr>
				<td width="20%" align="right"><?php echo _RSGALLERY_CATNAME;?>:</td>
				<td width="80%">
					<input class="inputbox" type="text" name="catname" size="50" maxlength="100" value="<?php echo htmlspecialchars(stripslashes($catname));?>" />
				</td>
			</tr>
			<tr>
				<td valign="top" align="right"><?php echo _RSGALLERY_CATDESCR;?>:</td>
				<td>
					<textarea class="inputbox" cols="50" rows="5" name="descr" style="width:500px" width="500"><?php echo htmlspecialchars(stripslashes($descr));?></textarea>
				</td>
			</tr>
			<tr>
				<td width="20%" align="right"><?php echo _RSGALLERY_SHOWFULLDESC;?>:</td>
				<td width="80%"><input type="checkbox" value="1" name="show_full_description" <?php if ($show_full_description == 1) echo "checked";?> /></td>
			</tr>

			<tr>
				<td width="20%" align="right">Published:</td>
				<td width="80%"><input type="checkbox" value="1" name="publ" <?php if ($published == 1) echo "checked";?> /></td>
			</tr>
		</table>
		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		</form>
		<?php
		}


	function showUpload()
		{
		global $catid, $submit, $database, $uploads, $rows, $conversiontype;
		?>

                <script>
                function submitbutton(pressbutton){
                    if (pressbutton != 'cancel'){
                        submitform( pressbutton );
                        return;
                    } else {
                        window.history.go(-1);
                        return;
                    }
                }
                </script>

		<table width="100%">
			<tr>
				<td class="sectionname"><?php echo _RSGALLERY_UPLOAD_TITLE ;?></td>
			</tr>
		</table>

		<table class="adminForm" width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
		 <tr>
		 	<td colspan="2">&nbsp;</td>
		 </tr>
		<tr>
			<td align="left">&nbsp;<?php echo _RSGALLERY_UPLOAD_NUMBER ;?></td>
			   <td>
              <form name="selection" method="post" action="index2.php?option=com_rsgallery&task=upload">
                <select name="uploads" size="1" onchange="this.form.submit();">
						<option value="1" selected>--</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                  <option value="8">8</option>
                  <option value="9">9</option>
                  <option value="10">10</option>
                  <option value="15">15</option>
                  <option value="20">20</option>
                </select>
		</form><br />
			</td>
		</tr>
         <form action="index2.php?option=com_rsgallery&task=upload" method="post" enctype="multipart/form-data">
		<tr>
			<td>&nbsp;<?php echo _RSGALLERY_FORM_INGALLERY; ?>:</td>
			<td>
				<select name="catid">
					<option value="">---&nbsp;<?php echo _RSGALLERY_PICK;?>&nbsp;---</option>
          <?php
		  foreach ($rows as $row)
		  	{
               ?>
          <option value="<?php echo $row->id;?>"><?php echo htmlspecialchars(stripslashes($row->catname));?></option>
          <?php
               }
            ?>
				</select>
			</td>
		</tr>
		<tr>
			<td colspan="2"><hr width="100%" size="1" /></td>
    		</tr>
    <?php
   for ( $t=1; $t < ($uploads+1); $t++)
      {
      ?>
		<tr>
				<td colspan="2">
					<table width="100%" border="0" cellpadding="1" cellspacing="1">
					<tr>
						<td valign="top" width="100"><?php echo _RSGALLERY_UPLOAD_FORM_TITLE." ".$t; ?>:</td>
						<td>
							<input name="title2[]" type="text" class="inputbox" size="40" />
						</td>
					</tr>
					<tr>
						<td valign="top"><?php echo _RSGALLERY_UPLOAD_FORM_FILE." ".$t; ?>:</td>
						<td><input class="inputbox" name="image[]" type="file" size="30" /></td>
					</tr>
          <?php
      if ($conversiontype == 0)
         {
         ?>
					<tr>
						<td valign="top"><?php echo _RSGALLERY_UPLOAD_FORM_THUMB." ".$t; ?>:</td>
						<td><input class="inputbox" name="thumb[]" type="file" size="30" /></td>
					</tr>
          <?php
         }
      ?>
					<tr>
						<td valign="top"><?php echo _RSGALLERY_DESCR." ".$t; ?></td>
						<td><textarea class="inputbox" cols="35" rows="3" name="descr[]"></textarea></td>
					</tr>
					<tr>
						<td colspan="2"><hr width="100%" size="1"></td>
					</tr>
					</table>
        <?php
      }
      ?>
				</td>
			</tr>
			<tr>
				<td colspan="2" align="center"><input class="button" type="submit" name="submit" value="Upload" /><br />(<font color="#FF0000"><?php echo _RSGALLERY_UPLOAD_BUTTON_DESC;?></font>)</td>
			</tr>
  			</table>
   </form>
   <?php
   }


	function viewImages( $option, &$rows, &$clist, &$clist2, &$search, &$pageNav , &$cats, &$cat_ordering_min, &$cat_ordering_max)
		{
		global $e_id, $my, $catid, $mosConfig_live_site, $mosConfig_absolute_path;
        include ($mosConfig_absolute_path."/administrator/components/com_rsgallery/settings.rsgallery.php");
?>
                <div id="overDiv" style="position:absolute; visibility:hidden; z-index:1000;"></div>
                <script language="Javascript" src="../includes/js/overlib_mini.js"></script>
                <script language="Javascript">
                function submitbutton(pressbutton){
                    if (pressbutton != 'cancel'){
                        submitform( pressbutton );
                        return;
                    } else {
                        window.history.go(-1);
                        return;
                    }
                }
				// following overlib functions are redefined with a kludge added to
				// hide any overlapping form select fields that may be under the overlay window
				// for IE.  The existing JSCookMenu functions are called to support this.
				if(document.all) var divref=oframe.document.all['overDiv'];
				function showObject(obj){
					if(ns4)obj.visibility="show";
					else if(ie4)obj.visibility="visible";
					else if(ns6)obj.style.visibility="visible";
					if (document.all){
					    divref.cmOverlap = new Array ();
						cmHideControl ('SELECT', divref);
                    }
				}
				function hideObject(obj){
					if(ns4)obj.visibility="hide";
					else if(ie4)obj.visibility="hidden";
					else if(ns6)obj.style.visibility="hidden";
					if(otimerid > 0)clearTimeout(otimerid);
					if(odelayid > 0)clearTimeout(odelayid);
					otimerid=0;
					odelayid=0;
					self.status="";
				    if (document.all){
				        cmShowControl(divref);
                    }
				}
				var overlibTable = new Array();

				<?php
				// dmcd  mar 5/04 create overlay html tables in javascript variables to avoid an issue
				// with javascript function argument length

				$overlayWidth=max(intval($size)+15, 175);
				for ($i=0, $n=count( $rows ); $i < $n; $i++){
					$row = $rows[$i];
					echo "overlibTable[" . ($i+1) . '] = "<table style=\"width:' . $overlayWidth . 'px;background-color:#444444; border:solid black;\" class=\"galThumbOverlay\">' .
					'<tr><td align=\"center\"><img src=\"' .
					$mosConfig_live_site.$imagepath.'thumbs/'.$row->name .'\" /></td></tr>"'."\n".
					'+ "<tr><td style=\"color:white;\"><b>Title:</b> '. htmlspecialchars(stripslashes($row->title), ENT_QUOTES) .'</td></tr>"'."\n".
					'+ "<tr><td style=\"color:white;\"><b>File Name:</b> '. $row->name .'</td></tr>'.
					'<tr><td style=\"color:white;\"><b>File Date:</b> '. $row->date .'</td></tr>"'."\n".
					'+ "<tr><td style=\"color:white;\"><b>Description:</b> <span style=\"font-style:italic;\">'. htmlspecialchars(stripslashes($row->descr), ENT_QUOTES).'</span></td></tr>'.
					'</table>";'."\n\n";
				}
				?>
                </script>
		<br />
		<form action="index2.php" method="post" name="adminForm">
		<table cellpadding="4" cellspacing="0" border="0" width="100%">
		<tr>
			<td style='width:40px;'>&nbsp;</td>
			<td>
				<input type="button" name="delete" value="<?php echo _RSGALLERY_DELETE ?>" class="button"
				   onClick="if (document.adminForm.boxchecked.value == 0){ alert('Please make a selection from the list to delete'); } else if (confirm('Are you sure you want to delete selected items? ')){ submitbutton('delete_image');}" />
			</td>
			<td width="10%"></td>
			<td>
				<input type="button" name="moveto" value="<?php echo _RSGALLERY_MOVETO ?>" class="button"
				   onClick="if (document.adminForm.boxchecked.value == 0){ alert('Please make a selection from the list to move'); } else if (document.adminForm.catmoveid.value==0) { alert('Please make a category selection from the list to move images to'); }else if (confirm('Are you sure you want to move selected items? ')){ submitbutton('move_image');}" />
			</td>
			<td>
				<?php echo $clist2;?>
            </td>
			<td width="100%" class="sectionname">&nbsp;
			</td>
			<td nowrap="nowrap"><?php echo _RSGALLERY_NUMDISPLAY;?></td>
			<td>
				<?php echo $pageNav->writeLimitBox(); ?>
			</td>
			<td><?php echo _RSGALLERY_SEARCH;?>:</td>
			<td>
				<input type="text" name="search" value="<?php echo htmlspecialchars(stripslashes($search), ENT_QUOTES);?>" class="inputbox" onChange="document.adminForm.submit();" />
			</td>
			<td width="right">
				<?php echo $clist;?>
			</td>
		</tr>
		</table>

		<table cellpadding="4" cellspacing="0" border="0" width="100%" class="adminlist">
			<tr>
                <th width="20">#</th>
				<th width="20">
					<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $rows ); ?>);" />
				</th>
				<th class="title" width="25%" nowrap="nowrap"><?php echo _RSGALLERY_IMAGENAME;?></th>
				<th width="25%" align="left" nowrap="nowrap"><?php echo _RSGALLERY_IMAGEFILE;?></th>
				<th width="15%" align="left" nowrap="nowrap"><?php echo _RSGALLERY_IMAGECAT;?></th>
				<th width="10%" nowrap="nowrap"><?php echo _RSGALLERY_IMAGEHITS;?></th>
				<th width="20%" nowrap="nowrap"><?php echo _RSGALLERY_IMAGEDATE;?></th>
                <th colspan="2"><?php echo _RSGALLERY_REORDER;?></th>
			</tr>
		<?php
		$k = 0;
		for ($i=0, $n=count( $rows ); $i < $n; $i++)
			{
			//asdbg_break();
			$row = &$rows[$i];
			?>
			<tr class="<?php echo "row$k"; ?>">
                                <td width="20"><?php echo $i + 1 + $pageNav->limitstart;?></td>
				<td width="20">
				<input type="checkbox" id="cb<?php echo $i;?>" name="cid[]" value="<?php echo $row->xid; ?>" onclick="isChecked(this.checked);" />
				</td>
				<td width="25%">
					<a href="index2.php?option=com_rsgallery&task=edit_image&e_id=<?php echo $row->xid;?>" 
					   onmouseover='return overlib(overlibTable[<?php echo $i+1; ?>],FULLHTML, VAUTO, DELAY, 700);'
					   onmouseout="return nd();"><?php echo $row->title;?></a>
				</td>
				<td width="25%"><?php echo $row->name; ?></td>
				<td width="15%"><?php echo  htmlspecialchars(stripslashes($row->catname), ENT_QUOTES); ?></td>
				<td width="10%" align="center"><?php echo $row->ahits;?></td>
				<td width="20%" align="center"><?php echo $row->date;?></td>
                                <td>
<?php
//asdbg_break();
if ($row->fordering > $cat_ordering_min[$row->gallery_id]) { ?>
				    <a href="#reorder" onclick="return listItemTask('cb<?php echo $i;?>','images_orderup')">
                                        <img src="images/uparrow.png" width="12" height="12" border="0" alt="Move Up" />
				    </a>
<?php		} else { ?>
			&nbsp;
<?php		} ?>
				</td>
				<td>
<?php		if ($row->fordering < $cat_ordering_max[$row->gallery_id]) { ?>
				    <a href="#reorder" onclick="return listItemTask('cb<?php echo $i;?>','images_orderdown')">
					<img src="images/downarrow.png" width="12" height="12" border="0" alt="Move Down" />
				    </a>
<?php		} else { ?>
			&nbsp;
<?php		} ?>
				</td>
<?php
				$k = 1 - $k;
				}//End for ?>
			</tr>
			<tr>
				<th align="center" colspan="9">
					<?php echo $pageNav->writePagesLinks(); ?></th>
			</tr>
			<tr>
				<td align="center" colspan="9">
					<?php echo $pageNav->writePagesCounter(); ?></td>
			</tr>
		</table>
		<input type="hidden" name="option" value="<?php echo $option;?>" />
		<input type="hidden" name="task" value="view_images" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="catChanged" value="0" />
		</form>

        <script language="Javascript">
        // preload all the thumb images for the overlay frame
		var image = new Array();

		function setImageLoaded(){
		    this.loaded=1;
		    return;
		}
		<?php
		for ($i=0, $n=count( $rows ); $i < $n; $i++){
        	$row = &$rows[$i];
            echo "image[".$i."] = new Image();\n";
		    echo "image[".$i."].loaded = 0;\n";
		    echo "image[".$i."].onLoad = setImageLoaded();\n";
            echo "image[".$i."].src = \"".$mosConfig_live_site.$imagepath."thumbs/".$row->name."\";\n";
			}
		?>
		</script>
<?php
	}

	}//end class
?>
