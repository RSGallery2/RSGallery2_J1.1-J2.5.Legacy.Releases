<?php
// $Id: toolbar.rsgallery.html.php,v 1.1 2005/04/22 15:04:11 richardjfoster Exp $
/**
* Weblink Toolbar Menu HTML
* @package Mambo Open Source
* @Copyright (C) 2000 - 2003 Miro International Pty Ltd
* @ All rights reserved
* @ Mambo Open Source is Free Software
* @ Released under GNU/GPL License: http://www.gnu.org/copyleft/gpl.html
* @version $Revision: 1.1 $
**/

// ensure this file is being included by a parent file
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class menuRSGallery {

	function NEW_MENU()
		{
		mosMenuBar::startTable();
		mosMenuBar::save();
		mosMenuBar::cancel();
		mosMenuBar::spacer();
		mosMenuBar::endTable();
		}

	function EDIT_MENU()
		{
		mosMenuBar::startTable();
		mosMenuBar::save('save_image');
		mosMenuBar::cancel();
		mosMenuBar::back();
		mosMenuBar::spacer();
		mosMenuBar::endTable();
		}
	
	function UPLOAD_MENU()
		{
		mosMenuBar::startTable();
		mosMenuBar::save('upload');
		mosMenuBar::cancel();
		mosMenuBar::spacer();
		mosMenuBar::endTable();
		}
	
	function VIEW_IMAGES_MENU()
		{
		mosMenuBar::startTable();
		mosMenuBar::addNew('upload');
		mosMenuBar::editList('edit_image');
		mosMenuBar::deleteList( '', 'delete_image', 'Delete Image' );
		mosMenuBar::spacer();
		mosMenuBar::endTable();
		}
		
	function VIEW_CAT_MENU()
		{
		mosMenuBar::startTable();
		mosMenuBar::addNew('new_category');
		mosMenuBar::editList('edit_category');
		mosMenuBar::deleteList();
		mosMenuBar::cancel();
		mosMenuBar::spacer();
		mosMenuBar::endTable();
		}
	
	function NEWCAT_MENU()
		{
		mosMenuBar::startTable();
		mosMenuBar::save('save_category');
		mosMenuBar::cancel();
		mosMenuBar::spacer();
		mosMenuBar::endTable();
		}
		
	function EDITCAT_MENU()
		{
		mosMenuBar::startTable();
		mosMenuBar::save('save_category');
		mosMenuBar::cancel();
		mosMenuBar::spacer();
		mosMenuBar::endTable();
		}
		
	function SETTINGS_MENU()
		{
		mosMenuBar::startTable();
		mosMenuBar::save('save_config');
		mosMenuBar::cancel();
		mosMenuBar::spacer();
		mosMenuBar::endTable();
		}

	function DEFAULT_MENU()
		{
		mosMenuBar::startTable();
		mosMenuBar::addNew();
		mosMenuBar::editList();
		mosMenuBar::deleteList();
		mosMenuBar::spacer();
		mosMenuBar::endTable();
		}
}
?>