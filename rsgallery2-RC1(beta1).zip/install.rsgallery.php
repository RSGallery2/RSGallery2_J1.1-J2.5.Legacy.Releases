<?php
/**
* This file handles installation of RSGallery.
*
* @version $ 2.0 RC-1 $
* @package RSGallery_2.0
* @copyright (C) 2003 - 2004 RSDevelopment
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* RSGallery is Free Software
**/

function setDirPermsOnGallery($dir, &$warning_num){

	global $ftpIsAvailable, $ftpUse;

	if(file_exists($dir)){
		if(is_dir($dir)){
			// check for correct permissions on the dir
			@chmod($dir, 0777);
			if((fileperms($dir) & 0777) != 0777){
				// can't change file perms, so see if
				// safemode patch installed and try it thru
				// ftp assist
				if(isset($ftpIsAvailable) && $ftpIsAvailable && $ftpUse && function_exists('chmodDir'))
					chmodDir($dir, '777');
			}
			if(fileperms($dir) & 0777 != 0777){
				// issue warning about not being able to change gallery dir perms to 777
				// this may or may NOT be a problem.  Let user decide.
				$warning_num = 2;
				return false;
			} else return true;

		} else {
			// existing gallery is a file rather than a directory
			// needs to be corrected by user first
			$warning_num = 1;
			return false;
		}
	}
	return true;
}

function com_install()
	{
	require_once("../configuration.php");
	global $mosConfig_absolute_path, $ftpIsAvailable, $ftpUse;
	$galleryDir = $mosConfig_absolute_path.'/images/gallery';
	$thumbsDir = $galleryDir.'/thumbs';
	$warning=false;
	
	// now check if there actually IS an existing gallery dir.  Perms should be
	// fixed by now.  If there is and we are running in safemode, then ownership
	// of the directory must be the ftp user.

	// for safemode, we compare file ownership to the mambo 'components' subdirectory
	// since if this is a successful and running MOS safemode installation, the
	// ownership of this subdirectory must be the FTP client id for this host.
	
	if(file_exists($galleryDir) && !is_dir($galleryDir))
		{
		// existing file with same name as gallery. Needs to be deleted by user
	   	echo "<p>Warning!  You already have an existing file with the name 'gallery' in the".
		   " MOS 'images' subdirectory.  This file will need to be deleted or renamed, and the ".
		   "$galleryDir subdirectory and its $thumbsDir subdirectory created manually ".
		   "using your host FTP client before the gallery can be used.</p>";
			echo "<p><b>RSGallery Installed With Warning!</b></p>";
			return;
		}
	elseif (is_dir($galleryDir))
		{
		echo "<p>Detected existing Gallery directory: <strong>$galleryDir</strong>.</p>";
		if(ini_get('safe_mode') && fileowner($galleryDir) != fileowner($mosConfig_absolute_path.'/components'))
			{
	    	// error, existing gallery directory ownership must be changed
	    	// we will not even be able to read this directory beyond this point
	    	echo "<p>Warning!  You already have an existing Gallery directory ($galleryDir) that is not of the".
				" correct <b>file ownership</b>.  Since this host is running with <b>SafeMode</b> enabled, ".
				"all directories must be created and owned by the FTP host client id.  You will need" .
				" to delete or rename this existing directory, or correct the file ".
				" ownership issue before RSGallery will function correctly.</p>";
			echo "<p><b>RSGallery Installed With Warning!</b></p>";
			return;
			}
			// correct the permissions if we can on the existing gallery directory
			if(!setDirPermsOnGallery($galleryDir, $warning_num))
				{
				// could not set correct perms on an existing gallery dir
	    		echo "<p>Warning!  Could not set the correct permissions of '777' on the $galleryDir ".
					"subdirectory.  Permissions are currently set at: ". decoct(fileperms($galleryDir)).".".
					"  Please rectify this if deemed necessary before using RSGallery.</p>";
				$warning = true;
				}
			// check for thumbs subdirectory
			if(file_exists($thumbsDir) && !is_dir($thumbsDir))
				{
				// existing file with same name as thumbs subdir. Needs to be deleted by user
	   			echo "<p>Warning!  You already have an existing file with the name 'thumbs' in the".
				   " $galleryDir subdirectory.  This file will need to be deleted or renamed, and the ".
		   			"$thumbsDir subdirectory created manually ".
		   			"using your host FTP client before the RSGallery can be used.</p>";
					echo "<p><b>RSGallery Installed With Warning!</b></p>";
				return;
				}
			elseif (is_dir($thumbsDir))
				{
				echo "<p>Detected existing Gallery thumbs subdirectory: <strong>$thumbsDir</strong>.</p>";
				if(ini_get('safe_mode') && fileowner($thumbsDir) != fileowner($mosConfig_absolute_path.'/components'))
					{
	    			// error, existing thumbs directory ownership must be changed
	    			echo "<p>Warning!  You already have an existing thumbs subdirectory $thumbsDir that is not of the".
					" correct <b>file ownership</b>.  Since this host is running with <b>SafeMode<b> enabled, ".
					"all directories must be created and owned by the FTP host client id.  You will need" .
					" to delete or rename this existing subdirectory, or correct the file " .
					" ownership issue before RSGallery will function correctly.</p>";
					echo "<p><b>RSGallery Installed With Warning!</b></p>";
					return;
					}
			// correct the permissions if we can and need to on the existing thumbs directory
			if(!setDirPermsOnGallery($thumbsDir, $warning_num)){
				// could not set correct perms on an existing thumbs subdir
	    		echo "<p>Warning!  Could not set the correct permissions of '777' on the $thumbsDir ".
					"subdirectory.  Permissions are currently set at: ". decoct(fileperms($thumbsDir)).".".
					"  Please rectify this if deemed necessary before using RSGallery.</p>";
				$warning=true;
			}
		} elseif(!file_exists($thumbsDir)){
			// no thumbs subdirectory.  Could be an old RSGallery format
			// go create a subdirectory
			if(isset($ftpIsAvailable) && $ftpIsAvailable && function_exists('makeDir') && $ftpUse)
				makeDir($thumbsDir, 0777);
			else
				@mkdir($thumbsDir, 0777);
			if(!file_exists($thumbsDir)){
				// error, directory not created
	    		echo "<p>Warning!  Cannot create the $thumbsDir subdirectory for unknown ".
				"reasons.  Please create this subdirectory manually thru your host FTP client ".
				"before using RSGallery.</p>";
				echo "<p><b>RSGallery Installed With Warning!</b></p>";
				return;
			} elseif ((fileperms($thumbsDir) & 0777) != 0777){
				// error, permissions are incorrect
	    		echo "<p>Warning!  Could not set the correct permissions of '777' on the $thumbsDir ".
					"subdirectory.  Permissions are currently set at: ". decoct(fileperms($thumbsDir)).".".
					"  Please rectify this if deemed necessary before using RSGallery.</p>";
				$warning=true;
			}
			// success!  thumbsDir created.
			echo "Created gallery thumbs subdirectory <strong>$thumbsDir</strong>... <b>OK</b><br />";
			echo "<p><b>RSGallery Installed" . ($warning ? " with Warnings" : " Successfully") ."!</b></p>";
			return;
		}

	}

	// If we get here, then there is no existing gallery directory.  Fresh install.

	if(isset($ftpIsAvailable) && $ftpIsAvailable && function_exists('makeDir') && $ftpUse){
		makeDir($galleryDir, 0777);
		makeDir($thumbsDir, 0777);
	} else {
		@mkdir($galleryDir, 0777);
		@mkdir($thumbsDir, 0777);
	}

	// Now do a final check to see if the gallery directory and thumbs subdir now exist with the proper
	// permissions

	if(!is_dir($galleryDir)){
	    echo "<p>Warning!  Cannot create the $galleryDir subdirectory for unknown ".
			"reasons.  Please create this subdirectory and the $thumbsDir manually thru your host FTP client ".
			"before using RSGallery.</p>";
		echo "<p><b>RSGallery Installed With Warning!</b></p>";
		return;
	} elseif(is_dir($galleryDir) && (fileperms($galleryDir) & 0777) != 0777){
	    echo "<p>Warning!  Created directory $galleryDir, but could not set the correct ".
			"permissions of '777'.  Permissions are currently set at: ". decoct(fileperms($galleryDir)).".".
			"  Please rectify this if deemed necessary before using RSGallery.</p>";
				$warning=true;
	}
	if(!is_dir($thumbsDir)){
	    echo "<p>Warning!  Cannot create the $thumbsDir subdirectory for unknown ".
			"reasons.  Please create this subdirectory manually thru your host FTP client ".
			"before using RSGallery.</p>";
		echo "<p><b>RSGallery Installed With Warning!</b></p>";
		return;
	} elseif(is_dir($thumbsDir) && (fileperms($thumbsDir) & 0777) != 0777){
	    echo "<p>Warning!  Created directory $thumbsDir, but could not set the correct ".
			"permissions of '777'.  Permissions are currently set at: ". decoct(fileperms($thumbsDir)).".".
			"  Please rectify this if deemed necessary before using RSGallery.</p>";
		$warning=true;
	}
	echo "<p><b>RSGallery Installed" . ($warning ? " with Warnings" : " Successfully") ."!</b></p>";
	?>
	<div align="center">Part one of the installation is finished.<br/>Please go to<br/><a href="index2.php?option=com_rsgallery&amp;task=install"><h2>Step 2</h2></a></div>
	<?php
}

function deleteTables($tablename)
	{
	global $database, $mosConfig_db, $tablename;
	$table_list = mysql_list_tables($mosConfig_db);
	while($result = mysql_fetch_row($table_list))
		{
		$array[] .= $result[0];
		}
	if (in_array($tablename, $array))
		{
		$sql = "DROP TABLE `$tablename`";
		$database->setQuery($sql);
		if ($database->query())
			{
			echo "<strong>$tablename</strong> deleting..........<font color=\"#008000\">OK</font><br/>";
			}
		else
			{
			echo "<strong>$tablename</strong> deleting..........<font color=\"#FF0000\">ERROR</font><br/>".mysql_error().$sql."<BR/>";
			}
		}
	else
		{
		echo "<strong>$tablename</strong> is not in database<BR/>";
		}
	}

function FreshInstall()
	{
	global $database, $tablename;
	$check_tables = array("#__rsgallery","#__rsgalleryfiles","#__rsgallery_comments");

	echo "<table width=\"400\" class=\"adminForm\"><tr><td class=\"sectionname\"><h2>Fresh install</h2></td></tr><tr><td>";
	foreach($check_tables as $tablename)
		{
		deleteTables($tablename);
		}
	echo "<BR/><BR/>Creating new tables............<BR/><BR/>";
	//SQL statements for new tables

	//PDW 22-7-2004
	//user should be type. Types can be site (0), user (1), filter (2)
	//uid should be owner_id
	//parent should be parent_id

	$sql1 = "CREATE TABLE `#__rsgallery` (".
  		" `id` int(9) unsigned NOT NULL auto_increment,".
		" `catname` varchar(50) default '0',".
		" `description` blob,".
		" `hits` int(11) unsigned NOT NULL default '0',".
		" `published` tinyint(1) unsigned NOT NULL default '1',".
		" `total` int(11) unsigned NOT NULL default '0',".
		" `ordering` int(11) unsigned NOT NULL default '0',".
		" `uid` int(11) unsigned NOT NULL default '0', ".
		" `allowed` varchar(100) NOT NULL default '0',".
		" `show_full_description` int(1) NOT NULL default '0',".
		" `parent` int(9) NOT NULL default '0',".
 		" `user` tinyint(4) NOT NULL default '0',".
		" PRIMARY KEY  (`id`),".
		" KEY `id` (`id`)".
		" ) TYPE=MyISAM;";

	//PDW 18-6-2004 PDW
	//name has extra unique key
	$sql2 = "CREATE TABLE `#__rsgalleryfiles` (".
		" `id` int(9) unsigned NOT NULL auto_increment,".
		" `name` varchar(100) NOT NULL default '',".
		" `descr` blob,".
		" `gallery_id` int(9) unsigned NOT NULL default '0',".
		" `title` varchar(50) NOT NULL default '',".
		" `hits` int(11) unsigned NOT NULL default '0',".
		" `date` datetime NOT NULL default '0000-00-00 00:00:00',".
		" `rating` int(10) unsigned NOT NULL default '0',".
		" `votes` int(10) unsigned NOT NULL default '0',".
		" `comments` int(10) unsigned NOT NULL default '0',".
		" `ordering` int(9) unsigned NOT NULL default '0',".
		" `approved` tinyint(1) unsigned NOT NULL default '0',".
		" PRIMARY KEY  (`id`),".
		"  UNIQUE KEY `UK_name` (`name`),".
		" KEY `id` (`id`)".
		") TYPE=MyISAM;";

	$sql3 = "CREATE TABLE `#__rsgallery_comments` (".
		" `id` int(9) unsigned NOT NULL auto_increment,".
		" `picid` int(9) unsigned NOT NULL default '0',".
		" `name` varchar(50) NOT NULL default '',".
		" `comment` blob NOT NULL,".
		" `date` datetime NOT NULL default '0000-00-00 00:00:00',".
		" PRIMARY KEY  (`id`),".
		" KEY `id` (`id`)".
		") TYPE=MyISAM;";
	$database->setQuery($sql1);
	$database->query();
	$database->setQuery($sql2);
	$database->query();
	$database->setQuery($sql3);
	$database->query();
	echo "Tables created...............<font color=\"#008000\">OK</font><br/>";
	echo "</td></tr></table>";
	echo "You can start using RSGallery by going to <strong>Components->RSGallery->Settings</strong><br/>";
	echo "If you have any questions, please visit http://mamboforge.net/projects/rsgallery2. From there you can visit the manual<br/>";
	echo "<h2><a href=\"index2.php?option=com_rsgallery&amp;task=settings\">Goto RSGallery settings</a></h2>";
	}

function Upgrade()
	{
	global $database;
	echo "<table width=\"500\" class=\"adminForm\"><tr><td class=\"sectionname\"><h2>Upgrade</h2></td></tr><tr><td>";
	$sql1 = "ALTER TABLE #__rsgallery ".
		"ADD `uid` int(11) unsigned NOT NULL default '0',".
		"ADD `user` tinyint(4) unsigned NOT NULL default '0',".
		"ADD `parent` int(9) unsigned NOT NULL default '0',".
		"ADD `allowed` varchar(100) NOT NULL default '0',".
		"ADD `show_full_description` int(1) NOT NULL default '0',".
		"CHANGE `catname` catname varchar(50)";
	//PDW 18-6-2004
	//TODO unique key op naam nog toevoegen. Dit kan alleen fout gaan als er dubbele namen zijn. Wat dan?
	$sql2 = "ALTER TABLE #__rsgalleryfiles ".
		"ADD `approved` tinyint(1) unsigned NOT NULL default '0',".
		"CHANGE `name` name varchar(100)";
	$database->setQuery($sql1);
	if ($database->query())
		{
		$database->setQuery($sql2);
		if ($database->query())
			{
			echo "Upgrade completed...............<font color=\"#008000\">OK</font><br/><br/>";
			echo "</td></tr>";
			echo "<tr><td>You can start using RSGallery by going to <strong>Components->RSGallery->Settings</strong><br/>";
			echo "If you have any questions, please visit http://mamboforge.net/projects/rsgallery2. From there you can visit the manual<br/>";
			echo "<h2><a href=\"index2.php?option=com_rsgallery&task=settings\">Goto RSGallery settings</a></h2>";
			echo "</td></tr></table>";
			}
		}
	else
		{
		//echo $database->getErrorMsg();//Debug purposes
		echo "Upgrade not completed...............<font color=\"#FF0000\">Errors</font><br/><br/>";
		}
	echo "</td></tr>";
	echo "<tr><td>Please review your installation before use.<br/>";
	echo "If you have any questions, please visit http://mamboforge.net/projects/rsgallery2. From there you can visit the manual or ask some questions in the forum.</td></tr></table>";
	}
?>
