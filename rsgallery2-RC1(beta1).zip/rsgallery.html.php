<?php
//rsgallery.html.php
require_once($mosConfig_absolute_path.'/includes/pageNavigation.php');

/**
 * This class encapsulates the HTML for the non-administration RSGallery pages.
 */
class HTML_RSGALLERY
    {
    function RSGalleryHeader()
            {
            global $mosConfig_live_site;
?>
			<table border="0" width="100%">
				<tr>
					<td class="sectionname"></td>
					<td align="right" width="200"><a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery"); ?>"><img src="<?php echo $mosConfig_live_site.'/components/com_rsgallery/images/home.gif'; ?>" alt="" border="0" />&nbsp;<?php echo _RSGALLERY_BACKBUTTON; ?></a></td>
				</tr>
		        </table>
<?php
            }


    function RSGalleryFooter()
            {
?>
            <table class="RSfooterTBL" width="100%">
            <tr>
				<td align="center">
					<p><font class="smalldark"><b>Powered By<br />
					<a href="http://rsgallery2.mamboforge.net/" target="_blank"><?php echo _RSGALLERY_VERSION; ?></a></b><br />
					<?php //echo mosGetBrowser($_SERVER["HTTP_USER_AGENT"]); ?>
					</font></p>
				</td>
			</tr>
            </table>
<?php
            }

     function userCat($rows)
		{
		global $mosConfig_live_site, $rows, $catid, $catname;
?>
		<script language="javascript" type="text/javascript">
		function submitbutton(pressbutton)
			{
			var form = document.form1;

			// do field validation
			if (form.catname1.value == "")
				{
				alert( "<?php echo _RSGALLERY_MAKECAT_ALERT_NAME; ?>" );
				}
			else if (form.description.value == "")
				{
				alert( "<?php echo _RSGALLERY_MAKECAT_ALERT_DESCR; ?>" );
				}
			else
				{
				form.submit();
				}
		}
	</script>
<?php
		echo TableHeaderTop();
		if ($rows)
			{
			foreach ($rows as $row)
				{
				$catname 		= $row->catname;
				$description 		= $row->description;
				$ordering 		= $row->ordering;
				$uid 			= $row->uid;
				$catid 			= $row->id;
				$published		= $row->published;
				$user			= $row->user;
				}
			}
		else
			{
			$catname 		= "";
			$description 		= "";
			$ordering 		= "";
			$uid 			= "";
			$catid 			= "";
			$published		= "";
			$user			= "";
			}
?>
		<table width="100%">
		<tr>
			<td>&nbsp;</td>
			<td align="right">
				<img onClick="submitbutton(save);" src="<?php echo $mosConfig_live_site; ?>/administrator/images/save.png" alt="Save" border="0" name="save" onMouseOver="document.save.src='<?php echo $mosConfig_live_site; ?>/administrator/images/save_f2.png';" onMouseOut="document.save.src='<?php echo $mosConfig_live_site;?>/administrator/images/save.png';" />&nbsp;&nbsp;
				<img onClick="history.back();" src="<?php echo $mosConfig_live_site; ?>/administrator/images/cancel.png" alt="Cancel" border="0" name="cancel" onMouseOver="document.cancel.src='<?php echo $mosConfig_live_site; ?>/administrator/images/cancel_f2.png';" onMouseOut="document.cancel.src='<?php echo $mosConfig_live_site; ?>/administrator/images/cancel.png';" />
			</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td width="10%">&nbsp;</td>
			<td>
				<form name="form1" id="form1" method="post" action="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;page=makeusercat"); ?>">
				<input type="hidden" name="catid" value="<?php echo $catid; ?>" />
				<input type="hidden" name="ordering" value="<?php echo $ordering; ?>" />
				<table class="galRandom">
					<tr class="sectiontableheader">
						<td colspan="2">Create gallery</td>
					</tr>
					<tr class="galListRowOdd">
						<td>Category name</td>
						<td align="left"><input type="text" name="catname1" size="30" value="<?php echo $catname; ?>" /></td>
					</tr>
					<tr class="galListRowEven">
						<td>Description</td>
						<td align="left"><textarea cols="20" rows="5" name="description"><?php echo htmlspecialchars(stripslashes($description)); ?></textarea></td>
					</tr>
					<tr class="galListRowOdd">
						<td>Published</td>
						<td align="left"><input type="checkbox" name="published" value="1" <?php if ($published==1) echo "checked"; ?> /></td>
					</tr>
				</table>
				</form>
			</td>
			<td width="10%">&nbsp;</td>
		</tr>
		</table>
<?php
		echo TableHeaderBottom();
		}

	function userCatProperties($rows)
		{
		global $mosConfig_live_site, $rows, $my;
		echo TableHeaderTop();
?>
		<form id="form1" method="post" action="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;page=saveprop"); ?>" enctype="multipart/form-data">
		<table border="0" width="90%">
			<tr>
				<td>&nbsp;</td>
				<td align="right">
					<img onClick="history.back();" src="<?php echo $mosConfig_live_site; ?>/administrator/images/cancel.png" alt="Cancel" border="0" name="cancel" onMouseOver="document.cancel.src='<?php echo $mosConfig_live_site; ?>/administrator/images/cancel_f2.png';" onMouseOut="document.cancel.src='<?php echo $mosConfig_live_site; ?>/administrator/images/cancel.png';" />
				</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td width="5%">&nbsp;</td>
				<td>
					<table width="100%">
					<tr>
						<td>
							<table class="galRandom">
							<tr class="sectiontableheader">
								<td colspan="4"><?php echo _RSGALLERY_USERCAT_HEADER; ?></td>
							</tr>
							<tr class="galListRowOdd">
								<td align="left"><strong><?php echo _RSGALLERY_USERCAT_NAME; ?></strong></td>
								<td width="50"><strong><?php echo _RSGALLERY_USERCAT_EDIT; ?></strong></td>
								<td width="50"><strong><?php echo _RSGALLERY_USERCAT_DELETE; ?></strong></td>
								<td width="50"><strong><?php echo _RSGALLERY_USERCAT_ACL; ?></strong></td>
							</tr>
							<?php
							foreach($rows as $row)
								{
								?>
								<tr>
									<td align="left"><?php echo $row->catname; ?></td>
									<td>
										<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;catid=".$row->id."&amp;page=editusercat"); ?>">
											<img src="<?php echo $mosConfig_live_site; ?>/administrator/images/edit_f2.png" alt="" border="0" height="18" />
										</a>
									</td>
									<td>
										<!--<a href="index.php?option=com_rsgallery&amp;catid=<?php //echo $row->id; ?>&amp;page=delusercat">-->
										<a href="#" onClick="if(window.confirm('<?php echo _RSGALLERY_DELCAT_TEXT; ?>')) location='<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;page=delusercat&amp;catid=".$row->id); ?>'">
											<img src="<?php echo $mosConfig_live_site; ?>/administrator/images/delete_f2.png" alt="" border="0" height="18" />
										</a>
									</td>
									<td>
										<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;catid=".$row->id."&amp;page=accessctl"); ?>">

											<img src="<?php echo $mosConfig_live_site; ?>/administrator/images/approve_f2.png" alt="" border="0" height="18" />
										</a>
									</td>
								</tr>
								<?php
								}
							?>

							</table>
						</td>
					</tr>
					</table>
				</td>
				<td width="5%">&nbsp;</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td>
					<table width="100%">
					<tr>
						<td>
							<table class="galRandom">
							<tr class="sectiontableheader">
								<td colspan="2">User properties</td>
							</tr>
							<tr class="galListRowOdd">
								<td>Name</td>
								<td align="left"><?php echo $my->username; ?></td>
							</tr>
							</table>
						</td>
					</table>
				</td>
				<td>&nbsp;</td>
			</tr>
		</table>
		</form>
<?php
		echo TableHeaderBottom();
		}

        function slideShowLink ()
        {
                 global $displaySlideshow;

                 if ( $displaySlideshow )
                     {
?>
    				<script type="text/javascript">
    					//if (browser.isIE55up)
    						document.write('[<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;page=slideshow&amp;catid=".$row->gallery_id."&id=".$row->id); ?>">Slideshow</a>]');					//else
    					//	document.write('Sorry, no slideshow link for now folks, still working on that!');
    				</script>
<?php
                     }
        }

	function accessControl($rows, $catid)
		{
		global $mosConfig_live_site, $my, $catid;
		//echo "Access control list for gallery($catid) here";
		foreach($rows as $row)
			{
			$user = $row->user;
			}
		?>
		<script language="JavaScript1.2" src="<?php echo $mosConfig_live_site; ?>/components/com_rsgallery/picklist.js" type="text/javascript"></script>
		<table width="90%">
			<tr>
				<td>&nbsp;</td>
				<td align="right">
					<img onClick="selectAll(document.combo_box.elements['list2[]']);form1.submit();" src="<?php echo $mosConfig_live_site; ?>/administrator/images/save.png" alt="Save" border="0" name="save" onMouseOver="document.save.src='<?php echo $mosConfig_live_site;?>/administrator/images/save_f2.png';" onMouseOut="document.save.src='<?php echo $mosConfig_live_site; ?>/administrator/images/save.png';" />&nbsp;&nbsp;
					<img onClick="history.back();" src="<?php echo $mosConfig_live_site; ?>/administrator/images/cancel.png" alt="Cancel" border="0" name="cancel" onMouseOver="document.cancel.src='<?php echo $mosConfig_live_site; ?>/administrator/images/cancel_f2.png';" onMouseOut="document.cancel.src='<?php echo $mosConfig_live_site; ?>/administrator/images/cancel.png';" />
				</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td>
					<table width="100%">
					<tr>
						<td>
							<form id="form1" name="combo_box" method="post" action="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;page=save_acl"); ?>">
							<input type="hidden" name="catid" value="<?php echo $catid; ?>" />
							<table class="galRandom">
							<tr class="sectiontableheader">
								<td colspan="4">Access Control List for <font color="#FF0000"><?php echo getCatName($catid); ?></font></td>
							</tr>
							<tr class="galListRowOdd">
								<td colspan="3" align="left">Please select your access method for this gallery.</td>
							</tr>
							<tr class="galListRowEven">
								<td colspan="3" align="left"><input type="radio" name="v_acceslevel" value="0"<?php if ($user == 0) echo " checked"; ?> />&nbsp;&nbsp;&nbsp;<strong>Owner only(0)</strong></td>
							</tr>
							<tr class="galListRowOdd">
								<td colspan="3" align="left"><input type="radio" name="v_acceslevel" value="1"<?php if ($user == 1) echo " checked"; ?> />&nbsp;&nbsp;&nbsp;<strong>All registered users(1)</strong></td>
							</tr>
							<tr class="galListRowEven">
								<td colspan="3" align="left"><input type="radio" name="v_acceslevel" value="2"<?php if ($user == 2) echo " checked"; ?> />&nbsp;&nbsp;&nbsp;<strong>All visitors(2)</strong></td>
							</tr>
							<tr class="galListRowOdd">
									<td colspan="3" align="left"><input type="radio" name="v_acceslevel" value="3"<?php if ($user == 3) echo "checked"; ?> />&nbsp;&nbsp;&nbsp;<strong>Select users from database(max. 20 persons)(3)</strong></td>
							</tr>
							<tr>
								<td colspan="3" align="center">
								<!--<form action="" method="post" name="combo_box">-->
								<table cellpadding="4" cellspacing="0" border="0">
								<tr>
									<td>
									<select multiple size="10" name="list1[]" style="width:150">
										<?php
										echo getUsers();
										?>
									</select>
									</td>
									<td align="center" valign="middle">
										<input type="button" onClick="move(this.form.elements['list2[]'],this.form.elements['list1[]'])" value="<<" />
										<input type="button" onClick="move(this.form.elements['list1[]'],this.form.elements['list2[]'])" value=">>" />
									</td>
									<td>
										<select multiple size="10" name="list2[]" style="width:150">
										<?php
										if ($user == 3)
											{
											echo getAllowed($catid);
											}
										?>
										</select>
									</td>
								</tr>
								<tr>
									<td colspan="3" align="center"><input type="submit" name="submit_button" value="Submit" onClick="selectAll(document.combo_box.elements['list2[]']);" /></td>
								</tr>
								</table>
								</form>
								</td>
							</tr>
							<!--
							<?php
							if (checkLogin($my->id) == 1)
								{
								//When you are here you are logged in as super administrator
								?>
								<tr class="galListRowOdd">
									<td colspan="3" align="left"><input type="radio" name="registered" value="3"<?php if ($user == 3) echo "checked"; ?> />&nbsp;&nbsp;&nbsp;<strong>Select users from database(max. 20 persons)(3)</strong></td>
								</tr>
								<tr class="galListRowEven">
									<td><strong>Userlist</strong></td>
									<td>&nbsp;</td>
									<td><strong>Approved users</strong></td>
								</tr>
								<tr class="galListRowOdd">
									<td>
									<select name="users" size="10" multiple>
										<?php echo getUsers(); ?>
									</select>
									</td>
									<td><input type="button" value=">>" /><br /><input type="button" value="<<" /></td>
									<td>
									<select name="approved" size="10" multiple>
									<?php echo getUsers(); ?>
									</select>
									</td>
								</tr>
								-->
								<?php
								}
							?>
							</table>
						</td>
					</tr>
					</table>
				</td>
				<td>&nbsp;</td>
			</tr>
		</table>
		<?php
		}

	function edit_image($rows, $id)
		{
		global $my, $mosConfig_live_site, $imagepath, $id, $description;
		foreach ($rows as $row)
			{
			$filename 		= $row->name;
			$title			= $row->title;
			$description		= $row->descr;
			$id			= $row->id;
			$limitstart		= $row->ordering - 1;
			$catid 			= $row->gallery_id;
			}
		//echo "Description is: ".$description;
		?>
		<form name="form1" method="post" action="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;page=save_image"); ?>">
		<input type="hidden" name="id" value="<?php echo $id; ?>" />
		<input type="hidden" name="catid" value="<?php echo $catid; ?>" />
		<table border="0" width="90%">
			<tr>
				<td>&nbsp;</td>
				<td align="right">
					<img onClick="form1.submit();" src="<?php echo $mosConfig_live_site; ?>/administrator/images/upload.png" alt="Upload" border="0" name="upload" onMouseOver="document.upload.src='<?php echo $mosConfig_live_site; ?>/administrator/images/upload_f2.png';" onMouseOut="document.upload.src='<?php echo $mosConfig_live_site; ?>/administrator/images/upload.png';" />&nbsp;&nbsp;
					<img onClick="history.back();" src="<?php echo $mosConfig_live_site; ?>/administrator/images/cancel.png" alt="Cancel" border="0" name="cancel" onMouseOver="document.cancel.src='<?php echo $mosConfig_live_site; ?>/administrator/images/cancel_f2.png';" onMouseOut="document.cancel.src='<?php echo $mosConfig_live_site; ?>/administrator/images/cancel.png';" />
				</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td width="10%">&nbsp;</td>
				<td>
					<table width="100%">
					<tr>
						<td>
							<table class="galRandom">
							<tr class="sectiontableheader">
								<td colspan="3">Edit Image</td>
							</tr>
							<tr class="galListRowOdd">
								<td align="left">Filename</td>
								<td align="left"><strong><?php echo $filename; ?></strong></td>
								<td rowspan="2"><img src="<?php echo $mosConfig_live_site.$imagepath."thumbs/".$filename; ?>" alt="<?php echo $title; ?>" border="0" width="75" /></td>
							</tr>
							<tr class="galListRowOdd">
								<td align="left">Title</td>
								<td align="left"><input type="text" name="title" size="30" value="<?php echo $title; ?>" /></td>
							</tr>
							<tr class="galListRowOdd">
								<td align="left" valign="top">Omschrijving</td>
								<td align="left" colspan="2"><textarea cols="25" rows="5" name="descr"><?php echo htmlspecialchars(stripslashes($description)); ?></textarea></td>
							</tr>
							</table>
						</td>
					</tr>
					</table>
				</td>
				<td width="10%">&nbsp;</td>
			</tr>
		</table>
		</form>
		<?php
		}


	function showFrontUpload($p_catid)
		{
		global $mosConfig_live_site, $mosConfig_absolute_path, $i_file, $conversiontype, $my;
		?>
		<script language="javascript" type="text/javascript">
		function submitbutton(pressbutton)
			{
			var form = document.form1;

			// do field validation
			if (form.i_cat.value == "xx")
				{
				alert( "<?php echo _RSGALLERY_UPLOAD_ALERT_CAT; ?>" );
				}
			else if (form.i_file.value == "")
				{
				alert( "<?php echo _RSGALLERY_UPLOAD_ALERT_FILE; ?>" );
				}
			else if (form.title.value == "")
				{
				alert( "<?php echo _RSGALLERY_UPLOAD_ALERT_TITLE; ?>" );
				}
			else
				{
				form.submit();
				}
		}
	</script>
		<?php
		echo TableHeaderTop();
		?>
		<script language="javascript" src="<?php echo $mosConfig_live_site; ?>/administrator/js/dhtml.js"></script>
		<script language="javascript" type="text/javascript">
		 var dhtml = new mosDHTML();
		</script>
		<form name="form1" id="form1" method="post" action="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;page=doFrontUpload"); ?>" enctype="multipart/form-data">
		<table border="0" width="90%">
			<tr>
				<td>&nbsp;</td>
				<td align="right">
					<img onClick="submitbutton(upload);" src="<?php echo $mosConfig_live_site; ?>/administrator/images/upload.png" alt="Upload" border="0" name="upload" onMouseOver="document.upload.src='<?php echo $mosConfig_live_site; ?>/administrator/images/upload_f2.png';" onMouseOut="document.upload.src='<?php echo $mosConfig_live_site; ?>/administrator/images/upload.png';" />&nbsp;&nbsp;
					<img onClick="history.back();" src="<?php echo $mosConfig_live_site; ?>/administrator/images/cancel.png" alt="Cancel" border="0" name="cancel" onMouseOver="document.cancel.src='<?php echo $mosConfig_live_site; ?>/administrator/images/cancel_f2.png';" onMouseOut="document.cancel.src='<?php echo $mosConfig_live_site; ?>/administrator/images/cancel.png';" />
				</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td width="10%">&nbsp;</td>
				<td>
					<table>
					<tr>
						<td>
							<table class="galRandom">
							<tr class="sectiontableheader">
								<td colspan="2"><?php echo _RSGALLERY_USERUPLOAD_TITLE; ?></td>
							</tr>
							<tr class="galListRowOdd">
								<td colspan="2" align="left"><p><?php echo _RSGALLERY_USERUPLOAD_TEXT; ?></p></td>
							</tr>
							<tr class="galListRowEven">
								<td>Category:</td>
								<td>
									<select name="i_cat">
									<?php echo showUserCatSelect($my->id,$p_catid); ?>	
									</select>
								</td>
							</tr>
								<td><?php echo _RSGALLERY_FILENAME ?></td>
								<td align="left"><input type="file" name="i_file" class="inputbox" /></td>
							</tr>
							</tr>
								<td><?php echo _RSGALLERY_UPLOAD_FORM_TITLE ?>:</td>
						        <td align="left"><input name="title" type="text" class="inputbox" size="40" />
						    </td>
							</tr>
							<tr>
						        <td><?php echo _RSGALLERY_DESCR ?></td>
						        <td align="left"><textarea class="inputbox" cols="35" rows="3" name="descr"></textarea></td>
					        </tr>
							<?php
							if ($conversiontype == 0)
								{ ?>
							<tr class="galListRowOdd">
								<td>Thumb:</td>
								<td align="left"><input type="file" name="i_thumb" class="inputbox" /></td>
							</tr>
								<?php } ?>
							<tr>
								<td colspan="2"><input type="hidden" name="cat" value="9999" /></td>
							<tr>
								<td colspan="2" class="galListRowEven">&nbsp;</td>
							</tr>
							</table>
						</td>
					</tr>
					</table>
				</td>
				<td width="10%">&nbsp;</td>
			</tr>
		</table>
		</form>
		<?php
		echo TableHeaderBottom();
		?>
		<script language="javascript" type="text/javascript">dhtml.cycleTab('tab1');</script><br /><br />
		<?php
		}

    function RSGalleryInline($id, $catid)
        {
        global $my, $displayDesc, $displayVoting, $displayComments, $displayEXIF, $database, $imagepath, $PageSize, $StartRow, $limitstart,$id, $PicWidth, $mosConfig_live_site, $mosConfig_absolute_path, $ResizeOption;
        include_once($mosConfig_absolute_path.'/administrator/components/com_rsgallery/config.rsgallery.php');
	include_once($mosConfig_absolute_path.'/administrator/components/com_rsgallery/settings.rsgallery.php');

        $useTabs=0;

        if ($displayDesc == 1) $useTabs++;
        if ($displayVoting == 1) $useTabs++;
        if ($displayComments ==1) $useTabs++;
        if ($displayEXIF == 1) $useTabs++;
        $useTabs = $useTabs > 1 ? 1 : 0;

        $firstTab='';

        if($displayDesc) $firstTab = 'tab1';
        elseif($displayVoting) $firstTab = 'tab2';
        elseif($displayComments) $firstTab = 'tab3';
        elseif($displayEXIF) $firstTab = 'tab4';

	$PageSize=1;

        $database->setQuery("SELECT COUNT(*) FROM #__rsgalleryfiles WHERE gallery_id = '$catid'");
        $numPics = $database->loadResult();

	if(!isset($limitstart))
		$limitstart = 0;

	//instantiate page navigation
	$pagenav = new mosPageNav($numPics, $limitstart, $PageSize);
        $thisPage = floor($limitstart/$PageSize)+1;
    	$maxPage = ceil($numPics / $PageSize);

	if (!$numPics)
	    {
	    echo "1" . _RSGALLERY_NOIMG;
	    }

        $database->setQuery("SELECT * FROM #__rsgalleryfiles".
		   " WHERE gallery_id = $catid".
		   " ORDER BY ordering ASC".
		   " LIMIT $limitstart, $PageSize");
        $rows = $database->loadObjectlist();

	if (!$rows) echo _RSGALLERY_NOIMG;
	echo '<script language="javascript" src="'.$mosConfig_live_site.'/components/com-rsgallery/dhtml.js"></script>';

        $j=$limitstart;
	$i=0;
        foreach($rows as $row)
            {
            // dmcd remove this below when new field is in database
	    // $row->votes=0;

            $abs_image_path = $mosConfig_absolute_path.$imagepath.$row->name;
            $live_image_path = $mosConfig_live_site.$imagepath.$row->name;
			addHit($row->id);
            $size = getimagesize($abs_image_path);
            $ext = substr(strchr($row->name, '.'),1);

	    $img_width = $size[0];
	    switch( $ResizeOption )
	    {
		case 0:  // No display resizing
			$dispWidth = $img_width;
			break;
		case 1:  // Resize larger pics down, and leave smaller pics as is
			if( $img_width > $PicWidth )
			{
				$dispWidth = $PicWidth;
			}
			else $dispWidth = $img_width;
			break;
		case 2:  // Resize smaller pics up, and leave larger pics as is
			if( $img_width < $PicWidth )
			{
				$dispWidth = $PicWidth;
			}
			else $dispWidth = $img_width;
			break;
		case 3:  // Resize all pics to fit into frame.
			$dispWidth = $PicWidth;
			break;
		default:
			$dispWidth = $img_width;
	   }

            //Hier komt dus alle HTML

            ?>
            <script language="javascript" type="text/javascript">
		// TODO?
                // Ron, you need to create a new instance of the dhtml tab object for every pic here
                var dhtml<?php echo "_".$i; ?> = new mosDHTML();
            </script>
		<script type="text/javascript" src="<?php echo $mosConfig_live_site ?>/components/com_rsgallery/browser_detect.js"></script>

	    <table class="RSTbl" cellspacing="0" cellpadding="0">
		<tr>
			<td class="RSlefttop"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer"></td>
			<td class="RStopline"></td>
			<td class="RSrighttop"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer"></td>
		</tr>

		<tr>
			<td class="RSleftline"></td>
			<td class = "RSGalDesc" align="right">
<?php
                        HTML_RSGALLERY::slideShowLink();
?>
			</td>
			<td class="RSrightline"></td>

		</tr>
		<tr>
			<td class="RSleftbottom"><img src="components/com_rsgallery/images/spacer.gif"  alt="" class="RSCornerSpacer"></td>
			<td class="RSbottomline">&nbsp;</td>
			<td class="RSrightbottom"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer"></td>
		</tr>
		</table>
	<br />

	<?php
	//PDW 1-8-2004
	//We don' use tableheadertop anymore
	//php echo TableHeaderTop();
	?>

       	<table class="RSTbl" border="0" cellspacing="0" cellpadding="0" >
        <tr>
		<td class="RSlefttop"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer"></td>
		<td class="RStopline"></td>
		<td class="RSrighttop"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer"></td>
	</tr>
        <tr>
   		<td class="RSleftline"></td>
		<td align="center" class="RSImagecell">
               		<?php
                        // print page navigation.  Ron, do you really want this at the top of every pic,
			// or maybe just at the top and bottom of the page?
                        echo $pagenav->writePagesLinks( "index.php?option=com_rsgallery&amp;page=inline&amp;catid=".$catid."&amp;id=".$row->id."&limitstart=".$j );
                        ?>
		</td>
		<td class="RSrightline"></td>
	</tr>
	<tr>
		<td class="RSleftline"></td>
		<td align="center" class="RSImagecell"><h2><?php echo htmlspecialchars(stripslashes($row->title), ENT_QUOTES); ?></h2></td>
		<td class="RSrightline"></td>
	</tr>
	<tr>
		<td class="RSleftline"></td>
		<td align="center" class="RSImagecell"><img src="<?php echo $live_image_path; ?>" alt="<?php echo htmlspecialchars(stripslashes($row->descr), ENT_QUOTES); ?>" border="1" width="<?php echo $dispWidth;?>" /></td>
		<td class="RSrightline"></td>
	</tr>
                <?php
		//Here comes the row with the tabs
		if ($useTabs)
		   { ?>
	           <tr>
		     <td class="RSleftline"></td>
                     <td class="RSImagecell">
			<!-- Start of the first table around the tabs -->
                        <table cellpadding="0" cellspacing="1" width="<?php echo $dispWidth; ?>">
                        <tr>
                                <td>
				    <!-- Start of the second  table around the tabs -->
                                    <table cellpadding="3" cellspacing="0" border="0" width="100%">
                                        <tr>
                                            <td width="5%" class="tabpadding">&nbsp;</td>
		                            <?php
					    if ($displayDesc == 1)
           					{ ?>
	                	                <td width="100" id="tab1<?php echo "_".$i; ?>" nowrap="nowrap" class="offtab" onclick="dhtml<?php echo "_".$i; ?>.cycleTab(this.id)"><?php echo _RSGALLERY_TAB_1; ?>
						</td>
			                        <?php }
                                            if ($displayVoting == 1)
           					{ ?>
                                        	<td width="100" id="tab2<?php echo "_".$i; ?>" nowrap="nowrap" class="offtab" onclick="dhtml<?php echo "_".$i; ?>.cycleTab(this.id)"><?php echo _RSGALLERY_TAB_2; if ($row->votes > 0)echo "(".$row->votes.")"; ?>
						</td>
			                        <?php }
                                            if ($displayComments == 1)
           					{ ?>
                                        	<td width="100" id="tab3<?php echo "_".$i; ?>" nowrap="nowrap" class="offtab" onclick="dhtml<?php echo "_".$i; ?>.cycleTab(this.id)"><?php echo _RSGALLERY_TAB_3; if ($row->comments > 0)echo "(".$row->comments.")"; ?>
						</td>
			                        <?php }
                                            if ($displayEXIF == 1 && $ext == 'jpg')
           					{ ?>
		                                <td width="100" id="tab4<?php echo "_".$i; ?>" class="offtab" onclick="dhtml<?php echo "_".$i; ?>.cycleTab(this.id)"><?php echo _RSGALLERY_TAB_4; ?>
						</td>
			                	<?php }
					    ?>
  		                            <td width="" class="tabpadding">&nbsp;
					    </td>
                                        </tr>
					<!-- End of the second table around the tabs -->
                                    </table>
                                </td>
                            </tr>
				<!-- End of the first table around the tabs -->
                        </table>
                    </td>
  		    <td class="RSrightline"></td>
                </tr>
                <?php } ?>
	    <!-- End of the table around the image and the tabs -->
            <!-- This was and </table>, now we incorporate the tabs too -->

		<tr>
		    <td class="RSleftline"></td>
       		    <td align="center" class="RSImagecell">
	    <!-- This is start for the tab showing the description -->
            <?php if ($displayDesc == 1){ ?>
            <div id="page1<?php echo "_".$i; ?>" class="pagetext">

            <table width="100%" border="0" cellpadding="0" cellspacing="1" class="adminForm" bgcolor="#000000">
            <tr>
                <td>
                    <table bgcolor="#c0c0c0" width="100%" cellpadding="2" cellspacing="1">
						<tr bgcolor="#CCCCCC">
						    <td valign="top" width="100">&nbsp;<strong><?php echo _RSGALLERY_TITLE; ?>:</strong></td>
						    <td valign="top"><?php echo htmlspecialchars(stripslashes($row->title), ENT_QUOTES); ?></td>
						</tr>
						<tr bgcolor="#CCCCCC">
						    <td valign="top" width="100">&nbsp;<strong><?php echo _RSGALLERY_CATHITS; ?>:</strong></td>
						    <td valign="top"><?php echo $row->hits+1; ?></td>
						</tr>
						<tr bgcolor="#CCCCCC">
						    <td valign="top" width="100">&nbsp;<strong><?php echo _RSGALLERY_FILENAME; ?>:</strong></td>
						    <td valign="top"><?php echo $row->name; ?></td>
						</tr>
						<tr bgcolor="#CCCCCC">
						    <td valign="top" width="100">&nbsp;<strong><?php echo _RSGALLERY_DESCR; ?>:</strong></td>
						    <td valign="top"><?php if ($row->descr) echo htmlspecialchars(stripslashes($row->descr), ENT_QUOTES); else echo "<em>"._RSGALLERY_NODESCR."</em>"; ?></td>
						</tr>
                    </table>
                </td>
            </tr>
            </table>
            </div>
	    <!-- This is end for the tab showing the description-->

	    <!-- This is start for the tab showing the voting -->
            <?php }
            if ($displayVoting == 1){ ?>
            <div id="page2<?php echo "_".$i; ?>" class="pagetext">
            <table width="100%" border="0" cellpadding="0" cellspacing="1" class="adminForm" bgcolor="#000000">
            <tr>
                <td>
                    <table bgcolor="#c0c0c0" width="100%" cellpadding="2" cellspacing="1">

                        <form method="post" action="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;page=vote"); ?>">
                        <tr bgcolor="#CCCCCC">
                                <td colspan="1" width="100"><strong><?php echo _RSGALLERY_VOTES_NR; ?>:</strong></td>
								<td colspan="4"><?php echo $row->votes; ?></td>
                        </tr>
                        <tr bgcolor="#CCCCCC">
                            <td colspan="1"><strong><?php echo _RSGALLERY_VOTES_AVG; ?>:</strong></td>
							<td colspan="4"><?php if ($row->votes > 0) echo showRating($row->id);else echo _RSGALLERY_NO_RATINGS; ?></td>
                        </tr>
						<?php if($my->gid >= "1")
						{ ?>
                        <tr bgcolor="#CCCCCC">
                            <input type="hidden" name="picid" value="<?php echo $row->id; ?>" />
                            <td valign="top"><strong><?php echo _RSGALLERY_VOTES; ?>:</strong></td>
                            <td colspan="4">
                                <input type="radio" name="vote" value="1" /><?php echo _RSGALLERY_VERYBAD; ?><br />
                                <input type="radio" name="vote" value="2" /><?php echo _RSGALLERY_BAD; ?><br />
                                <input type="radio" name="vote" value="3" /><?php echo _RSGALLERY_OK; ?><br />
                                <input type="radio" name="vote" value="4" /><?php echo _RSGALLERY_GOOD; ?><br />
                                <input type="radio" name="vote" value="5" /><?php echo _RSGALLERY_VERYGOOD; ?>
                            </td>
                        </tr>
                        <tr bgcolor="#CCCCCC">
                            <td colspan="5" align="center"><input class="button" type="submit" name="submit" value="<?php echo _RSGALLERY_VOTES;?>" /></td>
                        </tr>
                        </form>
						<?php } else { ?>
						<tr>
							<td colspan="2"><em><?php echo _RSGALLERY_NOT_LOGGED_IN_VOTE; ?></em></td>
						</tr>
							<?php } ?>
                    </table>
                </td>
            </tr>
            </table>
            </div>
	    <!-- This is end for the tab showing the voting -->

	    <!-- This is start for the tab showing the comments -->
            <?php 
	    }  //End if for $displayVoting == 1


            if ($displayComments == 1) { ?>
            <div id="page3<?php echo "_".$i; ?>" class="pagetext">
            <table width="100%" border="0" cellpadding="0" cellspacing="1" class="adminForm" bgcolor="#000000">
            <?php
            $database->setQuery("SELECT * FROM #__rsgallery_comments WHERE picid='$row->id' ORDER BY id DESC");
            $crows = $database->loadObjectList();
            if (!$crows)
		{
		?>
		<tr bgcolor="#c0c0c0">
			<td><?php echo _RSGALLERY_NO_COMMENTS; ?></td>
		</tr>
            	<?php 
		}
	    else
		{
		?>
	        <tr>
	        	<td>
	                <table bgcolor="#c0c0c0" width="100%" cellpadding="2" cellspacing="1">
	                <?php
	                foreach ($crows as $crow)
				{
				?>
	                        <tr>
	        	                <td width="120"><strong><?php echo _RSGALLERY_COMMENT_DATE; ?>:</strong></td>
	                	        <td><?php echo $crow->date; ?></td>
	                        </tr>
              			<tr>
		                        <td><strong><?php echo _RSGALLERY_COMMENT_BY; ?>:</strong></td>
                       			<td><?php echo htmlspecialchars(stripslashes($crow->name), ENT_QUOTES); ?></td>
		                </tr>
                        	<tr>
			                <td valign="top"><strong><?php echo _RSGALLERY_COMMENT_TEXT; ?>:</strong></td>
		                        <td><?php echo htmlspecialchars(stripslashes($crow->comment), ENT_QUOTES); ?></td>
			        </tr>
			        <tr>
			                <td colspan="2" align="center"><hr></td>
			        </tr>              
				<?php 
				}
			?>
			</table>
			</td>
	   	</tr>
            	<?php
		}
	    if($my->gid >= "1")
	    	{
		?> 
            	<tr bgcolor="#483D8B">
                	<td colspan="2"><strong><font color="#FFFFFF">&nbsp;<?php echo _RSGALLERY_COMMENT_ADD; ?></font></strong></td>
	        </tr>
        	<tr>
                    <td>
                    <form method="post" action="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;page=addcomment"); ?>">
					<input type="hidden" name="picid" value="<?php echo $row->id; ?>" />
                        <table bgcolor="#c0c0c0" width="100%" cellpadding="2" cellspacing="1">
                            <tr>
                                <td width="130"><strong><?php echo _RSGALLERY_COMMENT_NAME; ?>:</strong></td>
                                <td><input class="inputbox" type="text" name="name" size="30" value="<?php echo $my->username; ?>" readonly /></td>
                            </tr>
                            <tr>
                                <td width="130" valign="top"><strong><?php echo _RSGALLERY_COMMENT_TEXT; ?>:</strong></td>
                                <td><textarea class="inputbox" cols="30" rows="3" name="comment" /></textarea></td>
                            </tr>
                            <tr>
                                <td colspan="2" align="center"><input class="button" type="submit" name="submit" value="<?php echo _RSGALLERY_COMMENT_ADD; ?>" /></td>
                            </tr>
                        </table>
		    </form>
                    </td>
            	</tr>
		<?php
		}
	    else
		{
		?>
		<tr>
			<td bgcolor="#CCCCCC"><em><?php echo _RSGALLERY_NOT_LOGGED_IN_COMMENT; ?></em></td>
		</tr>
		<?php
		}
	    ?>
            </table>
            </div>

	    <!-- This is end for the tab showing the comments -->

	    <!-- This is start for the tab showing the Exif -->
            <?php }
            if ($displayEXIF == 1){ ?>
            <div id="page4<?php echo "_".$i; ?>" class="pagetext">
            <table width="100%" border="0" cellpadding="0" cellspacing="1" class="adminForm" bgcolor="#000000">
            <tr>
                <td>
                    <table bgcolor="#c0c0c0" width="100%" cellpadding="2" cellspacing="1">
                        <tr bgcolor="#CCCCCC">
                            <td align="center"><?php echo showEXIF($abs_image_path); ?></td>
                        </tr>
                    </table>
                </td>
            </tr>
            </table>
			</div>

	    <!-- This is end for the tab showing the Exif -->
	   <?php } ?>
	   </td>
	   	<td class=RSrightline></td>
	   </tr>
	   <tr>
		<td class="RSleftbottom" ><img src='components/com_rsgallery/images/spacer.gif' class="RSCornerSpacer"></td>
		<td class="RSbottomline"></td>	
		<td class="RSrightbottom" ><img src='components/com_rsgallery/images/spacer.gif' class="RSCornerSpacer"></td>
 	   </tr>
           </table> 

            <?php 

	    // We don' user the bottom anymore
 	    // echo TableHeaderBottom();


            if($useTabs){ ?>
                <script language="javascript" type="text/javascript">dhtml<?php echo "_".$i; ?>.cycleTab('<?php echo $firstTab."_".$i; ?>');</script>
	    <?php } elseif ($firstTab != '') { ?>               
                <script language="javascript" type="text/javascript">dhtml.showElem('<?php echo "page".substr($firstTab,3)."_".$i; ?>');</script>
	    <?php }
            //Einde HTML
        } $i++; $j++; ?>
    <?php
    }
    //end of inline


    function RSGalleryTitleblock($catid, $intro_text)
	{
	global $my,$mosConfig_live_site;

	$my_id = $my->id;

	?>
	<table class="RSTbl" cellspacing="0" cellpadding="0">
	<tr>
		<td class="RSlefttop"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
		<td class="RStopline" width="85"></td>
		<td class="RStopline" width="1"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSlinespacer" /></td>
		<td class="RStopline" width="100%"></td>
		<td class="RStopline" width="1"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSlinespacer" /></td>
		<td class="RStopline" width="50"><img src="components/com_rsgallery/images/spacer.gif" alt="" /></td>
		<td class="RSrighttop"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
	</tr>
	<tr>
		<td class="RSleftline"></td>
		<td class="RSGalTitle" colspan="4">
			<?php
			if (isset($catid))
				echo htmlspecialchars(stripslashes(getCatName($catid)), ENT_QUOTES);
			else
				echo _RSGALLERY_COMPONENT_TITLE;
			?>
		</td>
		<td align="right" class="RSGalDesc" colspan="1">
			<?php
			if (checkLogin($my_id) !== 0)
				{
				if (isset($catid))
					{
					?>
					<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;page=frontupload&amp;catid=$catid"); ?>">
					<img src="<?php echo $mosConfig_live_site;?>/administrator/images/upload.png" alt="Upload" border="0" />
					Upload</a>
					<?php
					}
				else
					{
					?>
					<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;page=frontupload"); ?>">
					<img src="<?php echo $mosConfig_live_site;?>/administrator/images/upload.png" alt="Upload" border="0" />
					Upload</a>
					<?php
					}
				}
			?>
		</td>
		<td class="RSrightline"></td>
	</tr>
	<tr valign="top">
		<td class="RSleftline"></td>
		<td colspan="4" class="RSGalDesc"><?php echo htmlspecialchars(stripslashes($intro_text), ENT_QUOTES); ?></td>
		<td class="RSGalDesc">
						<?php
						if (isset($catid))
							{
                                                        HTML_RSGALLERY::slideShowLink();
							}
						?>
		</td>

		<td class="RSrightline"></td>
	</tr>
	<tr>
		<td class="RSleftbottom"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
		<td class="RSbottomline" colspan="5"></td>
		<td class="RSrightbottom"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
	</tr>

	</table>
	<br />
	<?php
	}
	//End of  funcion RSGalleryTitleblock()

    function RSGalleryList ($style)
	{
	global $database,$mosConfig_live_site;

	/*

	TROOZERS: Commented out while testing why Master/Detail Frontmenu is not working
		  update: query included pgal.allowed and pgal.show_full_description, both of which are not within
		          the mos_rsgallery table.

	$mainsql="select pgal.id, pgal.catname,	pgal.description, pgal.published, pgal.ordering, pgal.uid, pgal.user, pgal.parent, pgal.allowed, pgal.show_full_description, count(distinct cgal.id) numgal, count(distinct pict.id) numpic";
	$mainsql.=" FROM mos_rsgallery  pgal LEFT OUTER JOIN mos_rsgallery cgal ON cgal.parent=pgal.id";
	$mainsql.=" left outer join mos_rsgalleryfiles pict on pict.gallery_id=pgal.id";
	$mainsql.=" group by pgal.id, pgal.catname, pgal.description, pgal.published, pgal.ordering, pgal.uid, pgal.user, pgal.parent, pgal.allowed, pgal.show_full_description";
	$mainsql.=" having (count(distinct cgal.id) >0 or	count(distinct pict.id)>0 )";
	$mainsql.=" and published=1";
	*/

	$mainsql = "SELECT pgal.id, pgal.catname, pgal.description, pgal.published, pgal.ordering, pgal.uid, pgal.user, 
		    pgal.parent, COUNT(DISTINCT cgal.id) numgal, COUNT(DISTINCT pict.id) numpic
		    FROM #__rsgallery pgal LEFT OUTER JOIN #__rsgallery cgal ON cgal.parent=pgal.id
		    LEFT OUTER JOIN #__rsgalleryfiles pict ON pict.gallery_id=pgal.id
		    GROUP BY pgal.id, pgal.catname, pgal.description, pgal.published, pgal.ordering, pgal.uid, pgal.user,
		    pgal.parent HAVING (COUNT(DISTINCT cgal.id) >0 OR COUNT(DISTINCT pict.id) >0 )
		    AND pgal.published=1";
	if ($style == 1)
		{
		//Style=1, so thats a dropdownlist
		//TODO make this compatible with the ACL stuff
		$galquery=$mainsql." AND (user = 0 or user=2) ORDER BY ordering ASC";
		$database->setQuery($galquery);
		$rows = $database->loadObjectList();
		?>
		<table class="RSTbl" cellspacing="0" cellpadding="0">
		<tr>
			<td class="RSlefttop"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
			<td class="RStopline"></td>
			<td class="RSrighttop"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
		</tr>
		<tr>
  			<td width="30">&nbsp;</td>
			<td align="left" width="300" valign="top">
			<form name="selection" method="POST" action="<?php echo sefRelToAbs("index.php?option=com_rsgallery"); ?>">
				<select name="catid" onchange="this.form.submit();">
				<option value="" selected>---&nbsp;<?php echo _RSGALLERY_GALLERY_PICK; ?>&nbsp;---</option>
				<?php
				foreach ($rows as $row)
					{
					echo "<option value=\"$row->id\">".htmlspecialchars(stripslashes($row->catname), ENT_QUOTES)."</option>";
					}
				?>
				</select>
				</form>
				<!--<?php echo htmlspecialchars(stripslashes($row->description), ENT_QUOTES); ?>-->
			</td>
			<td width="100" valign="top">
				<img src="<?php echo $mosConfig_live_site.'/components/com_rsgallery/images/camera.gif';?>" alt="" border="0" />
			</td>
		</tr>
		</table>
		<?php
		}
	elseif ($style==2)
		{
		//PDW 22-08-2004 This while elseif branche added for extra layout options
		//Style==2. So we want a master detail layout
		//First a row with the parent
		//Then columns with the childs

		//TODO make this compatible with the ACL stuff

		//TODO make this a parameter, for the time being the childs are displayed in 4 columns.
		$columns=5;
		$galquery=$mainsql." and pgal.parent = 0 AND pgal.user = 0 ORDER BY pgal.ordering ASC";
		$database->setQuery($galquery);
		$rows = $database->loadObjectList();

		?>
		<table class="RSTbl" cellspacing="0" cellpadding="0">
		<?php

		//Here we are gonne show the parent categories
		$i=0;
		foreach($rows as $row)
			{
			$i++;
			$c_id = $row->id;
			$galleryListClass = ($i & 1) ? 'galListRowOdd' : 'galListRowEven';
			//Get the child galleries
			$childsql=$mainsql." and (pgal.parent = '$c_id'  ) AND pgal.user='0' ORDER BY pgal.ordering ASC";
			$database->setQuery($childsql);
			$rows2 = $database->loadObjectList();
			$rowspan=count($rows2) + 1;

			?>
				<tr>
					<td class="RSlefttop" ><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
					<td class="RStopline" colspan="<?php echo $columns; ?>"></td>
					<td class="RSrighttop"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
				</tr>
				<tr>
					<td class="RSleftline"></td>
					<td colspan="<?php echo $columns; ?>" class="RSGalDesc">
					<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;catid=".$row->id); ?>" class="RSGalTitle">
					<?php echo htmlspecialchars(stripslashes($row->catname), ENT_QUOTES); ?>
					<?php echo newImages($row->id); ?></a><br />
					<?php echo htmlspecialchars(stripslashes($row->description), ENT_QUOTES); ?>

					</td>
					<td class="RSrightline"></td>
				</tr>
			<?php
			//Here we are gonna show the child categories
				?>
					<tr>
						<td class="RSleftline"></td>
						<td class="RSbetweencells" colspan="<?php echo $columns; ?>"></td>
						<td class="RSrightline"></td>
					</tr>
					<tr>
						<td class="RSleftline"></td>
						<td colspan="<?php echo $columns; ?>"><?php //echo _RSGALLERY_SUBCAT; ?></td>
						<td class="RSrightline"></td>
					</tr>
					<tr>
					<td class="RSleftline"></td>
					<?php
					$cell=0;
					if ($row->numpic > 0)
						{
						$cell++;	
						?>
						<td class="RSGalThumbCell">
							<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;catid=".$row->id); ?>"><?php echo getThumb($row->id,50,0,"");?></a>
							<br />
							<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;catid=".$row->id); ?>" class="RSGalThumbCell">
							<?php echo htmlspecialchars(stripslashes($row->catname), ENT_QUOTES); ?>&nbsp;(<?php echo getNumber($row->id);?>)
							</a>
							<?php echo newImages($row->id); ?>
						</td>
						<?php
						}
					if ($rows2)
						{
						$cell++;
						foreach($rows2 as $row2)
							{
							?>
							<td class="RSGalThumbCell">
							<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;catid=".$row2->id); ?>" class="RSGalThumbCell"><?php echo getThumb($row2->id,80,0,"");?>
							<br />
							<img src="<?php echo $mosConfig_live_site?>/components/com_rsgallery/images/folder.gif" border="0" />
							<?php echo htmlspecialchars(stripslashes($row2->catname), ENT_QUOTES); ?>&nbsp;(<?php echo getNumber($row2->id);?>)
							</a>
							<?php 
							echo newImages($row2->id);
							echo "</td>\n";
							$cell++;
							if ($cell>=$columns and $cell<=count($rows2))
								{
								echo "<td class=\"RSleftline\"></td></tr>\n<tr><td class=\"RSrightline\"></td>\n";
								$cell=1;
								}
							}
						}  //End of for loop for childgalleries

					//Finishing up the row
				      	for($j=$cell;($j % $columns) != 0; $j++)
						{
						?>
				                <td width="<?php echo $size; ?>" class="galThumb"></td>
			        		<?php
						}
				?>
				<td class="RSrightline"></td>
				</tr>
				<?php
				?>
				<tr>
					<td class="RSleftbottom" ><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer"></td>
					<td class="RSbottomline" colspan=<?php echo $columns; ?>></td>
					<td class="RSrightbottom" ><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer"></td>
				</tr>
				<tr>
					<td><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
					<td colspan=<?php echo $columns; ?>></td>
					<td><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
				</tr>
				<?php
			} //End of the parent loop
		echo "</table>\n";
		}
	else
		{
		//If style is 0 we want the normal list. We also make this list if we dont now the given style (ex. 9)
		//Haal de topcategorieen uit de database en echo ze naar het scherm
		//TODO make this compatible with the ACL stuff
		$database->setQuery("SELECT * FROM #__rsgallery WHERE published = 1 AND parent = 0 AND user = 0 ORDER BY ordering ASC");
		$rows = $database->loadObjectList();
		?>
		<table class="RSTbl" cellspacing="0" cellpadding="0">
		<tr>
			<td class="RSlefttop"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
			<td class="RStopline" width="85"></td>
			<td class="RStopline" width="1"></td>
			<td class="RStopline"></td>
			<td class="RStopline" width="1"></td>
			<td class="RStopline" width="50"></td>
			<td class="RSrighttop"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
		</tr>
		<tr>
			<td class="RSleftline"></td>
				<td class="sectiontableheader RSDescHeader" width="250" colspan="3"><?php echo _RSGALLERY_DESCR; ?></td>
				<td class="RSBetweenCells"></td>
				<td class="sectiontableheader RSDescHeader" width="50"><?php echo _RSGALLERY_NUMBEROFPICS; ?></td>
			<td class="RSrightline"></td>
		</tr>
			<?php
			//Here we are gonne show the parent categories
			$i=0;
			foreach($rows as $row)
				{
				$i++;
				$c_id = $row->id;
				$galleryListClass = ($i & 1) ? 'galListRowOdd' : 'galListRowEven';
				$database->setQuery("SELECT * FROM #__rsgallery WHERE published = 1 and parent = '$c_id' AND user='0' ORDER BY ordering ASC");
				$rows2 = $database->loadObjectList();
				$rowspan=count($rows2) + 1;

				?>
				<tr>
					<td class="RSleftline"></td>
					<td class="RSGalTitle"></td>
					<td class="RSBetweenCells"></td>
					<td valign="top" class="RSGalDesc"><a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;catid=".$row->id); ?>">
						<?php echo htmlspecialchars(stripslashes($row->catname), ENT_QUOTES); ?></a><?php echo newImages($row->id); ?>
					</td>
					<td class="RSBetweenCells"></td>
					<td align="center" class="RSGalDesc">
						<?php echo getNumber($row->id);?>
					</td>
					<td class="RSrightline"></td>
				</tr>
				<tr>
					<td class="RSleftline"></td>
					<td class="RSBetweenCells" colspan="5"></td>
					<td class="RSrightline"></td>
				</tr>
				<tr>
					<td class="RSleftline"></td>
					<td class="RSGalDesc" width="75"><a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;catid=".$row->id); ?>"><?php echo getThumb($row->id,50,0,""); ?></a></td>
					<td class="RSBetweenCells"></td>
					<td class="RSGalDesc">
					<?php echo htmlspecialchars(stripslashes($row->description), ENT_QUOTES); ?>
					<script type='text/javascript' src='<?php echo $mosConfig_live_site;?>/components/com_rsgallery/show_content.js'></script>
					<?php
					//Here we are gonne show the child categories
					if ($rows2)
      						{
                                                echo "<!-- Child rows -->";
						foreach($rows2 as $row2)
							{
					?>
								<br />
								<img height="10" src="components/com_rsgallery/images/folder.gif" alt="" border="0" />
								<a class="weblinks" href="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;catid=".$row2->id); ?>">
								<?php echo htmlspecialchars(stripslashes($row2->catname), ENT_QUOTES); ?>&nbsp;(<?php echo getNumber($row2->id); ?>)
								</a>
								<?php
								echo newImages($row2->id);
							}
						}
					?>
					</td>
					<td class="RSBetweenCells"></td>
					<td class="RSGalDesc"></td>
					<td class="RSrightline"></td>
				</tr>
				<tr>
					<td class="RSleftline"></td>
					<td class="RSBetweenCells" colspan="5"></td>
					<td class="RSrightline"></td>
				</tr>

				<?php
				}
				?>
		<tr>
			<td class="RSleftbottom"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
			<td class="RSbottomline" colspan="5"></td>
			<td class="RSrightbottom"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
		</tr>
		</table>
		<?php
		}
	}
	//End of  funcion RSGalleryList()

    function RSUserGalleryList()
	{
	global $my, $mosConfig_live_site;

	$my_id = $my->id;
	?>

	<script language="JavaScript" type="text/javascript">
	var DHTML = (document.getElementById || document.all || document.layers);
	function getObj(name)
		{
		  if (document.getElementById)
		  {
	  		this.obj = document.getElementById(name);
			this.style = document.getElementById(name).style;
		  }
		  else if (document.all)
		  {
			this.obj = document.all[name];
			this.style = document.all[name].style;
		  }
		  else if (document.layers)
		  {
		   	this.obj = document.layers[name];
		   	this.style = document.layers[name];
		  }
		}

	function setCookie(name, value, expires, path, domain, secure) 
		{
		  var curCookie = name + "=" + escape(value) +
		      ((expires) ? "; expires=" + expires.toGMTString() : "") +
		      ((path) ? "; path=" + path : "") +
		      ((domain) ? "; domain=" + domain : "") +
		      ((secure) ? "; secure" : "");
		  document.cookie = curCookie;
		}


	function getCookie(name) 
		{
		/*
		name - name of the desired cookie
		return string containing value of specified cookie or null
	  	if cookie does not exist
		*/

		  var dc = document.cookie;
		  var prefix = name + "=";
		  var begin = dc.indexOf("; " + prefix);
		  if (begin == -1) 
			{
			begin = dc.indexOf(prefix);
			if (begin != 0) return null;
			} 
		  else
	   	    	begin += 2;
		  var end = document.cookie.indexOf(";", begin);
		  if (end == -1)
		    end = dc.length;
		  return unescape(dc.substring(begin + prefix.length, end));
		}

	function invi(flag)
		{
		if (!DHTML) return;
		var sc1_HideUserGal = new getObj('sc1_HideUserGal'), sc1_ShowUserGal = new getObj('sc1_ShowUserGal'), now = new Date();

		now.setTime(now.getTime() + 365 * 24 * 60 * 60 * 1000);

		if (flag==1)
			{
			/* flag=1 betekent tonen van de Usergalleries */
			sc1_HideUserGal.style.display = 'none';
			sc1_ShowUserGal.style.display = 'block';
			}
		else
			{
			/* Verstoppen dat spul */
			sc1_HideUserGal.style.display = 'block';
			sc1_ShowUserGal.style.display = 'none';
			}
		setCookie ("showusergal",sc1_HideUserGal.style.display,now);
		}

	</script>

	<table class="RSTbl" cellspacing="0" cellpadding="0">
	<tr>
		<td class="RSlefttop"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
		<td class="RStopline" colspan="3">
		<!--<a href="javascript:invi(0)">hide</a>-->
		</td>
		<td class="RStopline" width="1"></td>
		<td class="RStopline" width="50"></td>
		<td class="RSrighttop"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
	</tr>
	<tr>
		<td class="RSleftline"></td>
		<td colspan="5" class="RSGalTitle">
			<?php
			if (!isset($showusergal))
				echo "<div id=\"sc1_HideUserGal\" class=\"showncontent\">";
			else
				{
				if ($showusergal == 'none')
					echo "<div id=\"sc1_HideUserGal\" class=\"hiddencontent\">";
				else
					echo "<div id=\"sc1_HideUserGal\" class=\"showncontent\">";
				}

			?>
			<table cellspacing="0" cellpadding="0" width="100%">
			<tr>
				<td class="sectiontableheader RSDescHeader" colspan="5">
				<a href="javascript:invi(1)">
				<img src="<?php echo $mosConfig_live_site; ?>/components/com_rsgallery/images/plus.gif" alt="" border="0" />
				</a>
				<?php echo _RSGALLERY_USERGAL_HEADER; ?>
				</td>
			</tr>
			<tr>
				<td class="RSGalTitle" width="85">&nbsp;</td>
				<td class="RSGalTitle" width="1"></td>
				<td class="RSGalTitle">Click on the plus sign to show the usergalleries</td>
				<td class="RSGalTitle" width="1"></td>
				<td class="RSGalTitle" width="50">&nbsp;</td>
			</tr>
			</table>
			</div>
		</td>
		<td class="RSrightline"></td>
	</tr>
	<tr>
		<td class="RSleftline"></td>
		<td colspan="5" class="RSGalTitle">
			<?php
			if (!isset($showusergal))
				echo "<div id=\"sc1_ShowUserGal\" class=\"hiddencontent\">";
			else
				{
				//showusergal is de style van sc1_HideUserGal
				if ($showusergal == 'none')
					echo "<div id=\"sc1_ShowUserGal\" class=\"showncontent\">";
				else
					echo "<div id=\"sc1_ShowUserGal\" class=\"hiddencontent\">";
				}

			echo showUserCategories($my_id);
			?>
			</div>
		</td>
		<td class="RSrightline"></td>
	</tr>
	<tr>
		<td class="RSleftbottom"></td>
		<td class="RSbottomline" colspan="5"></td>
		<td class="RSrightbottom"></td>
	</tr>
	</table> 
	<?php

	}
	//End of  funcion RSUserGalleryList()

    function RSShowPictures ($catid, $columns, $PageSize, $limit, $limitstart)
	{
	global $database, $mosConfig_absolute_path, $my, $mosConfig_live_site;
	include($mosConfig_absolute_path.'/administrator/components/com_rsgallery/settings.rsgallery.php');
	$my_id = $my->id;

	//TODO The thumbsize is named $size, this function creates a new $size;
	$ThumbSize = $size;



	//---------------------Pagination part 1---------------------------//

	$database->setQuery("SELECT COUNT(*) FROM #__rsgalleryfiles WHERE gallery_id='$catid'");
	$numPics = $database->loadResult();
	//instantiate page navigation

	if(!isset($limitstart))
	   $limitstart = 0;

	$pagenav = new mosPageNav($numPics, $limitstart, $PageSize);

	$picsThisPage = min($PageSize, $numPics - $limitstart);

        // dmcd, may want to remove this below later, but it looks better if we reduce columns when picsThisPage < columns
	// PDW 1-8-2004 Don't do this when there are no pics
	if (!$picsThisPage == 0)
	        $columns = min($picsThisPage, $columns);

        $database->setQuery("SELECT show_full_description FROM #__rsgallery WHERE id=$catid");
        $ShowFullDescription = $database->loadResult();

	//If the fulldescription of the image must be shown then double the columns
	//The extra columns will be used for the descriptions
	//Riba not sure what is this supposed to do, had to remove it
	//if ($ShowFullDescription==1)
	//	$columns=1;

        if($picsThisPage)
	   {
           $database->setQuery("SELECT * FROM #__rsgalleryfiles WHERE gallery_id=$catid ORDER BY ordering ASC LIMIT $limitstart, $PageSize");
           $rows =$database->loadObjectList();
	   }

	//------------------------------------------------//
	if ($catid && !$limitstart)
		{
		addCatHit($catid);
		}
	?>
	<br />


	<!-- Here comes the image within a table -->
	<table class="RSTbl" cellspacing="0" cellpadding="0">
	<tr>
		<td class="RSlefttop"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
		<td class="RStopline" colspan="<?php echo $columns+$ShowFullDescription; ?>"></td>
		<td class="RSrighttop"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td> 
	</tr>
	<tr>
		<td class="RSleftline"></td>
		<td colspan="<?php echo $columns+$ShowFullDescription; ?>" class="galPageCnt">
		<?php 
		if ($picsThisPage)
		{
			$thisPage = floor($limitstart/$PageSize)+1;
			echo "\t".$numPics . _RSGALLERY_IMGS . _RSGALLERY_PAGE . $thisPage . _RSGALLERY_OF . ceil($numPics/$PageSize) ."\n";
		}
		else
		{
			echo _RSGALLERY_NOIMG;
		}
		?>
			<br /><br />
		</td>
		<td class="RSrightline"></td>
	</tr>
	<?php
	$j = 0;
	$imgPosCount = 0;
	for( $i=$limitstart; $i<$picsThisPage+$limitstart; $i++ )
	{
		$imgPosCount++;
		//Make new row (TR) when this is the first image on the row
		if( $imgPosCount == 1 )
		{
		  	echo "\t<tr>\n";
			echo "\t\t<td class=\"RSleftline\"></td>\n"; 
		}

		//Teller om aantal per rij te tellen
		$row = $rows[$j++];
		$size = getimagesize($mosConfig_absolute_path.$imagepath.$row->name);

		//make new cell for each image
		if ($ShowFullDescription==1)
		{
			echo "\t\t<td class=\"galThumb\" width=\"".($ThumbSize+20)."px\">\n";
		}
		else
		{
			echo "\t\t<td class=\"galThumb\" width=\"".(100/$columns)."%\">\n";
		}

		//Check if link to image should be inline or popup and create according link
		$uid = getUID($catid);
		//pdw 1-8-2004 changed if construction so the edit and delete options will be shown
		//independant of the choice for popur or inline
		if ( $inline )
		{
			//So we want inline
		?>
			<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;page=inline&amp;id=".$row->id."&amp;catid=".$row->gallery_id."&amp;limitstart=".$i); ?>">
			<img border="1" alt="<?php echo htmlspecialchars(stripslashes($row->descr), ENT_QUOTES); ?>" src="<?php echo $mosConfig_live_site.$imagepath."thumbs/".$row->name; ?>" /><br />
			<?php echo htmlspecialchars(stripslashes($row->title), ENT_QUOTES); ?></a><br />
		<?php
		} else 	{
			//So we want popup

			if( $size[0] > $MaxWidthPopup )
			{
				$WindowsizeX =   $MaxWidthPopup + 20;
				$WindowsizeY = ( $MaxWidthPopup / $size[0] ) * $size[1] + 80;
			} else	{
				$WindowsizeX = $size[0] + 20;
				$WindowsizeY = $size[1] + 80;
			}
			?>
			<a href="#" onClick="window.open('components/com_rsgallery/view.php?<?php echo "name=$row->name&xwidth=$size[0]&ywidth=$size[1]&id=$row->id"; ?>', 'win1', 'width=<?php echo $WindowsizeX; ?>, height=<?php echo $WindowsizeY; ?>');return false;">
			<img border="1" alt="<?php echo htmlspecialchars(stripslashes($row->descr), ENT_QUOTES); ?>" src="<?php echo $mosConfig_live_site.$imagepath."thumbs/".$row->name; ?>" />
			<br /><?php echo $row->title;?><br />
			<?php //echo $row->name; ?>
			</a>
			<?php
		}

		//This is the place where we create the buttons and links to edit or delete an image
		//TODO PDW 20-6-2004
		//I don't like checking on id = 62
		//Change to select all the superusers and other backend users.
		//TODO
		//Add buttons for ordering
		if( ( $my_id <> 0 ) and ( ( $uid == $my_id ) OR ( $my_id == '62' ) ) )
		{
		?>
		<table border="0">
		<tr>
			<td width="50" align="center"><a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;page=edit_image&amp;id=".$row->id); ?>"><img src="<?php echo $mosConfig_live_site; ?>/administrator/images/edit_f2.png" alt="" border="0" height="15" /><br />Edit</a></td>
			<td width="50" align="center"><a href="#" onClick="if(window.confirm('<?php echo _RSGALLERY_DELIMAGE_TEXT;?>')) location='<?php echo sefRelToAbs("index.php?option=com_rsgallery&amp;page=delete_image&amp;id=".$row->id); ?>'"><img src="<?php echo $mosConfig_live_site; ?>/administrator/images/delete_f2.png" alt="" border="0" height="15" /><br />Delete</a></td>
		</tr>
		</table>
		<?php
		} else 	{
			//echo "You are not owner or Super Administrator";
		}
		echo "\t<br />\n";
		echo "\t\t</td>\n";

		// if (!$picsThisPage == 0)
		if( $ShowFullDescription==1 )
		{
			echo "<td class=\"RsImgDesc\">".$row->descr."</td>";
		}

		//If this is the last image on the row then end this row 
		//PDW 1-8-2004 changed $i+1 % $columns into bcmod($i+1, $columns)
		// TROOZERS: 2004-09-28 removed bcmod as bc functionality not compiled
		// by default into PHP.
		if( $imgPosCount == $columns )
		{
			echo "\t\t<td class=\"RSrightline\"></td>\n\t</tr>\n"; 
			$imgPosCount = 0;
		}
	}
        // dmcd fill up remaining last row with any necessary trailing blank columns
	// PDW 1-8-2004
	// $i is incremented when leaving the loop. so $i is not the same as $i for the last image.
	if( ( $i % $columns ) != 0 )
	{
	       	for( $j = $i; ($j % $columns) != 0; $j++ )
		{
			echo "<td width=\"".$size."\" class=\"galThumb\">&nbsp;</td>";
		}
	        echo "<td class=\"RSrightline\">&nbsp;</td></tr>";
        } ?>

        <tr>
		<td class="RSleftline"></td>
		<td align="center" colspan="<?php echo $columns+$ShowFullDescription; ?>" class="galPageNav">
		<?php
		//--------------------------------------------------------//
	        //Print First & Previous Link is necessary
		//When there are more pictures than there can be shown, shown the navigation
		if ($numPics>$PageSize)
			{
			echo  "<hr class=\"galHR\"><br />";
		        echo $pagenav->writePagesLinks("index.php?option=com_rsgallery&amp;catid=".$catid);
			}
	        ?>
		   </td>
		<td class="RSrightline"></td>
	</tr>
	<tr>
		<td class="RSleftbottom"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
		<td class="RSbottomline" colspan="<?php echo $columns+$ShowFullDescription; ?>"></td>
		<td class="RSrightbottom"><img src="components/com_rsgallery/images/spacer.gif" alt="" class="RSCornerSpacer" /></td>
	</tr>
	</table>
	<?php
	}
	//End of function RSShowPictures
}
?>
