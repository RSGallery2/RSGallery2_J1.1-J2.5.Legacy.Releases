<?php
/**
* This file contains the non-presentation processing for the Admin section of RSGallery.
*
* @version $ 2.0 RC-1 $
* @package RSGallery_2.0
* @copyright (C) 2003 - 2004 RSDevelopment
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* RSGallery is Free Software
**/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
//Check for language files, if not found, default to english
if (file_exists($mosConfig_absolute_path.'/administrator/components/com_rsgallery/language/'.$mosConfig_lang.'.php'))
	{
	include($mosConfig_absolute_path.'/administrator/components/com_rsgallery/language/'.$mosConfig_lang.'.php');
	}
else
	{
	include($mosConfig_absolute_path.'/administrator/components/com_rsgallery/language/english.php');
	}
include($mosConfig_absolute_path.'/administrator/components/com_rsgallery/config.rsgallery.php');
 //require_once('../administrator/components/com_rsgallery/settings.rsgallery.php');

// dmcd - the following is necessary to strip out added backslashes to POST vars depending upon
// whether the PHP 'magic_quotes_gpc' setting is enabled or not, which automatically
// backslashes ' " and \ chars in GET, POST and COOKIE Global Vars.  I have seen this
// setting both on AND off on different commercial Hosts out there, so it is best
// to remove all the backslashes first and add them in later when necessary such as
// writing to the database or using these URL variables within a specific context such
// as printing PHP variables to HTML output, whereby ANY variable that can potentially have
// quotes, doublequotes or other special chars that can potentially cause a HTML syntax violation
// should be pre-processed with the htmlspecialchars() or htmlentities() functions before being
// printed/echoed.  Note that it does not seem that the MOS core code for now does any sort of
// post-processing of the GLOBAL variable arrays in this way.  The RECOMMENDED MOS setting is for
// magic quotes to be enabled.

// here we remove slashes around post vars we know can potentially contain quotes or backslashes
$postVars = array('title','descr','search','imagepath', 'IM_path', 'NETPBM_path', 'intro_text');

if (get_magic_quotes_gpc()){
	reset($postVars);
	foreach($postVars as $var)
		if(isset($_POST[$var])) $_POST[$var] = stripslashes($_POST[$var]);
}


error_reporting(E_ALL);//added jdg; Goeie manier om potentiele fouten er bij voorbaat uit te halen
require_once( $mainframe->getPath( 'admin_html' ) );

// reorder the database tables every time for now.
/*reorderRSGallery('#__rsgallery');
$database->setQuery("SELECT id FROM #__rsgallery");
$catids= $database->loadResultArray();
foreach($catids as $catid)
	{
	reorderRSGallery('#__rsgalleryfiles', "gallery_id = '$catid'");
	}
*/

// asdbg_break();
umask(0);

//$cid = mosGetParam( $_POST, 'cid', array(0) );
//$cid = mosGetParam( $_GET, 'cid', array(0) );
$cid = mosGetParam( $_POST, 'cid', array(0) );
if (!is_array( $cid )) {
   $cid = array(0);
}

switch ($task)
	{
	case "settings":
		HTML_RSGallery::RSGalleryTopMenu();
		HTML_RSGallery::RSGalleryHeader();
		showConfig($option, $mosConfig_absolute_path);
		HTML_RSGallery::RSGalleryFooter();
		break;
	case "edit_image":
		HTML_RSGallery::RSGalleryTopMenu();
		HTML_RSGallery::RSGalleryHeader();
		editImage($option, $cid[0]);
		HTML_RSGallery::RSGalleryFooter();
		break;
	case "upload":
		HTML_RSGallery::RSGalleryTopMenu();
		HTML_RSGallery::RSGalleryHeader();
		showUpload();
		HTML_RSGallery::RSGalleryFooter();
		break;
	case "batchupload":
		HTML_RSGallery::RSGalleryTopMenu();
		HTML_RSGallery::RSGalleryHeader();
		batch_upload($option, $mosConfig_absolute_path);
		HTML_RSGallery::RSGalleryFooter();
		break;
	case "save_batchupload":
		save_batchupload();
		break;
	case "view_images":
		HTML_RSGallery::RSGalleryTopMenu();
		HTML_RSGallery::RSGalleryHeader();
		viewImages($option);
		HTML_RSGallery::RSGalleryFooter();
		break;
	case "view_categories":
		HTML_RSGallery::RSGalleryTopMenu();
		HTML_RSGallery::RSGalleryHeader();
		viewCategories($option);
		HTML_RSGallery::RSGalleryFooter();
		break;
	case "save_category":
		saveCategory($option, $id);
		break;
	case "edit_category":
		HTML_RSGallery::RSGalleryTopMenu();
		HTML_RSGallery::RSGalleryHeader();
		newCategory($option, $cid[0]);
		HTML_RSGallery::RSGalleryFooter();
		break;
	case "save_image":
		saveImage($option, $id);
		break;
   case "move_image":
      moveImage($option, $cid[0]);
      break;
   case "remove":
      deleteCategory($option,$cid);
      break;
	case "new_category":
		HTML_RSGallery::RSGalleryTopMenu();
		HTML_RSGallery::RSGalleryHeader();
		newCategory($option, 0);
		HTML_RSGallery::RSGalleryFooter();
		break;
	case "install":
		RSInstall();
		break;
	case "save_config":
      // dmcd jan 6/04  check to see if thumnail size var has changed.  If so, go regenerate all
      // thumbnails.  May want to ask user first since it could take a while.
      // Get old $size value to compare
      if($size != getOldSetting('size') || $conversiontype != getOldSetting('conversiontype') || $JPEGquality != getOldSetting('JPEGquality')){
         // re-generate all the thumbs in all categories
         regenerateAllThumbs();
      }
      // Maybe inform the user to wait because that thumbnails are being regenerated?  How to do this.

		saveConfig($option);
		break;
   case "categories_orderup":
   case "images_orderup":
      orderRSGallery( $cid[0], -1, $option, $task );
      break;
   case "categories_orderdown":
   case "images_orderdown":
      orderRSGallery( $cid[0], 1, $option, $task );
      break;
	case "cancel":
		cancelGallery($option);
		break;
	case "delete_image":
		deleteImage( $cid, $option );
		break;
	case "regen_thumbs":
		HTML_RSGallery::RSGalleryTopMenu();
		HTML_RSGallery::RSGalleryHeader();
		echo "Feature not implemented. To follow.<br /><br /><br />Ronald Smit";
		HTML_RSGallery::RSGalleryFooter();
		break;
   case "consolidate_db":
		HTML_RSGallery::RSGalleryTopMenu();
		HTML_RSGallery::RSGalleryHeader();
		consolidateDbInform($option);
		HTML_RSGallery::RSGalleryFooter();
		break;
   case "consolidate_db_go":
      consolidateDbGo($option);
	  break;
	case "import_captions":
		HTML_RSGallery::RSGalleryTopMenu();
		HTML_RSGallery::RSGalleryHeader();
		import_captions();
		HTML_RSGallery::RSGalleryFooter();
		break;
	case "test":
		viewCategories2($s_id);
		break;
	case "publish":
		publishCategory( $cid, 1, $option );
		break;
	case "unpublish":
		publishCategory( $cid, 0, $option );
		break;
	default:
		HTML_RSGallery::RSGalleryTopMenu();
		HTML_RSGallery::RSGalleryHeader();
		viewCategories($option);
		HTML_RSGallery::RSGalleryFooter();
   }

/**
 * This function is called to publish (or unpublish) a category.
 */		
function publishCategory( $cid = null, $publish = 1, $option )
	{
	global $database, $my;
	if (!is_array( $cid ) || count( $cid ) < 1)
		{
		$action = $publish ? 'publish' : 'unpublish';
		echo "<script> alert('Select an item to $action'); window.history.go(-1);</script>\n";
		exit;
		}
	$cids = implode( ',', $cid );
	$database->setQuery( "UPDATE #__rsgallery SET published='$publish'"
		. "\nWHERE id IN ($cids)"
		);
	if (!$database->query())
		{
		echo "<script> alert('".$database->getErrorMsg()."'); window.history.go(-1); </script>\n";
		exit();
		}
	/*if (count( $cid ) == 1)
		{
		$row = new sbForum( $database );
		$row->checkin( $cid[0] );
		}*/
	mosRedirect( "index2.php?option=$option" );
	}

/**
 * This function is called during step 2 of the RSGallery installation. It
 * outputs the HTML allowing the user to select between a "fresh" install,
 * or an "upgrade" install.
 */		
function RSInstall()
	{
	global $opt, $mosConfig_absolute_path;
	require_once($mosConfig_absolute_path.'/administrator/components/com_rsgallery/install.rsgallery.php');
	HTML_RSGallery::RSGalleryHeader();
	//echo "Dit is het installscherm";
	switch ($opt)
		{
		case "fresh":
			FreshInstall();

			break;
		case "upgrade":
			Upgrade();
			break;
		default:
	?>
	<table class="adminForm" width="400">
		<tr>
			<td class="sectionname"><h3>Choose your option</h3></td>
		</tr>
		<tr>
			<td><a href="index2.php?option=com_rsgallery&task=install&opt=fresh">Fresh install</a><br />Install new tables for RSGallery</td>
		</tr>
		<tr>
			<td><a href="index2.php?option=com_rsgallery&task=install&opt=upgrade">Upgrade</a><br />Upgrade from RSGallery 2.0 beta 5</td>
		</tr>
		<tr>
			<td><a href="index2.php?option=com_rsgallery&task=settings">Finish</a><br />Continue to Configuration</td>
		</tr>
	</table>
	<?php
	}
	HTML_RSGallery::RSGalleryFooter();
	}

function deleteImage($cid, $option)
	{
	global $database, $mosConfig_live_site, $mosConfig_absolute_path, $imagepath;
	require_once($mosConfig_absolute_path.'/administrator/components/com_rsgallery/settings.rsgallery.php');
	foreach ($cid as $id)
		{
		$database->setQuery("SELECT gallery_id FROM #__rsgalleryfiles WHERE id = '$id'");
		$gallery_id = $database->loadResult();
		$xname = getFileName($id);
		if (unlink($mosConfig_absolute_path.$imagepath.$xname))
			{
			unlink($mosConfig_absolute_path.$imagepath."thumbs/".$xname);
			$database->setQuery("DELETE FROM #__rsgalleryfiles WHERE id = '$id'");
			$database->query();
			reorderRSGallery('#__rsgalleryfiles', "gallery_id = '$gallery_id'");
			}
		}
	?>
	<script>
		alert("<?php echo _RSGALLERY_ALERT_IMGDELETEOK;?>");
		location = 'index2.php?option=com_rsgallery&task=view_images';
	</script>
	<?php
	}

function save_batchupload()
	{
	global $database, $mosConfig_absolute_path, $mosConfig_live_site, $FTP_path;
	require_once($mosConfig_absolute_path.'/administrator/components/com_rsgallery/settings.rsgallery.php');

        // There is a discrepancy here... in some places ftppath is used, in others FTP_path is used. Set them both the same!
        $ftppath = $FTP_path;

	//Check if all categories are chosen
	if (in_array("xx",$_POST['category']))
		{
		?>
		<script>
				alert("<?php echo _RSGALLERY_ALERT_NOCATSELECTED;?>");
				history.back();
		</script>
		<?php
		}
	?>
	<table border="1">
	<?php
	for($i=0;$i<$_POST['teller'];$i++)
		{

		//Check if file needs to be deleted
		if ($_POST['delete'][$i] == 'true')
			{
			unlink($mosConfig_absolute_path.$ftppath.$_POST['filename'][$i]);
			continue;
			}
		$i_name = SpaceToUnderscore($_POST['filename'][$i]);
		//Copy image to right directory
		if (copy ($mosConfig_absolute_path.$ftppath.$_POST['filename'][$i], $mosConfig_absolute_path.$imagepath.$i_name))
			{
			//Chmod file to 755
			chmod($mosConfig_absolute_path.$imagepath.$i_name,0755);
			//Make thumbnail and copy to right location
			$file_in = $mosConfig_absolute_path.$imagepath.$i_name;
			$file_out = $mosConfig_absolute_path.$imagepath."thumbs/".$i_name;
			$maxsize    = $size;
			$origname   = $i_name;
			$quality    = $JPEGquality;
			$ext		= explode(".", $i_name);
            $ext        = strtolower(trim($ext[1]));

			//Make thumbnail and copy to right location
			if($conversiontype == 0)
				{
				//No autothumb, upload thumbnail seperately
				copy("$thumb[$t]", "$imagepath$thumbs/$thumb_name[$t]");
				//chmod thumbnail to 755
				chmod($mosConfig_absolute_path.$imagepath.$thumb_name[$t],0755);
				}
			else
				{
                makeThumb($conversiontype, $file_in, $file_out, $maxsize, $origname, $quality, $ext);
				resizePicture($conversiontype, $file_in, $ResizeOption, $PicWidth); // Troozers Modification
				}
			//Insert entry into database
			if ($_POST['ptitle'][$i] == "")
				{
				$title = $i_name;
				}
			else
				{
				$title = $_POST['ptitle'][$i];
				}
			$gallery_id = $_POST['category'][$i];
			$filename = $_POST['filename'][$i];
			$database->setQuery("SELECT COUNT(*) FROM #__rsgalleryfiles WHERE gallery_id = '$gallery_id'");
			$ordering = $database->loadResult() + 1;
			$descr = (isset($_POST['descr'])) ?  $_POST['descr'] : '';
			$descr = addslashes($descr);
			$title = addslashes($title);
			$database->setQuery("INSERT INTO #__rsgalleryfiles".
			" (title, name, descr, gallery_id, date, ordering) VALUES".
			" ('$title', '$i_name', '', '$gallery_id', now(), '$ordering')");
			if ($database->query())
				//{
				//Delete from uploadfiles
				//}
				unlink($mosConfig_absolute_path.$ftppath.$_POST['filename'][$i]);

				?>
				<script>
					alert("<?php echo _RSGALLERY_ALERT_UPLOADOK;?>");
					location = 'index2.php?option=com_rsgallery&task=batchupload';
				</script>
				<?php
			}
		else
			{
			//File Copy Failed. Alert User and go back to Upload Page
			?>
				<script>
					alert("<?php echo _RSGALLERY_ALERT_NOWRITE;?>");
					location = 'index2.php?option=com_rsgallery&task=batchupload';
				</script>
			<?php
			}
		}
		?>
		</table>
	<?php
	}


function cancelGallery($option)
	{
	mosRedirect("index2.php?option=$option");
	}

function batch_upload($option, $submit)
	{
	function myPreExtractCallBack($p_event, &$p_header)
		{
		if ($p_header['folder'] == 1)
			{
			return 0;
			}
		else
			{
			return 1;
			}
		}
	global $database, $mosConfig_absolute_path,$mosConfig_live_site, $submit, $zip_file, $ziplist, $batchmethod, $ftppath;
// Path was changed in MOS 4.5.2.
//	include($mosConfig_absolute_path.'/administrator/classes/pclzip.lib.php');
	include($mosConfig_absolute_path.'/administrator/includes/pcl/pclzip.lib.php');
	// BEGIN Troozers Modifiction
	require_once($mosConfig_absolute_path.'/administrator/components/com_rsgallery/settings.rsgallery.php');
	if ($submit)
	{
		if ($batchmethod == "zip")
		{
			//New zipfile
			$zipfile = new PclZip($zip_file);
			//List contents in array
			$ziplist = $zipfile->listContent();
			//Unzip to ftp directory, removing all path info
			$list = $zipfile->extract(	PCLZIP_OPT_PATH, $mosConfig_absolute_path.$FTP_path,
									PCLZIP_OPT_REMOVE_ALL_PATH,
									PCLZIP_CB_PRE_EXTRACT, "myPreExtractCallBack");
			if ($list == 0)
			{
    				die ("Error message :".$zipfile->errorInfo(true));
			}
		}
		else
		{
		// Process files in FTP folder
		$allowed_ext = array("gif", "jpg", "png");

		// Troozers: Not sure if this works, confuses when defining path,
		//           maybe default to $mosConfig_absolute_path/uploads if nothing specified
		//if( $handle = opendir( $mosConfig_absolute_path.$FTP_path ) )
echo $FTP_path;
echo $ftppath;
		if( $handle = opendir( $FTP_path ) )
			{
				while (false !== ($file = readdir($handle)))
				{
					if ($file != "." && $file != "..")
					{
						if( copy( $FTP_path.$file, $mosConfig_absolute_path."/uploadfiles/$file" ) )
						{
						chmod($mosConfig_absolute_path."/uploadfiles/".$file,0755);
							// make sure file is an image and process it
							$frag = array_reverse(explode(".", $file));
							$ext = strtolower($frag[0]);

							if( in_array( $ext, $allowed_ext ) )
							{
								$ziplist[][filename] = $file;
								unlink( $FTP_path.$file );
							}
						}
					}
   				}
				closedir($handle);
			}

		}
		//show all thumbs on a page with details
		HTML_RSGALLERY::batch_upload_2($ziplist, $mosConfig_live_site,$mosConfig_absolute_path);
	} else {
		HTML_RSGALLERY::batch_upload();
	}

}


function editImage($option, $cid)
	{

	global $e_id, $descr, $xtitle, $submit, $database, $id, $imagepath, $task, $mosConfig_absolute_path;
	if ($cid[0]!="")
		{
		$e_id = $cid[0];
		}
		require_once($mosConfig_absolute_path.'/administrator/components/com_rsgallery/settings.rsgallery.php');
		$database->setQuery("SELECT * FROM #__rsgalleryfiles AS a, #__rsgallery AS b WHERE a.gallery_id = b.id AND a.id='$e_id'");
		$rows = $database->loadObjectList();
     	HTML_RSGALLERY::editImage($option, $e_id, $rows);
   }


// dmcd Feb 05/04  new move image function, to move images to a different category
function moveImage($option, $cid)
	{

	global $database, $mainframe;
	$catmoveid = $mainframe->getUserStateFromRequest( "catmoveid{$option}", 'catmoveid', 0 );

	// there will be at least 1 image selected for a move as well as a valid
	// move category, but check anyways
    $database->setQuery("SELECT id FROM #__rsgallery WHERE id = '$catmoveid'");

	if ($cid && $catmoveid && $database->loadResult()){
		// get largest ordering num from target category
      	$database->setQuery("SELECT MAX(ordering) FROM #__rsgalleryfiles WHERE gallery_id = '$catmoveid'");
		$k=$database->loadResult()+1;
		for($i=0;$i<count($cid);$i++){
		    $e_id = $cid[$i];
      		$database->setQuery("UPDATE #__rsgalleryfiles SET ordering = $k, gallery_id = '$catmoveid' WHERE id='$e_id'");
			$database->query();
			$k++;
		}
    viewImages($option);
   }
}


// BEGIN: Troozers Modification	
function ftp_upload()
{
	global $database, $mosConfig_absolute_path, $mosConfig_live_site, $submit;
	require_once($mosConfig_absolute_path.'/administrator/components/com_rsgallery/settings.rsgallery.php');

	$allowed_ext = array("gif","jpg","png");
	if ($submit)
	{
		// $ziplist[][filename] is an array of files in ftp upload dir,
		// am using $ziplist so that i can use the batch_upload_2 function
		// which is used for the zip-file upload.

		if( $handle = opendir( $FTP_path ) )
		{
			while (false !== ($file = readdir($handle))) 
			{ 
				if ($file != "." && $file != "..") 
				{ 
					if( copy( $FTP_path.$file, "$mosConfig_absolute_path/uploadfiles/$file" ) )
					{
					chmod($mosConfig_absolute_path."/uploadfiles/".$file,0755);
						// make sure file is an image and process it
						$frag = array_reverse(explode(".", $file));
						$ext = strtolower($frag[0]);

						if( in_array( $ext, $allowed_ext ) )
						{
							$ziplist[][filename] = $file;
							unlink( $FTP_path.$file );
						}
					}
				}
   			}
			closedir($handle); 
		}

		//show all thumbs on a page with details
		HTML_RSGALLERY::batch_upload_2($ziplist, $mosConfig_live_site,$mosConfig_absolute_path);
	} else {
		HTML_RSGALLERY::ftp_upload();
	}

}
// END: Troozers Modification



function showUpload()
{
   global 
   	$JPEGquality,
	      $size,
	      $descr,
	      $hits,
	      $udate,
	      $title2,
	      $IM_path,
	      $NETPBM_path,
	      $imagepath,
	      $image,
	      $image_type,
	      $image_name,
	      $catdir,
	      $submit,
	      $database,
	      $uploads,
	      $rows,
	      $conversiontype,
	      $mosConfig_absolute_path;

	include($mosConfig_absolute_path.'/administrator/components/com_rsgallery/settings.rsgallery.php');
	//HTML_RSGALLERY::RSGalleryHeader();
	if ($submit)
		{
		//Opslaan en terug naar uploadscherm als er geen categorie is aangegeven
		if (!$_POST['catid'])
			{
			?>
			<script>
				alert("<?php echo _RSGALLERY_ALERT_NOCAT;?>");
				location = 'index2.php?option=com_rsgallery&task=upload';
			</script>
            		<?php
            		}

		//So there is a category, we continue
		//When you are here the files are uploaded but not in /uploadfiles!

		$cat_id = $_POST['catid'];

		for ( $t=0; $t < count($image); $t++)
			{
			//PDW 19-6-2004
			//remove spaces, copy to /uploadfiles.
			//ImportImage will do it from there.
			$i_name = SpaceToUnderscore($image_name[$t]);

			copy($image[$t], $mosConfig_absolute_path."/uploadfiles/".$i_name);

			$imported=ImportImage($i_name, $cat_id, $title2[$t], $descr[$t]);

                        switch ( $imported )
                               {
                               case 1:
				?>
				<script>
					alert("<?php echo _RSGALLERY_ALERT_UPLOADOK;?>");
					location = "index2.php?option=com_rsgallery&task=view_images";
				</script>
				<?php
                                case 2:
				?>
				<script>
					alert("<?php echo _RSGALLERY_ALERT_WRONGFORMAT;?>");
					location = "index2.php?option=com_rsgallery&task=view_images";
				</script>
				<?php
                                default:
				?>
				<script>
					alert("<?php echo _RSGALLERY_ALERT_NOWRITE;?>");
					location = "index2.php?option=com_rsgallery&task=upload";
				</script>
				<?php
				}
			} //End for
		} 
	else 
		{
		//It's not a submitted form. Show the upload form.
		$database->setQuery("SELECT * FROM #__rsgallery");
		$rows = $database->loadObjectList();
		HTML_RSGALLERY::showUpload();
		//HTML_RSGALLERY::RSGalleryFooter();
		}
}



function saveImage($option, $id)
	{
	global $database, $descr, $id, $xtitle;
	$xtitle = addslashes($xtitle);
	$descr = addslashes($descr);
	$xtitle = addslashes($xtitle);
	$database->setQuery("UPDATE #__rsgalleryfiles SET descr = '$descr', title = '$xtitle' WHERE id='$id'");
	if ($database->query())
		{
		//terug naar overzicht
		?>
		<script>
			alert("<?php echo _RSGALLERY_ALERT_IMAGEDETAILSOK;?>");
			location = "index2.php?option=com_rsgallery&task=view_images";
		</script>
		<?php
		}
	else
		{
		?>
		<script>
			alert("<?php echo _RSGALLERY_ALERT_IMAGEDETAILSNOTOK;?>");
			location = "index2.php?option=com_rsgallery&task=view_images";
		</script>
		<?php
		}
	}
function viewCategories2($s_id)
	{
	global $database;
	function RTreeRecurse($id, $indent, $prefix, &$list, &$children, $maxlevel=9999, $level=0)
		{
		// This function builds a linear list of the expanded tree of items
		// contained in the $children structure.  Each treename text field is
		// built from the db catname field, an indentation string, and a prefix
		// string.

		if (@$children[$id] && $level <= $maxlevel)
			{
			// For top categories, there is no indent or prefix
			if($id==0)
				$topCategory=true;
			else
				$topCategory=false;
			foreach ($children[$id] as $v)
				{
				// note that $children[$id] is an array of its own children
				$id = $v->id;
				$txt = $v->catname;
				$leaf->id = $id;
				$leaf->treename = $topCategory ?  $txt : "$indent$prefix$txt";
				$list[] = $leaf;
				if(!$topCategory)
					$indent .= $indent;
				RTreeRecurse( $id, $indent, $prefix, $list, $children, $maxlevel, $level+1 );
				}
			}
		return true;
		}
		/**
		* Generates an HTML select list from a tree based query list
		* @param array Source array with id and parent fields
		* @param array The id of the current list item
		* @param array Target array.  May be an empty array.
		* @param array An array of objects
		* @param string The value of the HTML name attribute
		* @param string Additional HTML attributes for the <select> tag
		* @param string The name of the object varible for the option value
		* @param string The name of the object varible for the option text
		* @param mixed The key that is selected
		* @returns string HTML for the select list
		*/
	function RStreeSelectList( &$src_list, $src_id, $tgt_list, $tag_name, $tag_attribs, $key, $text, $selected )
		{
		global $database, $rows;
		// establish the hierarchy of the menu
		$children = array();
		// first pass - collect children
		foreach ($src_list as $v )
			{
			$pt = $v->parent;
			$list = @$children[$pt] ? $children[$pt] : array();
			array_push( $list, $v );
			$children[$pt] = $list;
			}
		// second pass - get an indent list of the items
		$ilist = array();
		RTreeRecurse( 0, '', '--> ', $ilist, $children );

		// assemble menu items to the array
		foreach ($ilist as $item)
			{
			$tgt_list[] = mosHTML::makeOption( $item->id, $item->treename );
			}
			// build the html select list
			return mosHTML::selectList( $tgt_list, $tag_name, $tag_attribs, $key, $text, $selected );
		}
	///////////
	$database->setQuery("SELECT * FROM #__rsgallery ORDER BY parent, ordering");
	$rows = $database->getObjectList();
	echo RStreeSelectList( &$rows    , 'id'   , $tgt_list ,'treeselect', ''          , 'value', 'text', '' );
	}

//View categories new = Subcats possible
function viewCategories($option)
	{
	global $database, $mainframe;
	global $mosConfig_lang;
	include_once( "components/com_rsgallery/settings.rsgallery.php" );

	$limit = $mainframe->getUserStateFromRequest( "viewlistlimit", 'limit',10 );
	$limitstart = $mainframe->getUserStateFromRequest( "view{$option}limitstart",'limitstart', 0 );
	$levellimit = $mainframe->getUserStateFromRequest( "view{$option}limit",'levellimit', 10 );

	$database->setQuery("SELECT COUNT(*) FROM #__rsgallery");
	$total = $database->loadResult();

	require_once( "includes/pageNavigation.php" );
	$pageNav = new mosPageNav( $total, $limitstart, $limit  );

	// select the records
	// note, since this is a tree we have to do the limits code-side
	// PDW 8-8-2004
	// added the name to solve some notices on the screen. Mostreerecurse needs a name.
	$database->setQuery( "SELECT a.*, b.catname AS category,b.catname AS name"
		. "\nFROM #__rsgallery AS a"
		. "\nLEFT JOIN #__rsgallery AS b ON b.id = a.parent"
		. "\nORDER BY parent, ordering"
		);
	$rows = $database->loadObjectList();
	if ($database->getErrorNum())
		{
		echo $database->stderr();
		return false;
		}

	// establish the hierarchy of the menu
	$children = array();
	// first pass - collect children
	foreach ($rows as $v )
		{
		$pt = $v->parent;
		$list = @$children[$pt] ? $children[$pt] : array();
		array_push( $list, $v );
		$children[$pt] = $list;
		}

	// second pass - get an indent list of the items
	$list = mosTreeRecurse( 0, '', array(), $children, max( 0, $levellimit-1) );

	// slice out elements based on limits
	$list = array_slice( $list, $pageNav->limitstart, $pageNav->limit );
	HTML_RSGALLERY::viewCategories( $list, $pageNav, $option );
	}
//End View Categories new

function saveCategory($option, $id)
	{
	global $database, $imagepath, $catname, $catdir, $descr, $parent, $publ, $mosConfig_absolute_path, $show_full_description;
	include($mosConfig_absolute_path.'/administrator/components/com_rsgallery/settings.rsgallery.php');
	$show_full_description = $_POST['show_full_description'];
	$descr = addslashes($_POST['descr']);
	$catname = addslashes($_POST['catname']);
	if ($id)
		{
		$database->setQuery("UPDATE #__rsgallery SET catname = '$catname', description = '$descr' , parent = '$parent', published = '$publ', show_full_description = '$show_full_description' WHERE id='$id'");
		if ($database->query())
			{
			?>
			<script>
			alert('<?php echo _RSGALLERY_ALERT_CATDETAILSOK;?>');
			location = "index2.php?option=com_rsgallery&task=view_categories";
			</script>
			<?php
			}
		else
			{
			?>
			<script>
			alert('<?php echo _RSGALLERY_ALERT_CATDETAILSNOTOK;?>');
			location = "index2.php?option=com_rsgallery&task=view_categories";
			</script> 
			<?php
			}
		}
	else
		{

			if (trim($catname))
			{
				//Sla gegevens op in database
				$database->setQuery("SELECT MAX(ordering) FROM #__rsgallery");
				$ordering = $database->loadResult() + 1;
				$database->setQuery("INSERT INTO #__rsgallery (catname,description,ordering, parent, show_full_description, published) VALUES ('$catname', '$descr', '$ordering','$parent','$show_full_description','$publ')");
				if (!$database->query())
					{
					?>
					<script>
						alert('<?php echo _RSGALLERY_ALERT_NONEWCAT;?>');
						location = "index2.php?option=com_rsgallery&task=view_categories";
					</script>
					<?php
					}
				?>
				<script>
					alert('<?php echo _RSGALLERY_ALERT_NEWCAT;?>');
					location = "index2.php?option=com_rsgallery&task=view_categories";
				</script>
				<?php
			}
		}
	}

function newCategory($option, $cid)
	{
	global $database, $id, $rows;
	echo $cid;
	if ($cid)
		{
		$database->setQuery("SELECT * FROM #__rsgallery WHERE id = '$cid'");
		$rows = $database->loadObjectList();
		HTML_RSGALLERY::newCategory($option, $rows);
		}
	else
		{
		HTML_RSGALLERY::newCategory($option, $rows);
		}
	}

function deleteCategory($option, $cid=null)
	{
	global $database, $mosConfig_absolute_path, $imagepath;
	include_once($mosConfig_absolute_path."/administrator/components/com_rsgallery/settings.rsgallery.php");
	if(count($cid)>0)
		{
		foreach($cid as $catid)
			{
			//Data verwijderen
			$database->setQuery("DELETE FROM #__rsgallery WHERE id = '$catid'");
			if ($database->query())
				{
				//Delete images within gallery and gallery/thumbs directory
				$database->setQuery("SELECT name FROM #__rsgalleryfiles WHERE gallery_id = '$catid'");
				$files = $database->loadResultArray();
				foreach ($files as $file)
					{
					unlink($mosConfig_absolute_path.$imagepath.$file);
					unlink($mosConfig_absolute_path.$imagepath."thumbs/".$file);
					}
				$database->setQuery("DELETE FROM #__rsgalleryfiles WHERE gallery_id = '$catid'");
				$database->query();
				}
			else
				{
				//Terug naar overzicht
				?>
				<script>
					alert('<?php echo _RSGALLERY_ALERT_CATDELNOTOK;?>');
					location = "index2.php?option=com_rsgallery&task=view_categories";
				</script>
				<?php
				}
			}
		reorderRSGallery('#__rsgallery');
		?>
		<script>
			alert('<?php echo _RSGALLERY_ALERT_CATDELOK;?>');
			location = "index2.php?option=com_rsgallery&task=view_categories";
		</script>
		<?php
		}
	else
		{
		//Terug naar overzicht
		echo "Count nul";
		?>
		<script>
			alert("<?php echo _RSGALLERY_ALERT_NOCAT;?>");
			location = "index2.php?option=com_rsgallery&task=view_categories";
		</script>
		<?php
		}
	}

function showConfig($option, $mosConfig_absolute_path)
	{
	//HTML_RSGALLERY::RSGalleryHeader();
	include_once("components/com_rsgallery/settings.rsgallery.php");

	$configfile = "components/com_rsgallery/settings.rsgallery.php";
	@chmod ($configfile, 0766);
	$cssfile = "../components/com_rsgallery/rsgallery.css";
	@chmod ($cssfile, 0766);
	$permission = is_writable($configfile);
	if (!$permission)
		{
		echo "<center><h1><font color=red>Warning...</FONT></h1>";
		echo "<B>Your config file is /administrator/$configfile</b><BR>";
		echo "<B>You need to chmod this to 766 in order for the config to be updated</B></center><BR>";
		$warning=1;
		}
	$permission = is_writable($cssfile)  && is_readable($cssfile);
	if (!$permission)
		{
		if(!isset($warning)) echo "<center><h1><font color=red>Warning...</FONT></h1>";
		else echo "<BR/>";
		echo "<B>Your css file is $cssfile</b><BR>";
		echo "<B>You need to chmod this to 766 in order for the styling to be updated</B></center><BR>";
		}

      	// do auto-detection on the available graphics libraries
        // This assumes the executables are within the path of the shell's path
        // For Windows hosts, may need to do an exec with a command shell to use that
        // path info
		$imageLibs=array();
        $shell_cmd='';
        if(substr(PHP_OS, 0, 3) == 'WIN') $shell_cmd = getenv( "COMSPEC" ) . " /C ";
        unset($output);
        @exec($shell_cmd.'convert -version',  $output, $status);
        if(!$status){
            if(preg_match("/imagemagick[ \t]+([0-9\.]+)/i",$output[0],$matches))
               $imageLibs['imagemagick'] = $matches[0];
        }
        unset($output);
        @exec($shell_cmd. 'jpegtopnm -version 2>&1',  $output, $status);
        if(!$status){
            if(preg_match("/netpbm[ \t]+([0-9\.]+)/i",$output[0],$matches))
               $imageLibs['netpbm'] = $matches[0];
        }
        $GDfuncList = get_extension_funcs('gd');
        ob_start();
        @phpinfo(INFO_MODULES);
        $output=ob_get_contents();
        ob_end_clean();
        $matches[1]='';
        if(preg_match("/GD Version[ \t]*(<[^>]+>[ \t]*)+([^<>]+)/s",$output,$matches)){
            $gdversion = $matches[2];
        }
        if( $GDfuncList ){
         if( in_array('imagegd2',$GDfuncList) )
            $imageLibs['gd2'] = $gdversion;
         else
            $imageLibs['gd1'] = $gdversion;
        }
         if(array_key_exists('imagemagick',$imageLibs))
            $conversiontype=1;
         elseif(array_key_exists('netpbm',$imageLibs))
            $conversiontype=2;
         elseif(array_key_exists('gd1',$imageLibs))
               $conversiontype=3;
         elseif(array_key_exists('gd2',$imageLibs))
            $conversiontype=4;
         else $conversiontype=0;

        $conf_style='';
	If(is_readable($cssfile)){
	    $css = fopen($cssfile, 'r');
		$conf_style = fread($css, filesize($cssfile));
		fclose($css);
		}

	HTML_RSGALLERY::showSettings($option, isset($rows)? $rows : NULL, $conf_style, $imageLibs, $conversiontype);
	//HTML_RSGALLERY::RSGalleryFooter();
	}

//function saveConfig($option, $conversiontype,$inline,$imagepath,$IM_path,$NETPBM_path,$size,$JPEGquality,$columns,$PageSize,$counter,$nbfiles,$currfile,$file,$isAdmin,$isUser,$CurrUID,$StartRow)
function saveConfig($option)
	{
	global $displayDesc, $displayVoting, $displayRandom, $displayLatest, $displayComments, $displayEXIF, $img_details, $mosConfig_absolute_path, $PicWidth, $ResizeOption, $MaxWidthPopup, $conf_style, $conversiontype, $inline, $dropdown, $size, $JPEGquality, $imagepath, $FTP_path, $IM_path, $NETPBM_path, $columns, $PageSize, $intro_text, $userupload, $reg_upload, $user_cat, $max_user_cat, $max_images;
	$configfile = "components/com_rsgallery/settings.rsgallery.php";
	$cssfile = "../components/com_rsgallery/rsgallery.css";
	@chmod ($configfile, 0766);
	@chmod ($cssfile, 0766);
	$permission = is_writable($configfile);
	if (!$permission)
		{
		$mosmsg = "Config File Not writeable";
		mosRedirect("index2.php?option=$option&task=settings",$mosmsg);
		break;
		}

 	// massage the $imagepath value so it functions properly
        $imagepath=preg_replace('/\\\\/','/',$imagepath);
        $imagepath = preg_replace('/(\/)+/','/',$imagepath);
        $imagepath=trim($imagepath);
        $imagepath=trim($imagepath, '/');
        $imagepath='/'.$imagepath.'/';

	// BEGIN: Troozers Modification
	// massage the $FTP_path value to it functions properly
        $FTP_path=preg_replace('/\\\\/','/',$FTP_path);
        $FTP_path = preg_replace('/(\/)+/','/',$FTP_path);
        $FTP_path=trim($FTP_path);
        $FTP_path=trim($FTP_path, '/');
        $FTP_path='/'.$FTP_path.'/';
	// END: Troozers Modification


        if(substr(PHP_OS, 0, 3) == 'WIN'){
            //make sure thumb program paths use backslashes
            $IM_path=preg_replace('/\//','\\',$IM_path);
            $NETPBM_path=preg_replace('/\//','\\',$NETPBM_path);
            $IM_path = trim($IM_path); $NETPBM_path = trim($NETPBM_path);
            if($IM_path != '' && $IM_path != '\\'){
               $IM_path = rtrim($IM_path,'\\');
               $IM_path .= '\\';
            }
            if($NETPBM_path != '' && $NETPBM_path != '\\'){             
               $NETPBM_path = rtrim($NETPBM_path,'\\');
               $NETPBM_path .= '\\';
            }
        } else {
            $IM_path=str_replace('\\\\','/',$IM_path);
            $NETPBM_path=str_replace('\\\\','/',$NETPBM_path);
            $IM_path = trim($IM_path);
            $NETPBM_path = trim($NETPBM_path);
            if($IM_path != '' && $IM_path != '/'){
               $IM_path = rtrim($IM_path,'/');
               $IM_path .= '/';
            }
            if($NETPBM_path != '' && $NETPBM_path != '/'){             
               $NETPBM_path = rtrim($NETPBM_path,'/');
               $NETPBM_path .= '/';
            }
        }

	$txt  = "";
	$txt .= "\$conversiontype	= $conversiontype;\n";
	$txt .= "\$inline		= $inline;\n";
	$txt .= "\$dropdown		= $dropdown;\n";
	$txt .= "\$imagepath		=\"$imagepath\";\n";
	$txt .= "\$IM_path		=\"$IM_path\";\n";
	$txt .= "\$NETPBM_path		=\"$NETPBM_path\";\n";
	$txt .= "\$size			=\"$size\";\n";
	$txt .= "\$JPEGquality		=\"$JPEGquality\";\n";
	$txt .= "\$columns		= $columns;\n";		 
	$txt .= "\$PageSize		= $PageSize;\n";
	$txt .= "\$PicWidth		= \"$PicWidth\";\n";
	// BEGIN: Troozers Modification
	$txt .= "\$FTP_path		= \"$FTP_path\";\n";
	$txt .= "\$ResizeOption		= $ResizeOption;\n";
	// END: Troozers Modification
	// BEGIN: PDW Modification
	// The max width of the image in the popup
	$txt .= "\$MaxWidthPopup 	=$MaxWidthPopup;\n";
	// END: PDW Modification
	$txt .= "\$intro_text		= \"".htmlspecialchars($intro_text, ENT_QUOTES)."\";\n";
	$txt .= "\$counter		= 0;\n";
	$txt .= "\$nbfiles		= 0;\n";
	$txt .= "\$currfile		=\"\";\n";
	$txt .= "\$file[0]		=\"\";\n";
	$txt .= "\$isAdmin		= False;\n";
	$txt .= "\$isUser		= False;\n";
	$txt .= "\$CurrUID		= -1;\n";
	$txt .= "\$StartRow		= 0;\n";
	$txt .= "\$displayRandom	= $displayRandom;\n";
	$txt .= "\$displayLatest	= $displayLatest;\n";
	$txt .= "\$displayDesc		= $displayDesc;\n";
	$txt .= "\$displayVoting	= $displayVoting;\n";
	$txt .= "\$displayComments	= $displayComments;\n";
	$txt .= "\$displayEXIF		= $displayEXIF;\n";
	$txt .= "\$userupload		= $userupload;\n";
	$txt .= "\$reg_upload		= $reg_upload;\n";
	$txt .= "\$user_cat		= $user_cat;\n";
	$txt .= "\$max_user_cat		= $max_user_cat;\n";
	$txt .= "\$max_images		= $max_images;\n";
	echo "$txt";

	$config = "<?php\n";
	$config .= $txt;
	$config .= "";
	$config .= "?>";

	if ($fp = fopen("$cssfile", "r")){
            $old_conf_style = fread($fp,filesize($cssfile));
            fclose($fp);
        }
        if($old_conf_style != $conf_style){
            if (is_writeable($cssfile)){
               // go update stylesheet
               $fp=fopen($cssfile, "w");
               fputs($fp, $conf_style, strlen($conf_style));
               fclose($fp);
               $style_saved=1;
            }
         } // otherwise we ignore it since we already warned user

	if ($fp = fopen("$configfile", "w"))
		{
		fputs($fp, $config, strlen($config));
		fclose ($fp);
		$config_saved=1;
		}
	else
		{
		echo "Niet gelukt!";
		}
		// Tell me it is saved
        if(isset($config_saved))
            $mosmsg = "Configuration file saved!";
        if(isset($style_saved)){
           if(isset($config_saved)) $mosmsg .= "  -  ";
           $mosmsg .= "StyleSheet file saved!";
        }
        if(isset($config_saved) || isset($style_saved))
            mosRedirect("index2.php?option=com_rsgallery&task=settings",$mosmsg);
	}
//--------------------------------------------------------------------------
function viewImages($option)
	{
	//HTML_RSGALLERY::RSGalleryHeader();


	global $option, $database, $mainframe, $xid, $mosConfig_absolute_path;
	//
	$catid = $mainframe->getUserStateFromRequest( "catid{$option}", 'catid', 0 );
	$catChanged = $mainframe->getUserStateFromRequest( "catChanged{$option}", 'catChanged', 0 );
	$limit = $mainframe->getUserStateFromRequest( "viewlistlimit", 'limit', 10 );
	$limitstart = $mainframe->getUserStateFromRequest( "view{$option}limitstart", 'limitstart', 0 );
	$search = $mainframe->getUserStateFromRequest( "search{$option}", 'search', '' );
	$search = $database->getEscaped( trim( strtolower( $search ) ) );

	// dmcd mar 6/04  to resolve bug #33 where paging goes wacko after
	// category filter select is changed, we need to detect this select
	// field change and reset limitstart back to 0.  Need a new hidden
	// input called 'catChanged'

	if ($catid > 0)
		{
		$sql = "SELECT count(*) FROM #__rsgalleryfiles AS a".
                  "\nWHERE a.gallery_id='$catid'";
		}
	else
		{
		$sql = "SELECT count(*) FROM #__rsgalleryfiles AS a";
		}
	//get the total number of records
	$database->setQuery($sql);
	$total = $database->loadResult();
	echo $database->getErrorMsg();

	include_once( $mosConfig_absolute_path."/administrator/includes/pageNavigation.php" );
	if($catChanged) $limitstart=0;
	$pageNav = new mosPageNav( $total, $limitstart, $limit  );
	$where = array();

	if ($catid > 0)
		{

		$sql2 = "SELECT a.hits as ahits,a.id as xid,a.ordering as fordering, a.*,b.*  FROM #__rsgalleryfiles as a, #__rsgallery as b".
                  "\n WHERE (a.gallery_id = b.id AND b.id = '$catid')".
                  "\n ORDER BY a.ordering".
                  "\n LIMIT $pageNav->limitstart,$pageNav->limit";
		}
	else
		{
		$sql2 = "SELECT a.hits as ahits,a.id as xid,a.ordering as fordering, a.*,b.* FROM #__rsgalleryfiles as a, #__rsgallery as b".
                "\n WHERE a.gallery_id = b.id".
                "\n ORDER BY b.ordering, a.ordering".
                "\n LIMIT $pageNav->limitstart,$pageNav->limit";
		}

	$database->setQuery($sql2);	
	$rows = $database->loadObjectList();
	if ($database->getErrorNum()) {
		echo $database->stderr();
		return false;
	}

	// get list of categories
	$categories[] = mosHTML::makeOption( '0', 'View Category' );
	$categories[] = mosHTML::makeOption( '-1', '- All Categories' );
	$database->setQuery( "SELECT id AS value, catname AS text FROM #__rsgallery"
		. "\n ORDER BY catname" );
	$dbCategories = $database->loadObjectList();
    $categories = array_merge( $categories, $dbCategories );

	$clist = mosHTML::selectList( $categories, 'catid', 'class="inputbox" size="1" onchange="document.adminForm.catChanged.value=1;document.adminForm.submit();"',
		'value', 'text', $catid );
	$categories[0] = mosHTML::makeOption( '0', 'Select Category' );
    array_splice($categories, 1, 1);
  	$clist2 = mosHTML::selectList( $categories, 'catmoveid', 'class="inputbox" size="1" ', 'value', 'text', 0 );

	// dmcd jan 12/04  tally total pics per category/gallery
        $database->setQuery("SELECT id FROM #__rsgallery");
        $catss = $database->loadResultArray();
 foreach($catss as $cat){
            $database->setQuery("SELECT MAX(ordering), MIN(ordering) FROM #__rsgalleryfiles WHERE gallery_id = '$cat'");
            $maxmin = $database->loadRow();
            $cat_ordering_max[$cat] = $maxmin[0];
			$cat_ordering_min[$cat] = $maxmin[1];
       }
        //asdbg_break();
        HTML_RSGALLERY::viewImages( $option, $rows, $clist, $clist2, $search, $pageNav, $cats, $cat_ordering_min, $cat_ordering_max );
	//HTML_RSGALLERY::RSGalleryFooter();
}

// dmcd jan 6/04 added this function to retrieve old values of rsgallery settings to detect config changes
function getOldSetting($varStr){
   global $mosConfig_absolute_path;
   include ($mosConfig_absolute_path."/administrator/components/com_rsgallery/settings.rsgallery.php");
   return $$varStr;
}

/**
 * This function is used to handle the RSGallery ordering tasks (I.e. the user indicating
 * that they want to display a given image and/or category before or after another one.)
 */				
function orderRSGallery( $id, $inc, $option, $task ) {
   global $database;
   // reorder categories or pics within a category
//asdbg_break();

switch ($task){
      case "images_orderup":
      case "images_orderdown":
         $table = "#__rsgalleryfiles";
         $where = "gallery_id = '\$row->gallery_id'";
         $new_task = "view_images";
         break;

	  default:
         $table = "#__rsgallery";
         $where = NULL;
         $new_task = "view_categories";
         break;      
   }

   $sql = "SELECT * FROM $table WHERE id = $id";
   $database->setQuery( $sql );
   $database->loadObject($row);

   eval("\$where=\"$where\";");
   $sql = "SELECT id, ordering FROM $table";
   if ($inc < 0) {
      $sql .= "\nWHERE ordering < '$row->ordering'";
      $sql .= ($where ? "\n	AND $where" : '');
      $sql .= "\nORDER BY ordering DESC\nLIMIT 1";
   } else if ($inc > 0) {
      $sql .= "\nWHERE ordering > '$row->ordering'";
      $sql .= ($where ? "\n	AND $where" : '');
      $sql .= "\nORDER BY ordering\nLIMIT 1";
   } else {
      $sql .= "\nWHERE ordering = '$row->ordering'";
      $sql .= ($where ? "\n	AND $where" : '');
      $sql .= "\nORDER BY ordering\nLIMIT 1";
   }

   $database->setQuery( $sql );
   $adj_row = null;
   if ($database->loadObject( $adj_row )) {
      $database->setQuery( "UPDATE $table SET ordering='$row->ordering'"
	 . "\nWHERE id='".$adj_row->id."'");
      $database->query();
      $database->setQuery( "UPDATE $table SET ordering='$adj_row->ordering'"
	 . "\nWHERE id='".$row->id."'");
      $database->query();
   } else {
      // no adjacent row: either the only row or already the first or last row
      // what is this really doing?
      $database->setQuery( "UPDATE $table SET ordering='$row->ordering'"
	 . "\nWHERE id='".$id."'");
      $database->query();
   }

   // go back to RSGallery category or image listing
   mosRedirect( "index2.php?option=$option&task=".$new_task );
}


function reorderRSGallery ($tbl, $where = NULL ) {
   // reorders either the categories or images within a category
   // it is necessary to call this whenever a shuffle or deletion is performed
   global $database;

//   asdbg_break();
   $database->setQuery( "SELECT id, ordering FROM $tbl"
      . ($where ? "\nWHERE $where" : '')
      . "\nORDER BY ordering"
      );
   if (!($rows = $database->loadObjectList())) {
      return false;
   }
   // first pass, compact the ordering numbers
   $n=count( $rows );

   for ($i=0;  $i < $n; $i++) {
//      if ($rows[$i]->ordering > 0) {
	 $rows[$i]->ordering = $i+1;
	 $database->setQuery( "UPDATE $tbl"
	    . "\nSET ordering='".$rows[$i]->ordering."' WHERE id ='".$rows[$i]->id."'"
	    );
	 $database->query();
//      }
   }

   return true;
}

function consolidateDbInform($option){
	// inform user of purpose of this function, then provide a proceed button
	//HTML_RSGALLERY::RSGalleryHeader();
    echo '<p align="justify"><br/>'._RSGALLERY_CONSOLIDATE_DB.'<br/></p>';
?>
    <script language="Javascript">
        function submitbutton(pressbutton){
            if (pressbutton != 'cancel'){
                submitform( pressbutton );
                return;
            } else {
                window.history.go(-1);
                return;
            }
        }
	</script>
	<form action="index2.php" method="post" name="adminForm">
	<table cellpadding="4" cellspacing="0" border="0" width="100%" align="center">
		<tr>
			<td align="right">
				<input type="button" name="consolidate_db_go" value="<?php echo _RSGALLERY_PROCEED ?>" class="button"
				   onClick="submitbutton('consolidate_db_go');" />
			</td>
			<td align="left">
				<input type="button" name="cancel" value="<?php echo _RSGALLERY_CANCEL ?>" class="button"
				   onClick="submitbutton('cancel');" />
			</td>
		</tr>
	</table>
	<input type="hidden" name="option" value="<?php echo $option;?>" />
	<input type="hidden" name="task" value="" />
	</form>

<?php	//HTML_RSGALLERY::RSGalleryFooter();
}

function consolidateDbGo($option)
	{
	// do datbase, file base consolidation
	echo "feature not yet implemented. To follow.<br><br><br>Ronald Smit";
	}

function import_captions()
	{
	echo "Feature not yet implemented. To follow.<br><br><br>Ronald Smit";
	}

//--------------------------------------------------------------------------

?>
