<?php
//Language file

//admin.rsgallery.html.php
// dmcd jan 11/04 added new define for admin reorder field
DEFINE("_RSGALLERY_REORDER",			"Reorder");
DEFINE("_RSGALLERY_ADMIN_TITLE",		"RSGallery administrator");
DEFINE("_RSGALLERY_VERSION",			"RSGallery2 beta1");
DEFINE("_RSGALLERY_PROP_TITLE",		"Edit image properties");
DEFINE("_RSGALLERY_TITLE",				"Title");
DEFINE("_RSGALLERY_FILENAME",			"Filename");
DEFINE("_RSGALLERY_DESCR",				"Description");
DEFINE("_RSGALLERY_NODESCR",			"No Description");
DEFINE("_RSGALLERY_VERYGOOD",			"&nbsp;Very Good&nbsp;");
DEFINE("_RSGALLERY_GOOD",				"&nbsp;Good&nbsp;");
DEFINE("_RSGALLERY_OK",			      "&nbsp;Ok&nbsp;");
DEFINE("_RSGALLERY_BAD",				"&nbsp;Bad&nbsp;");
DEFINE("_RSGALLERY_VERYBAD",			"&nbsp;Very Bad&nbsp;");
DEFINE("_RSGALLERY_NO_RATINGS",		"No Ratings Yet!");
DEFINE("_RSGALLERY_TAB1_SETTINGS",	"Admin Settings");
DEFINE("_RSGALLERY_TAB2_SETTINGS",	"Appearance");
DEFINE("_RSGALLERY_TAB3_SETTINGS",	"Stylesheet");
DEFINE("_RSGALLERY_TAB4_SETTINGS",	"User Uploads");
DEFINE("_RSGALLERY_THUMB_GEN",		"Thumbnail generator");
DEFINE("_RSGALLERY_THUMB_WIDTH",		"Thumbnail width");
DEFINE("_RSGALLERY_THUMB_QUAL",		"Thumbnail quality");
DEFINE("_RSGALLERY_INLINE",			"Inline/popup");
DEFINE("_RSGALLERY_IMAGEPATH",		"Gallery Subdir (below MOS root)");
DEFINE("_RSGALLERY_FTPPATH",      	"FTP Path");
DEFINE("_RSGALLERY_AUTO_DETECTED",	"auto-detected  Version: ");
DEFINE("_RSGALLERY_NETPBMPATH",		"NETPBM path");
DEFINE("_RSGALLERY_IMAGEMAGICKPATH","ImageMagick path");
DEFINE("_RSGALLERY_NUMCOLUMNS",		"Number of columns");
DEFINE("_RSGALLERY_NUMPICS",			"Number of pictures");
DEFINE("_RSGALLERY_PICWIDTH",			"Width of full picture");
DEFINE("_RSGALLERY_RESIZEPIC",    	"Resize Options");
DEFINE("_RSGALLERY_FRONTMENU",		"Frontmenu");
DEFINE("_RSGALLERY_INTROTEXT",		"Introtext");
DEFINE("_RSGALLERY_CATNAME",			"Gallery name");
DEFINE("_RSGALLERY_CATDESCR",			"Description");
DEFINE("_RSGALLERY_CATHITS",			"Hits");
DEFINE("_RSGALLERY_CATPUBLISHED",	"Published");
DEFINE("_RSGALLERY_NEWCAT",			"New gallery");
DEFINE("_RSGALLERY_UPLOAD_TITLE",	"Upload");
DEFINE("_RSGALLERY_UPLOAD_NUMBER",	"Number of uploads");
DEFINE("_RSGALLERY_FORM_INGALLERY",	"In gallery");
DEFINE("_RSGALLERY_PICK",				"Pick a gallery");
DEFINE("_RSGALLERY_UPLOAD_FORM_TITLE","Title");
DEFINE("_RSGALLERY_UPLOAD_FORM_FILE","File");
DEFINE("_RSGALLERY_UPLOAD_FORM_THUMB","Thumbfile");
DEFINE("_RSGALLERY_NUMDISPLAY",		"Display #");
DEFINE("_RSGALLERY_SEARCH",			"Search");
DEFINE("_RSGALLERY_IMAGENAME",		"Name");
DEFINE("_RSGALLERY_IMAGEFILE",		"Filename");
DEFINE("_RSGALLERY_IMAGECAT",			"Gallery");
DEFINE("_RSGALLERY_IMAGEHITS",		"Hits");
DEFINE("_RSGALLERY_IMAGEDATE",		"Date upload");
DEFINE("_RSGALLERY_DELETE",			"Delete");
DEFINE("_RSGALLERY_MOVETO",			"Move To");
DEFINE("_RSGALLERY_ID",			    	"ID");
DEFINE("_RSGALLERY_TAB_1",			   "Description");
DEFINE("_RSGALLERY_TAB_2",			   "Vote");
DEFINE("_RSGALLERY_TAB_3",			   "Comments");
DEFINE("_RSGALLERY_TAB_4",			   "EXIF-information");
DEFINE("_RSGALLERY_VOTES",			   "Vote");
DEFINE("_RSGALLERY_VOTES_NR",			"Votes");
DEFINE("_RSGALLERY_VOTES_AVG",		"Average Vote");
DEFINE("_RSGALLERY_THANK_VOTING",	"Thank you for voting");
DEFINE("_RSGALLERY_VOTING_FAILED",	"Your vote has failed");
DEFINE("_RSGALLERY_RATING_NOTSELECT","Please select value");
DEFINE("_RSGALLERY_NO_COMMENTS",		"No Comments Yet!");
DEFINE("_RSGALLERY_COMMENT_ADD",		"Add a Comment");
DEFINE("_RSGALLERY_COMMENT_NAME",   "Your Name");
DEFINE("_RSGALLERY_COMMENT_TEXT",   "Your Comment");
DEFINE("_RSGALLERY_COMMENT_DATE",   "Date");
DEFINE("_RSGALLERY_COMMENT_BY",     "Comment by");
DEFINE("_RSGALLERY_COMMENT_FIELD_CHECK","Please enter name and/or comment!");
DEFINE("_RSGALLERY_COMMENT_ADDED",		"Comment succesfully added!");
DEFINE("_RSGALLERY_COMMENT_NOT_ADDED",	"Comment not added!");
DEFINE("_RSGALLERY_SHOWDETAILS", 		"Show image details");
DEFINE("_RSGALLERY_UPLOAD_BUTTON_DESC","Save button does not work, use this one instead!!");
DEFINE("_RSGALLERY_YES",					"Yes");
DEFINE("_RSGALLERY_NO",						"No");

//admin.rsgallery.php
DEFINE("_RSGALLERY_ALERT_NOCAT",			"No gallery selected!\\nWe will take you back to the previous screen.");
DEFINE("_RSGALLERY_ALERT_NOWRITE",			"Upload failed.\\nBack to uploadscreen");
DEFINE("_RSGALLERY_ALERT_WRONGFORMAT",		"Wrong image format.\\nWe will redirect you to the upload screen");
DEFINE("_RSGALLERY_ALERT_UPLOADTHUMBOK",	"Thumbnail uploaded succesfully!");
DEFINE("_RSGALLERY_ALERT_UPLOADOK",			"Image uploaded succesfully!");
DEFINE("_RSGALLERY_ALERT_IMAGEDETAILSOK",	"Details updated succesfully!");
DEFINE("_RSGALLERY_ALERT_IMAGEDETAILSNOTOK","Details not updated!");
DEFINE("_RSGALLERY_ALERT_CATDETAILSOK",		"Gallery details updated!");
DEFINE("_RSGALLERY_ALERT_CATDETAILSNOTOK",	"Could not update gallery details!");
DEFINE("_RSGALLERY_ALERT_NEWCAT",			"New gallery created!");
DEFINE("_RSGALLERY_ALERT_NONEWCAT",			"Gallery could not be created!\\nWe wil take you back to the previous screen.");
DEFINE("_RSGALLERY_ALERT_CATDELOK",			"Gallery deleted!");
DEFINE("_RSGALLERY_ALERT_CATDELNOTOK",		"Gallery could not be deleted!");
DEFINE("_RSGALLERY_ALERT_IMGDELETEOK",		"Image(s) deleted succesfully!");
DEFINE("_RSGALLERY_ALERT_NOCATSELECTED",	"Please select gallery for ALL images!\\n(Also for images that will be deleted.\\nnThis will be corrected in future version!)");//New!!!
DEFINE("_RSGALLERY_CANCEL",					"Cancel");
DEFINE("_RSGALLERY_PROCEED",				"Proceed");
DEFINE("_RSGALLERY_CONSOLIDATE_DB",
"The 'Consolidate Database' function performs a check on the RSGallery database tables and the physical image".
" files in the gallery directory, and generates a report based on discrepancies found.  The user will then have".
" the option of adding or deleting database entries or physical image files to maintain consistency in the".
" galleries.<br/><br/>This function should also be run if any additions or deletions are done to any image files".
" contained within the gallery directory.  EG. A user can FTP additional image files into the gallery subdirectory".
" and then call this function to update the database.<br/><br/>Please chose 'Proceed' or 'Cancel' below.  No".
" changes will occur until the user confirms them.<br/>");


//rsgallery.php

DEFINE("_RSGALLERY_COMPONENT_TITLE",		"Gallery");
DEFINE("_RSGALLERY_GALLERY_PICK",			"Pick a gallery");
DEFINE("_RSGALLERY_GALLERY_TEXT",			"Choose your introtext here");
DEFINE("_RSGALLERY_NUMBEROFPICS",			"# pics");
DEFINE("_RSGALLERY_BACKBUTTON",				"Back");
DEFINE("_RSGALLERY_NOIMG",					"No images in gallery");
DEFINE("_RSGALLERY_IMGS",					" image(s) found - ");
DEFINE("_RSGALLERY_PAGE",					" Page ");
DEFINE("_RSGALLERY_OF",						" of ");
DEFINE("_RSGALLERY_MAX_USERCAT_ALERT"		,"Maximum number of galleries already made, taking you back to main screen");
//slideshow.rsgallery.php
DEFINE("_RSGALLERY_SETSPEED"					,"Set speed first!");

//New
DEFINE("_RSGALLERY_NOT_LOGGED_IN_COMMENT"	,"Please login to add a comment.");
DEFINE("_RSGALLERY_NOT_LOGGED_IN_VOTE"		,"Please login to vote.");
DEFINE("_RSGALLERY_USERUPLOAD_TITLE"		,"User Upload");
DEFINE("_RSGALLERY_USERUPLOAD_TEXT",
"First make sure you created a gallery. Your file will be uploaded automatically to the Server and thumbnails will be created.".
" This gallery is only available to you, when you are logged in. To make it public, change the properties.".
" <br/>You can upload single files".
" as well as ZIP-files.<br/><br/>");


DEFINE("_RSGALLERY_CATLEVEL"					,"Top gallery");
DEFINE("_RSGALLERY_SUBCAT"						,"Sub-categories");
DEFINE("_RSGALLERY_RANDOM_TITLE"				,"Random images");

DEFINE("_RSGALLERY_CREATED_BY"				,"Gallery created by ");
DEFINE("_RSGALLERY_MAX_IMAGES"				,"Maximum number of images per gallery");
DEFINE("_RSGALLERY_MAX_USERCAT"				,"Maximum number of galleries per user");
DEFINE("_RSGALLERY_USERGAL_HEADER"			,"User galleries");
DEFINE("_RSGALLERY_DELCAT_TEXT"				,"Are you sure you want to delete this gallery?\\nIf this gallery still holds images, these will be deleted as well.");
DEFINE("_RSGALLERY_USERCAT_NOTOWNER"		,"You are not the owner of this gallery, taking you back to the main screen");

DEFINE("_RSGALLERY_USERCAT_HEADER"			,"User galleries");
DEFINE("_RSGALLERY_USERCAT_NAME"				,"Gallery name");
DEFINE("_RSGALLERY_USERCAT_EDIT"				,"Edit");
DEFINE("_RSGALLERY_USERCAT_DELETE"			,"Delete");
DEFINE("_RSGALLERY_USERCAT_ACL"				,"ACL");
DEFINE("_RSGALLERY_NEW_7DAYS"					,"New in the last 7 days");
DEFINE("_RSGALLERY_NEW"							,"NEW");
DEFINE("_RSGALLERY_DELIMAGE_TEXT"			,"Are you sure you want to delete this image?");
DEFINE("_RSGALLERY_DELIMAGE_OK"				,"Image is deleted");
DEFINE("_RSGALLERY_UPLOAD_ALERT_CAT"		,"You must provide a category.");
DEFINE("_RSGALLERY_UPLOAD_ALERT_FILE"		,"You must provide a file to upload.");
DEFINE("_RSGALLERY_UPLOAD_ALERT_TITLE"		,"You must provide a title for the picture to be uploaded.");
DEFINE("_RSGALLERY_MAKECAT_ALERT_NAME"		,"You must provide a category name.");
DEFINE("_RSGALLERY_MAKECAT_ALERT_DESCR"	,"You must provide a description.");
DEFINE("_RSGALLERY_LATEST_TITLE"				,"Latest Titles");
DEFINE("_RSGALLERY_MAXWIDTHPOPUP"			,"Maximum width of popup");
DEFINE("_RSGALLERY_SHOWFULLDESC"				,"Show full descriptions in gallery view.");

// Slideshow settings.
DEFINE("_RSGALLERY_SLIDESHOW"		        	,"Slideshow");

?>
