<?php
//RSItems - show random pictures, latest, most popular and most votes //
//German (informal) language file by Daniel Tulp

/**
* RSGallery2 Items - Random, Latest, Popular, Most Voted
* @ package Joomla! Open Source
* @ Based on the RSitems module from Errol Elumir
* @ Modified for use with RSgallery2 by Daniel Tulp
* @ Joomla! Open Source is Free Software
* @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @ version 1.4.2
**/

DEFINE("_RSITEMS_RANDOM",	"Zufall");
DEFINE("_RSITEMS_LATEST",	"Neueste");
DEFINE("_RSITEMS_POPULAR",	"Beliebt");
DEFINE("_RSITEMS_VOTES",	"Meiste Stimmen");
DEFINE("_RSITEMS_RATED",	"Bestbewertet");
DEFINE("_RSITEMS_MCOMMENT",	"Meiste Kommentare");
DEFINE("_RSITEMS_LCOMMENT",	"Zuletzt kommentiert");

DEFINE("_RSITEMS_DATE",	"Datum: ");
DEFINE("_RSITEMS_HITS",	"Treffer: ");
DEFINE("_RSITEMS_VOTESCOUNT","Abgestimmt: "); 
DEFINE("_RSITEMS_AVERAGE","Durchschnitt: "); 
DEFINE("_RSITEMS_RANK","Rang: ");

DEFINE("_RSITEMS_COMMENT"," Kommentar");
DEFINE("_RSITEMS_COMMENTS"," Kommentare");
DEFINE("_RSITEMS_LAST","Zuletzt: ");
DEFINE("_RSITEMS_BY", "Von: ");
?>