<?php
//RSItems - show random pictures, latest, most popular and most votes //
//Dutch language file by Daniel Tulp

/**
* RSGallery2 Items - Random, Latest, Popular, Most Voted
* @ package Joomla! Open Source
* @ Based on the RSitems module from Errol Elumir
* @ Modified for use with RSgallery2 by Daniel Tulp
* @ Joomla! Open Source is Free Software
* @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @ version 1.4.2
**/

DEFINE("_RSITEMS_RANDOM",	"Willekeurig");
DEFINE("_RSITEMS_LATEST",	"Laatste ");
DEFINE("_RSITEMS_POPULAR",	"Populair");
DEFINE("_RSITEMS_VOTES",	"Meeste stemmen");
DEFINE("_RSITEMS_RATED",	"Beste");
DEFINE("_RSITEMS_MCOMMENT",	"Meeste commentaar");
DEFINE("_RSITEMS_LCOMMENT",	"Laatste commentaar");

DEFINE("_RSITEMS_DATE",	"Datum: ");
DEFINE("_RSITEMS_HITS",	"Bezoeken: ");
DEFINE("_RSITEMS_VOTESCOUNT","Gestemd: "); 
DEFINE("_RSITEMS_AVERAGE","Gemiddeld: "); 
DEFINE("_RSITEMS_RANK","Positie: ");

DEFINE("_RSITEMS_COMMENT"," commentaar");
DEFINE("_RSITEMS_COMMENTS"," commentaren");
DEFINE("_RSITEMS_LAST","Laatste: ");
DEFINE("_RSITEMS_BY", "Door: ");
?>