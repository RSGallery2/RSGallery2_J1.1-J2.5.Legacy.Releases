<?php
//RSItems - show random pictures, latest, most popular and most votes //
//English language file by Daniel Tulp

/**
* RSGallery2 Items - Random, Latest, Popular, Most Voted
* @ package Joomla! Open Source
* @ Based on the RSitems module from Errol Elumir
* @ Modified for use with RSgallery2 by Daniel Tulp
* @ Joomla! Open Source is Free Software
* @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @ version 1.4.2
**/

DEFINE("_RSITEMS_RANDOM",	"Random");
DEFINE("_RSITEMS_LATEST",	"Latest");
DEFINE("_RSITEMS_POPULAR",	"Popular");
DEFINE("_RSITEMS_VOTES",	"Most votes");
DEFINE("_RSITEMS_RATED",	"Top rated");
DEFINE("_RSITEMS_MCOMMENT",	"Most commented");
DEFINE("_RSITEMS_LCOMMENT",	"Last commented");

DEFINE("_RSITEMS_DATE",	"Date: ");
DEFINE("_RSITEMS_HITS",	"Hits: ");
DEFINE("_RSITEMS_VOTESCOUNT","Voted: "); 
DEFINE("_RSITEMS_AVERAGE","Average: "); 
DEFINE("_RSITEMS_RANK","Rank: ");

DEFINE("_RSITEMS_COMMENT"," comment");
DEFINE("_RSITEMS_COMMENTS"," comments");
DEFINE("_RSITEMS_LAST","Last: ");
DEFINE("_RSITEMS_BY", "By: ");
?>