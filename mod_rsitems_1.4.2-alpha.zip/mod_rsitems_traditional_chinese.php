<?php
//RSItems - show random pictures, latest, most popular and most votes //
//Traditional Chinese language file by Mike Ho @ www.dogneighbor.com

/**
* RSGallery2 Items - Random, Latest, Popular, Most Voted
* @ package Joomla! Open Source
* @ Based on the RSitems module from Errol Elumir
* @ Modified for use with RSgallery2 by Daniel Tulp
* @ Joomla! Open Source is Free Software
* @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @ version 1.4.2
**/

DEFINE("_RSITEMS_RANDOM",	"隨機選取");
DEFINE("_RSITEMS_LATEST",	"最新上載");
DEFINE("_RSITEMS_POPULAR",	"熱門瀏覽");
DEFINE("_RSITEMS_VOTES",	"最受歡迎");
DEFINE("_RSITEMS_RATED",	"最高評價");
DEFINE("_RSITEMS_MCOMMENT",	"最多評論");
DEFINE("_RSITEMS_LCOMMENT",	"最新評論");

DEFINE("_RSITEMS_DATE",	"日期: ");
DEFINE("_RSITEMS_HITS",	"點擊: ");
DEFINE("_RSITEMS_VOTESCOUNT","投票: "); 
DEFINE("_RSITEMS_AVERAGE","平均: "); 
DEFINE("_RSITEMS_RANK","評級: ");

DEFINE("_RSITEMS_COMMENT"," 項評論");
DEFINE("_RSITEMS_COMMENTS"," 項評論");
DEFINE("_RSITEMS_LAST","最新: ");
DEFINE("_RSITEMS_BY", "來自: ");
?>