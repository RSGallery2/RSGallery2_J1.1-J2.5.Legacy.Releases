<?php
/**
* RSGallery2 Items - Random, Latest, Popular, Most Voted
* @ package Joomla! Open Source
* @ Based on the RSitems module from Errol Elumir
* @ Modified for use with RSgallery2 by Daniel Tulp
* @ Joomla! Open Source is Free Software
* @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @ version 1.4.2
**/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

//initialise init file
global $mosConfig_absolute_path;
require_once($mosConfig_absolute_path.'/administrator/components/com_rsgallery2/init.rsgallery2.php');

$params = mosParseParams( $module->params );

// How many to display
$count = @$params->count ? intval( $params->count ) : 1;

// Horizontal or vertical (horizontal by default)
$display_case = @$params->display ? $params->display : 0;

// Determine whether or not the user wants to use ACL
$useACL = @$params->useACL;

//Do we want the text to be displayed
$display_text = @$params->display_text;

//Translation of text
//Check for language files, if not found, default to english
if (file_exists($mosConfig_absolute_path.'/modules/mod_rsitems_'.$mosConfig_lang.'.php')){
    include_once($mosConfig_absolute_path.'/modules/mod_rsitems_'.$mosConfig_lang.'.php');
} else {
    include_once($mosConfig_absolute_path.'/modules/mod_rsitems_english.php');
}

//what to display
//random
$display_random = @$params->display_random;
//latest
$display_latest = @$params->display_latest;
$displaydate = @$params->displaydate;
$dateformat = @$params->dateformat;
//popular
$display_popular = @$params->display_popular;
$displayhits = @$params->displayhits;
//votes
$display_votes = @$params->display_votes;
$displayvotescount = @$params->displayvotescount;
$displayaverage = @$params->displayaverage;
//rank
$display_rank = @$params->display_rank;
$displayranknr = @$params->displayranknr;
$displayvotes_e = @$params->displayvotes_e;
$displayaverage_e = @$params->displayaverage_e;
//most commented
$display_mcommented = @$params->display_mcommented;
//last commented
$display_lcommented = @$params->display_lcommented;
//comments
$display_comments = @$params->display_comments;

//css?
$usecss = @$params->usecss ? $params->usecss : 0;
$css = @$params->css;

//select only specific gallery
$usegalselect = @$params->usegalselect ? $params->usegalselect : 0;
$galselect = @$params->galselect;

//determine seperator value
$useseperator = @$params->useseperator ? $params->useseperator : 0;
if($useseperator){
	$seperatorRandom = @$params->seperatorRandom ? $params->seperatorRandom : 1;
	$seperatorLatest = @$params->seperatorLatest ? $params->seperatorLatest : 1;
	$seperatorPopular = @$params->seperatorPopular ? $params->seperatorPopular : 1;
	$seperatorVotes = @$params->seperatorVotes? $params->seperatorVotes : 1;
	$seperatorRank = @$params->seperatorRank ? $params->seperatorRank : 1;
	$seperatorMcommented = @$params->seperatorMcommented ? $params->seperatorMcommented : 1;
	$seperatorLcommented = @$params->seperatorLcommented ? $params->seperatorLcommented : 1;
}

//get Itemid from menutable
    $query = "SELECT id"
        . "\n FROM #__menu"
        . "\n WHERE published = 1"
        . "\n AND link = 'index.php?option=com_rsgallery2'"
        . "\n ORDER BY link"
        ;
    $database->setQuery( $query );
    $RSG2Itemidobj = $database->loadObjectList();
    if (count($RSG2Itemidobj) > 0)
        $RSG2Itemid = $RSG2Itemidobj[0]->id;


//determine which gallery id's to use
//use ACL
if($useACL){
	global $rsgAccess;
	//check if acl is activated
	if(rsgAccess::aclActivated()){
		//make list of allowed gallery_ids
		$gal_ids = $rsgAccess->actionPermitted('view');
		if($usegalselect){
			if(in_array($galselect, $gal_ids)){
				$list = "WHERE #__rsgallery2_files.gallery_id IN(".$galselect.")";
			}
			else{
				echo "One or more gallery id limits is not viewable for the current usertype";
				exit;
			}
		}
		else{
			$list = "WHERE #__rsgallery2_files.gallery_id IN(".implode(",", $gal_ids).")";
		}
	}
	else{
		echo"ACL not enabled in RSGallery2 config<br>Enable it, or also disable it for RSItems";
		exit;
	}
}
else{
	//determine gallery id's to use if only usegalsselect
	if($usegalselect){
		$list = "WHERE gallery_id IN(".$galselect.")";
	}
	else{
	$list = '';
	}
}
if($display_random){
	//make the queries to the database
	$querya="SELECT * FROM #__rsgallery2_files $list ORDER BY rand() LIMIT $count";
	$database->setQuery( $querya );
	$rowsa = $database->loadObjectList();
	$rowa=$rowsa[0];
	//error trapping:
	if(mysql_error()){
		echo "MySQL error ".mysql_errno().": ".mysql_error()."\n<br>When executing a:<br>\n$querya\n<br>";
	}
}
if($display_latest){
	$queryb="SELECT * FROM #__rsgallery2_files $list ORDER BY date DESC LIMIT $count";
	$database->setQuery( $queryb );
	$rowsb = $database->loadObjectList();
	$rowb=$rowsb[0];
	//error trapping:
	if(mysql_error()){
		echo "MySQL error ".mysql_errno().": ".mysql_error()."\n<br>When executing b:<br>\n$queryb\n<br>";
	}
}
if($display_popular){
	$queryc="SELECT * FROM #__rsgallery2_files $list ORDER BY hits DESC LIMIT $count";
	$database->setQuery( $queryc );
	$rowsc = $database->loadObjectList();
	$rowc=$rowsc[0];
	//error trapping:
	if(mysql_error()){
		echo "MySQL error ".mysql_errno().": ".mysql_error()."\n<br>When executing c:<br>\n$queryc\n<br>";
	}
}
if($display_votes){
	$queryd="SELECT * FROM #__rsgallery2_files $list ORDER BY votes DESC LIMIT $count";
	$database->setQuery( $queryd );
	$rowsd = $database->loadObjectList();
	$rowd=$rowsd[0];
	//error trapping
	if(mysql_error()){
		echo "MySQL error ".mysql_errno().": ".mysql_error()."\n<br>When executing d:<br>\n$queryd\n<br>";
	}
}
if($display_rank){
	$querye="SELECT * FROM #__rsgallery2_files $list ORDER BY rating/votes DESC LIMIT $count";
	$database->setQuery( $querye );
	$rowse = $database->loadObjectList();
	$rowe=$rowse[0];
	//error trapping
	if(mysql_error()){
		echo "MySQL error ".mysql_errno().": ".mysql_error()."\n<br>When executing e:<br>\n$querye\n<br>";
	}
}
if($display_mcommented){
	$queryf="SELECT * FROM #__rsgallery2_files $list ORDER BY comments DESC LIMIT $count";
	$database->setQuery( $queryf );
	$rowsf = $database->loadObjectList();
	$rowf=$rowsf[0];
	//error trapping
	if(mysql_error()){
		echo "MySQL error ".mysql_errno().": ".mysql_error()."\n<br>When executing f:<br>\n$queryf\n<br>";
	}
}
if($display_lcommented){
	$queryg="SELECT #__rsgallery2_comments.picid, #__rsgallery2_comments.name AS author, #__rsgallery2_comments.date, #__rsgallery2_comments.comment, #__rsgallery2_files.name AS filename, #__rsgallery2_files.title, #__rsgallery2_files.id, #__rsgallery2_files.ordering, #__rsgallery2_files.gallery_id, #__rsgallery2_files.comments FROM #__rsgallery2_comments JOIN #__rsgallery2_files ON #__rsgallery2_comments.picid = #__rsgallery2_files.id $list ORDER BY #__rsgallery2_comments.date DESC LIMIT $count";
	$database->setQuery( $queryg );
	$rowsg = $database->loadObjectList();
	$rowg=$rowsg[0];
	//error trapping
	if(mysql_error()){
		echo "MySQL error ".mysql_errno().": ".mysql_error()."\n<br>When executing g:<br>\n$queryg\n<br>";
	}
}
//display not implemented yet
if($display_comments){
	$queryh="SELECT * FROM #__rsgallery2_comments LIMIT $count";
	$database->setQuery( $queryh );
	$rowsh = $database->loadObjectList();
	$rowh=$rowsh[0];
	//error trapping
	if(mysql_error()){
		echo "MySQL error ".mysql_errno().": ".mysql_error()."\n<br>When executing h:<br>\n$queryh\n<br>";
	}
}

//<style> can not be valid outside head, so javascript is needed, thanks Danilo Reinhardt
if($usecss){
?>
<script type = "text/javascript">
<!-- 
  var style = document.createElement('style');
  var css = document.createTextNode("<?php echo $css;?>");
  style.appendChild(css);
  style.setAttribute('type', 'text/css');
  var head = document.getElementsByTagName('head').item(0);
  head.appendChild(style);
//-->
</script>
<?php
}
//let's start to display horizontal
if($display_case == 0) {
       ?>
<table class="rsitems_table">
	<?php if($display_text){?>
	<tr>
		<?php if($display_random){?>
		<td><b><?php echo _RSITEMS_RANDOM;?></b></td>
		<?php }?>
		<?php if($display_latest){?>
		<td><b><?php echo _RSITEMS_LATEST;?></b></td>
		<?php }?>
		<?php if($display_popular){?>
		<td><b><?php echo _RSITEMS_POPULAR;?></b></td>
		<?php }?>
		<?php if($display_votes){?>
		<td><b><?php echo _RSITEMS_VOTES;?></b></td>
		<?php }?>
		<?php if($display_rank){?>
		<td><b><?php echo _RSITEMS_RATED;?></b></td>
		<?php }?>
		<?php if($display_mcommented){?>
		<td><b><?php echo _RSITEMS_MCOMMENT;?></b></td>
		<?php }?>
		<?php if($display_lcommented){?>
		<td><b><?php echo _RSITEMS_LCOMMENT;?></b></td>
		<?php }?>
	</tr>
	<?php }?>
	<tr>
		<?php if($display_random){?>
		<td>
			<?php
			foreach($rowsa as $rowa)
				{
				$filename_a       = $rowa->name;
				$title_a          = $rowa->title;
				$description_a    = $rowa->descr;
				$id_a             = $rowa->id;
				$limitstart_a     = $rowa->ordering - 1;
				$catid_a          = $rowa->gallery_id;
				?>
				<a href="<?php echo sefRelToAbs('index.php?option=com_rsgallery2&amp;page=inline&id='.$id_a.'&amp;catid='.$catid_a.'&limitstart='.$limitstart_a.'&amp;Itemid='.$RSG2Itemid);?>">
				<img src="<?php echo imgUtils::getImgThumb($filename_a); ?>" alt="<?php echo $title_a; ?>" border="0" />
				</a>
				<?php if($useseperator){?>
					<div class="rsitems_seperator">
						<?php for($i=0; $seperatorRandom > $i; $i++){
						echo "<br />";
						}
						?>
					</div>
				<?php 
					}
				}
				?>
		</td>
		<?php }?>
		<?php if($display_latest){?>
		<td>
			<?php 
			foreach($rowsb as $rowb)
				{
				$filename_b       = $rowb->name;
				$title_b          = $rowb->title;
				$description_b    = $rowb->descr;
				$id_b             = $rowb->id;
				$limitstart_b     = $rowb->ordering - 1;
				$catid_b          = $rowb->gallery_id;
				$date			  = $rowb->date;
				?>
				<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery2&amp;page=inline&amp;id=".$id_b."&amp;catid=".$catid_b."&amp;limitstart=".$limitstart_b."&amp;Itemid=".$RSG2Itemid);?>">
				<img src="<?php echo imgUtils::getImgThumb($filename_b); ?>" alt="<?php echo $title_b; ?>" border="0" /><?php if ($displaydate){?></a>				
				<div class="rsitems_date"><?php echo _RSITEMS_DATE.date($dateformat,strtotime($date));  ?></div><?php }?>
				<?php if($useseperator){?>
					<div class="rsitems_seperator">
						<?php for($i=0; $seperatorLatest > $i; $i++){
						echo "<br />";
						}
						?>
					</div>				
				<?php 
					}
				}
				?>
		</td>
		<?php }?>
		<?php if($display_popular){?>
		<td>
			<?php
			foreach($rowsc as $rowc)
				{
				$filename_c       = $rowc->name;
				$title_c          = $rowc->title;
				$description_c    = $rowc->descr;
				$id_c             = $rowc->id;
				$limitstart_c     = $rowc->ordering - 1;
				$catid_c          = $rowc->gallery_id;
				$hits			  =	$rowc->hits;
				?>
				<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery2&amp;page=inline&amp;id=".$id_c."&amp;catid=".$catid_c."&amp;limitstart=".$limitstart_c."&amp;Itemid=".$RSG2Itemid);?>">
				<img src="<?php echo imgUtils::getImgThumb($filename_c); ?>" alt="<?php echo $title_c; ?>" border="0" /></a>
				<?php if ($displayhits){?><div class="rsitems_hits"><?php echo _RSITEMS_HITS.$hits ?></div><?php }?>
				<?php if($useseperator){?>
					<div class="rsitems_seperator">
						<?php for($i=0; $seperatorPopular > $i; $i++){
						echo "<br />";
						}
						?>
					</div>
				<?php 
					}
				}
				?>
		</td>
		<?php }?>
		<?php if($display_votes){?>
		<td>
			<?php
			foreach($rowsd as $rowd)
				{
				$filename_d       = $rowd->name;
				$title_d          = $rowd->title;
				$description_d    = $rowd->descr;
				$id_d             = $rowd->id;
				$limitstart_d     = $rowd->ordering - 1;
				$catid_d          = $rowd->gallery_id;
				$votes			  = $rowd->votes;
				$rating			  = $rowd->rating;
				if($votes!=0){
					$average		  = $rating/$votes;
				}
				?>
				<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery2&amp;page=inline&amp;id=".$id_d."&amp;catid=".$catid_d."&amp;limitstart=".$limitstart_d."&amp;Itemid=".$RSG2Itemid);?>">
				<img src="<?php echo imgUtils::getImgThumb($filename_d); ?>" alt="<?php echo $title_d; ?>" border="0" /></a>
				<?php 
				if ($displayvotescount){
					echo "<div class='rsitems_votescount'>"._RSITEMS_VOTESCOUNT."$votes </div>";
					}
				if($votes!=0){
					if($displayaverage == '1'){
						echo "<div class='rsitems_votesaverage'>"._RSITEMS_AVERAGE."$average </div>";
						}
					elseif($displayaverage == '2'){
					?>
						<div class="rsitems_votesaverage">
						<?php 
						for($r=1; $r<=$average; $r++){
							echo "<img border='0' src='$mosConfig_live_site/images/M_images/rating_star.png' alt='rating' />";
							}
						}
						echo"</div>";
					}	
				if($useseperator){?>
					<div class="rsitems_seperator">
						<?php for($i=0; $seperatorVotes > $i; $i++){
						echo "<br />";
						}
						?>
					</div>
				<?php 
					}
				}
				?>
		</td>
		<?php }?>
		<?php if($display_rank){
		$rank			  = '1';
		?>
		<td>
			<?php
			foreach($rowse as $rowe)
				{
				$filename_e       = $rowe->name;
				$title_e          = $rowe->title;
				$description_e    = $rowe->descr;
				$id_e             = $rowe->id;
				$limitstart_e     = $rowe->ordering - 1;
				$catid_e          = $rowe->gallery_id;
				$votes_e		  = $rowe->votes;
				$rating_e		  = $rowe->rating;
				if($votes_e!=0){
					$average_e	  = $rating_e/$votes_e;
				}
				?>
				<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery2&amp;page=inline&amp;id=".$id_e."&amp;catid=".$catid_e."&amp;limitstart=".$limitstart_e."&amp;Itemid=".$RSG2Itemid);?>">
				<img src="<?php echo imgUtils::getImgThumb($filename_e); ?>" alt="<?php echo $title_e; ?>" border="0" /></a>
				<?php 
				if ($displayranknr){
					echo "<div class='rsitems_ranknr'>"._RSITEMS_RANK."$rank </div>";
					$rank++;
					}
				if ($displayvotes_e){
					echo "<div class='rsitems_votescount'>"._RSITEMS_VOTESCOUNT."$votes_e </div>";
					}
				if($votes_e!=0){
					if($displayaverage_e == '1'){
						echo "<div class='rsitems_rankaverage'>"._RSITEMS_AVERAGE."$average_e ?></div>";
						}
					elseif($displayaverage_e == '2'){
						echo"<div class='rsitems_rankaverage'>";
						for($r=1; $r<=$average_e; $r++){
							echo "<img border='0' src='$mosConfig_live_site/images/M_images/rating_star.png' alt='rating' /> ";
							}
						}
						echo"</div>";
					}
				if($useseperator){?>
					<div class="rsitems_seperator">
						<?php for($i=0; $seperatorRank > $i; $i++){
						echo "<br />";
						}
						?>
					</div>
				<?php 
					}
				}
				?>
		</td>
		<?php }?>
		<?php if($display_mcommented){?>
		<td>
			<?php
			foreach($rowsf as $rowf)
				{
				$filename_f       = $rowf->name;
				$title_f          = $rowf->title;
				$description_f    = $rowf->descr;
				$id_f             = $rowf->id;
				$limitstart_f     = $rowf->ordering - 1;
				$catid_f          = $rowf->gallery_id;
				$comments		  =	$rowf->comments;
				?>
				<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery2&amp;page=inline&amp;id=".$id_f."&amp;catid=".$catid_f."&amp;limitstart=".$limitstart_f."&amp;Itemid=".$RSG2Itemid);?>">
				<img src="<?php echo imgUtils::getImgThumb($filename_f); ?>" alt="<?php echo $title_f; ?>" border="0" /></a><div class="rsitems_commentnr"><?php if($comments <= 1){echo $comments._RSITEMS_COMMENT;}else{echo $comments._RSITEMS_COMMENTS;}echo "</div>";
			if($useseperator){?>
					<div class="rsitems_seperator">
						<?php for($i=0; $seperatorMcommented > $i; $i++){
						echo "<br />";
						}
						?>
					</div>
			<?php 
				}
			}?>
		</td>
		<?php }?>
		<?php if($display_lcommented){?>
		<td>
			<?php
			foreach($rowsg as $rowg)
				{
				$picid_g 		= $rowg->picid;
				$author 		= $rowg->author;
				$date_g 		= $rowg->date;
				$comment		= $rowg->comment;
				$filename_g       = $rowg->filename;
				$title_g          = $rowg->title;
				$id_g             = $rowg->id;
				$limitstart_g     = $rowg->ordering - 1;
				$catid_g          = $rowg->gallery_id;
				$comments_g		  =	$rowg->comments;
				?>
				<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery2&amp;page=inline&amp;id=".$id_g."&amp;catid=".$catid_g."&amp;limitstart=".$limitstart_g."&amp;Itemid=".$RSG2Itemid);?>">
				<img src="<?php echo imgUtils::getImgThumb($filename_g); ?>" alt="<?php echo $title_g; ?>" border="0" /></a><div class="rsitems_commentnr"><?php if($comments_g <= 1){echo $comments_g._RSITEMS_COMMENT;}else{echo $comments_g._RSITEMS_COMMENTS;}echo "</div>";
				echo "<div class='rsitems_comment'>"._RSITEMS_LAST.$comment."<br />"._RSITEMS_BY.$author."</div>";
			if($useseperator){?>
					<div class="rsitems_seperator">
						<?php for($i=0; $seperatorLcommented > $i; $i++){
						echo "<br />";
						}
						?>
					</div>
			<?php 
				}
			}?>
		</td>
		<?php }?>
	</tr>
</table>
<?php }
else {
//else display vertical
	?>
	<table class="rsitems_table">
	<?php if($display_random){?>
		<?php if($display_text){?>
		<tr>
			<td colspan="<?php echo $count ?>"><b><?php echo _RSITEMS_RANDOM;?></b></td>
		</tr>
		<?php }?>
		<tr>
			<?php
   		foreach($rowsa as $rowa)
		{
		$filename_a       = $rowa->name;
		$title_a          = $rowa->title;
		$description_a    = $rowa->descr;
		$id_a             = $rowa->id;
		$limitstart_a     = $rowa->ordering - 1;
		$catid_a          = $rowa->gallery_id;
		?><td>
		<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery2&amp;page=inline&amp;id=".$id_a."&amp;catid=".$catid_a."&amp;limitstart=".$limitstart_a."&amp;Itemid=".$RSG2Itemid);?>">
		<img src="<?php echo imgUtils::getImgThumb($filename_a); ?>" alt="<?php echo $title_a; ?>" border="0" />
		</a></td>
		<?php }?>
		</tr>
	<?php }?>
	<?php if($display_latest){?>
		<?php if($display_text){?>
		<tr>
			<td colspan="<?php echo $count ?>"><b><?php echo _RSITEMS_LATEST;?></b></td>
		</tr>
		<?php }?>
		<tr>
			<?php
		foreach($rowsb as $rowb)
		{
		$filename_b       = $rowb->name;
		$title_b          = $rowb->title;
		$description_b    = $rowb->descr;
		$id_b             = $rowb->id;
		$limitstart_b     = $rowb->ordering - 1;
		$catid_b          = $rowb->gallery_id;
		$date			  = $rowb->date;
		?><td>
		<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery2&amp;page=inline&amp;id=".$id_b."&amp;catid=".$catid_b."&amp;limitstart=".$limitstart_b."&amp;Itemid=".$RSG2Itemid);?>">
		<img src="<?php echo imgUtils::getImgThumb($filename_b); ?>" alt="<?php echo $title_b; ?>" border="0" /></a>
		<?php if ($displaydate){?><div class="rsitems_date"><?php echo _RSITEMS_DATE.date($dateformat,strtotime($date));  ?></div><?php }?>
		</td>
		<?php }?>			
		</tr>
	<?php }?>
	<?php if($display_popular){?>
		<?php if($display_text){?>
		<tr>
			<td colspan="<?php echo $count ?>"><b><?php echo _RSITEMS_POPULAR;?></b></td>
		</tr>
		<?php }?>
		<tr>
			<?php
		foreach($rowsc as $rowc)
		{
		$filename_c       = $rowc->name;
		$title_c          = $rowc->title;
		$description_c    = $rowc->descr;
		$id_c             = $rowc->id;
		$limitstart_c     = $rowc->ordering - 1;
		$catid_c          = $rowc->gallery_id;
		$hits			  =	$rowc->hits;
		?>
		<td>
	<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery2&amp;page=inline&id=".$id_c."&amp;catid=".$catid_c."&amp;limitstart=".$limitstart_c."&amp;Itemid=".$RSG2Itemid);?>">
		<img src="<?php echo imgUtils::getImgThumb($filename_c); ?>" alt="<?php echo $title_c; ?>" border="0" /></a>
		<?php if ($displayhits){?><div class="rsitems_hits"><?php echo _RSITEMS_HITS.$hits ?></div><?php }?>
		</td>
		<?php }?>			
		</tr>
	<?php }?>
	<?php if($display_votes){?>
		<?php if($display_text){?>
		<tr>
			<td colspan="<?php echo $count ?>"><b><?php echo _RSITEMS_VOTES;?></b></td>
		</tr>
		<?php }?>
		<tr>
			<?php
		foreach($rowsd as $rowd)
		{
		$filename_d       = $rowd->name;
		$title_d          = $rowd->title;
		$description_d    = $rowd->descr;
		$id_d             = $rowd->id;
		$limitstart_d     = $rowd->ordering - 1;
		$catid_d          = $rowd->gallery_id;
		$votes			  = $rowd->votes;
		$rating			  = $rowd->rating;
		if($votes!=0){
			$average		  = $rating/$votes;
		}
		?>
		<td>
		<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery2&amp;page=inline&amp;id=".$id_d."&amp;catid=".$catid_d."&amp;limitstart=".$limitstart_d."&amp;Itemid=".$RSG2Itemid);?>">
		<img src="<?php echo imgUtils::getImgThumb($filename_d); ?>" alt="<?php echo $title_d; ?>" border="0" /></a>
		<?php 
		if ($displayvotescount){
			echo "<div class='rsitems_votescount'>"._RSITEMS_VOTESCOUNT."$votes </div>";
			}
		if($votes!=0){
			if($displayaverage == '1'){
				echo "<div class='rsitems_votesaverage'>"._RSITEMS_AVERAGE."$average ?></div>";
				}
			elseif($displayaverage == '2'){?>
				<div class="rsitems_votesaverage">
				<?php 
				for($r=1; $r<=$average; $r++){
					echo "<img border='0' src='$mosConfig_live_site/images/M_images/rating_star.png' alt='rating' /> ";
					}
				}
				echo"</div>";
			}
			?>
		</td>
		<?php }?>			
		</tr>
	<?php }?>
	<?php if($display_rank){
		$rank = '1';
		if($display_text){?>
			<tr>
				<td colspan="<?php echo $count ?>"><b><?php echo _RSITEMS_RATED;?></b></td>
			</tr>
		<?php }?>
			<tr>
			<?php
			foreach($rowse as $rowe)
				{
				$filename_e       = $rowe->name;
				$title_e          = $rowe->title;
				$description_e    = $rowe->descr;
				$id_e             = $rowe->id;
				$limitstart_e     = $rowe->ordering - 1;
				$catid_e          = $rowe->gallery_id;
				$votes_e		  = $rowe->votes;
				$rating_e		  = $rowe->rating;
				if($votes_e!=0){
					$average_e	  = $rating_e/$votes_e;
				}
				?>
				<td>
				<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery2&amp;page=inline&amp;id=".$id_e."&amp;catid=".$catid_e."&amp;limitstart=".$limitstart_e."&amp;Itemid=".$RSG2Itemid);?>">
				<img src="<?php echo imgUtils::getImgThumb($filename_e); ?>" alt="<?php echo $title_e; ?>" border="0" /></a>
				<?php 
				if ($displayranknr){
					echo "<div class='rsitems_ranknr'>"._RSITEMS_RANK."$rank </div>";
					$rank++;
					}
				if ($displayvotes_e){
					echo "<div class='rsitems_votescount'>"._RSITEMS_VOTESCOUNT."$votes_e </div>";
					}
				if($votes_e!=0){
					if($displayaverage_e == '1'){
						echo "<div class='rsitems_rankaverage'>"._RSITEMS_AVERAGDE."$average_e ?></div>";
						}
					elseif($displayaverage_e == '2'){
						echo"<div class='rsitems_rankaverage'>";
						for($r=1; $r<=$average_e; $r++){
							echo "<img border='0' src='$mosConfig_live_site/images/M_images/rating_star.png' alt='rating' /> ";
							}
						}
						echo"</div>";
					}
					?>
			<?php }?>
				</td>
			</tr>
	<?php }?>
	<?php if($display_mcommented){?>
		<tr>
				<td colspan="<?php echo $count ?>"><b><?php echo _RSITEMS_MCOMMENT;?></b></td>
		</tr>
		<tr>
		<?php
			foreach($rowsf as $rowf)
				{
				$filename_f       = $rowf->name;
				$title_f          = $rowf->title;
				$description_f    = $rowf->descr;
				$id_f             = $rowf->id;
				$limitstart_f     = $rowf->ordering - 1;
				$catid_f          = $rowf->gallery_id;
				$comments		  =	$rowf->comments;
				?>
				<td>
				<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery2&amp;page=inline&amp;id=".$id_f."&amp;catid=".$catid_f."&amp;limitstart=".$limitstart_f."&amp;Itemid=".$RSG2Itemid);?>">
				<img src="<?php echo imgUtils::getImgThumb($filename_f); ?>" alt="<?php echo $title_f; ?>" border="0" /></a><div class="rsitems_commentnr"><?php if($comments <= 1){echo $comments._RSITEMS_COMMENT;}else{echo $comments._RSITEMS_COMMENTS;}echo "</div>";
			}?>
			</td>
		</tr>
		<?php }?>
		<tr>
		<?php if($display_lcommented){?>
		<tr>
				<td colspan="<?php echo $count ?>"><b><?php echo _RSITEMS_LCOMMENT;?></b></td>
		</tr>
		<tr>
			<?php
			foreach($rowsg as $rowg)
				{
				$picid_g 		= $rowg->picid;
				$author 		= $rowg->author;
				$date_g 		= $rowg->date;
				$comment		= $rowg->comment;
				$filename_g       = $rowg->filename;
				$title_g          = $rowg->title;
				$id_g             = $rowg->id;
				$limitstart_g     = $rowg->ordering - 1;
				$catid_g          = $rowg->gallery_id;
				$comments_g		  =	$rowg->comments;
				?>
			<td>
				<a href="<?php echo sefRelToAbs("index.php?option=com_rsgallery2&amp;page=inline&amp;id=".$id_g."&amp;catid=".$catid_g."&amp;limitstart=".$limitstart_g."&amp;Itemid=".$RSG2Itemid);?>">
				<img src="<?php echo imgUtils::getImgThumb($filename_g); ?>" alt="<?php echo $title_g; ?>" border="0" /></a><div class="rsitems_commentnr"><?php if($comments_g <= 1){echo $comments_g._RSITEMS_COMMENT;}else{echo $comments_g._RSITEMS_COMMENTS;}echo "</div>";
				echo "<div class='rsitems_comment'>"._RSITEMS_LAST.$comment."<br />"._RSITEMS_BY.$author."</div>";
			}?>
			</td>
		</tr>
		<?php }?>
	</table>
<?php }?>