<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); ?>

<table class="rsg2_random_table" align="center">
    <tr>
        <td align="center">
            <b>Most Popular Picture<?php if( ((int)$params->get('count')) > 1)echo 's'; ?></b>
        </td>
    </tr>
    <?php
    foreach($images as $item)
    {
        echo modRSG2PopularHelper::getImageCell( $item );
        
        if( $params->get('display_title') )
        {
            echo modRSG2PopularHelper::getImageTitle( $item );
        }
        
        if( $params->get('display_hits') )
        {
            echo modRSG2PopularHelper::getImageHits( $item );
        }
    }
   ?>
</table>