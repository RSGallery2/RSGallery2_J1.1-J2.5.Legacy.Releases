<?php
/**
 * Helper class for RSGallery2 most popular picture module
 * 
 * @ package Joomla! Open Source
 * @subpackage Modules
 * @ Joomla! Open Source is Free Software
 * @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @ version 0.0.1
 */
 
class modRSG2PopularHelper
{
    function getPopularImage( $params )
    {  
        $count  = $params->get('count') ? (int)$params->get('count') : 1;
		$db		=& JFactory::getDBO();
		$result	= null;

		$query  = "SELECT * FROM #__rsgallery2_files ORDER BY hits DESC LIMIT $count";
        
		$db->setQuery($query);
        
		$result = $db->loadObjectList();

		if ($db->getErrorNum())
        {
			JError::raiseWarning( 500, $db->stderr() );
		}

		return $result;
    }
    
    function getImageCell ( $item )
    {
		$filename       = $item->name;
		$title          = $item->title;
		$id             = $item->id;
        
        return '<tr><td align="center"><a href="index.php?option=com_rsgallery2&page=inline&id='.$id.'">'.
                '<img src="images/rsgallery/thumb/'.$filename.'.jpg" alt="'.$title.'" border="0" /></a></td></tr>';  
    }
    
    function getImageTitle ( $item )
    {
		$title          = $item->title;
        $id             = $item->id;
        return '<tr><td align="center"><a href="index.php?option=com_rsgallery2&page=inline&id='.$id.'">'.$title.'</a></td></tr>';  
    }
    
    function getImageHits ( $item )
    {
		$hits			= $item->hits;
        $id             = $item->id;
        return '<tr><td align="center"><a href="index.php?option=com_rsgallery2&page=inline&id='.$id.'">Hits: '.$hits.'</a></td></tr>';  
    }
}