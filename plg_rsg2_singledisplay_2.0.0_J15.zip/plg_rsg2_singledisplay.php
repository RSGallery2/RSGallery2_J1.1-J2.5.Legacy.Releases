
<?php
/**
* @version $Id:$
* @package RSGallery2
* @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* Joomla! is free software and parts of it may contain or be derived from the
* GNU General Public License or other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
 
/** ensure this file is being included by a parent file */
defined( '_JEXEC' ) or die();

$mainframe->registerEvent( 'onPrepareContent', 'bot_rsg2_singledisplay' );

/**
* RSGallery Single Image Display Bot
*
* <b>Usage:</b>
* <code>{rsg2_singledisplay: imageid, size, caption, align}</code>
*/
function bot_rsg2_singledisplay( &$row, &$params, $page=0 ) {
  $plugin =& JPluginHelper::getPlugin('content', 'bot_rsg2_singledisplay');
 
  // define the regular expression for the bot
  $regex = "#{rsg2_singledisplay\:*(.*?)}#s";
 
  // perform the replacement
  $row->text = preg_replace_callback( $regex, 'bot_rsg2_singledisplay_replacer', $row->text );
}

/**
 * Code to replace {rsg2_singledisplay: imageid, size, caption}
 *
 * @param object $matches
 * @return output
 */
function bot_rsg2_singledisplay_replacer( &$matches ) {
	if( $matches ) {
		global $mosConfig_absolute_path;
		global $mosConfig_lang;
		
		// initialize RSGallery 2 
		require_once( JPATH_BASE.'/administrator/components/com_rsgallery2/init.rsgallery2.php' );
		
		// get attributes from matches and create array
		$attribs = split( ',',$matches[1] );
		if ( is_array( $attribs ) ) {
			$clean_attribs = array ();
			foreach ( $attribs as $attrib ) {
				$clean_attrib = bot_rsg2_singledisplay_clean_data ( $attrib );
				array_push( $clean_attribs, $clean_attrib );
			}
		} else {
			return false;
		}
		
		
		if ( (int)$clean_attribs[0] ) {// check if imageID is numeric
			$image_attribute = $clean_attribs[0];// imageID
			if ( isset( $clean_attribs[1] ) ) {// check if Size is set
				$image_size = $clean_attribs[1];
			} else {
				$image_size = NULL;
			}
			if ( isset( $clean_attribs[2] ) ) {// check if caption is set
				$image_caption = bot_rsg2_singledisplay_bool($clean_attribs[2]);//make sure you get bool 
			} else {
				$image_caption = NULL;
			}
			if (isset( $clean_attribs[3] ) ) {// check if align is set
				$image_align = $clean_attribs[3];
			} else {
				$image_align = NULL;
			}

		} else {
			return false;// if nothing is set then the User did not use bot correctly SHOW NOTHING!
		}
		
		// obtain gallery object by the Images ID
		$gallery_object = rsgGalleryManager::getGalleryByItemID( $image_attribute );
		
		if ( is_object( $gallery_object ) ) {// check if gallery object was returned from ImageID
			$image_object = $gallery_object->getItem( $image_attribute );// get image array from gallery object	
		} else {
			return false; // if image object is not returned from gallery object then user specified wrong imageID SHOW NOTHING!
		}
		
		if ( is_object( ( $image_object ) ) ) {// Check if image array was returned
			$output = bot_rsg2_singledisplay_display( $image_object, $image_size, $image_caption, $image_align);
			ob_start();// start output buffer
				echo $output;// output content
				$display_output = ob_get_contents(); // apply buffer to var
			ob_end_clean();// close buffer and clean up
			return $display_output; // return output content buffer
		} else {
			return true;// Something messed up some how not sure but SHOW NOTHING!
		}
	}
}

/**
 * Code that generates Image output
 *
 * @param object $image_object
 * @param string $image_size
 * @param bool $image_caption
 * @param string $image_align 
 * @return string
 * Example: {rsg2_singledisplay:9999,thumb,true,left;float:left} 
 */
function bot_rsg2_singledisplay_display ( $image_object, $image_size ,$image_caption, $image_align) {
	global $mosConfig_live_site;
	if ($image_align != '') {
		$output = '<div class="rsgSingleDisplay id_' . $image_object->id . '" style="text-align: '.$image_align.';">';
	} else {
		$output = '<div class="rsgSingleDisplay id_' . $image_object->id . '">';
	}
	$params_obj = $image_object->parameters();//get params object
	
	if( is_a( $image_object, 'rsgItem_audio' ) ) {
		$audio = $image_object->original();
		if ( strtolower( $image_size ) == "thumb" ) {
			$output .= '<object type="application/x-shockwave-flash" width="17" height="17" data="' . $mosConfig_live_site . '/components/com_rsgallery2/flash/xspf/musicplayer.swf?song_title=' . $image_object->name . '&song_url=' . $audio->url() .'"><param name="movie" value="' . $mosConfig_live_site . '/components/com_rsgallery2/flash/xspf/musicplayer.swf?song_title=' . $image_object->name
				.'&song_url=' . $audio->url() . '" /></object>';
		} else {
			$output .= '<object type="application/x-shockwave-flash" width="400" height="15" data="' . $mosConfig_live_site . '/components/com_rsgallery2/flash/xspf/xspf_player_slim.swf?song_title=' . $image_object->name . '&song_url=' . $audio->url() .'"><param name="movie" value="' . $mosConfig_live_site . '/components/com_rsgallery2/flash/xspf/xspf_player_slim.swf?song_title=' . $image_object->name
				.'&song_url=' . $audio->url() . '" /></object>';			
		}
	} else {
	  
	  $thumb = $image_object->thumb();
	  $display = $image_object->display();
	  $original = $image_object->original();
	  // Highslide stuff 
	  $image_output .= '<a href="' . $original->url() . '" class="highslide" onclick="return hs.expand(this, { fadeInOut:true,dimmingOpacity:0.75 })"> ';
		switch ( strtolower( $image_size ) ) {
			case "thumb":// thumbnail display

				$image_output .= '<img src="' . $thumb->url() . '" alt="' . $image_object->descr . '" border="0" /> </a>';
				break;
			
			case "display":// display set by RSGallery

				$image_output .= '<img src="' . $display->url() . '" alt="' . $image_object->descr . '" border="0" /> </a>';
				break;
							
			case "original":// original image 

				$image_output.= '<img src="' . $original->url() . '" alt="' . $image_object->descr . '" border="0" /> </a>';
				break;
				
			default:// display set by RSGallery

				$image_output .= '<img src="' . $display->url() . '" alt="' . $image_object->descr . '" border="0" /></a>';
				break;
		}
	}
	
	if ( $params_obj->get( 'link_text','' ) ) {
		$parse_url = parse_url( $params_obj->get( 'link', '' ) );
		( $parse_url['scheme'] == "http" ) ? $link = $params_obj->get( 'link', '' ) : $link = 'http://' . $params_obj->get( 'link', '' );
		$output .= '<a href="' . $link . '">';
		$output .= $image_output . '<br />';
		if( $params_obj->get( 'link_text','' ) ){ $output .= $params_obj->get( 'link_text','' ); }
		$output .= '</a>';
	} else {
		$output .= $image_output;
	}
	
	// if image caption then output the description of the image 
	$image_caption ? $output .= '<div class=highslide-caption>' . $image_object->descr . '</div>' : $output .= "";		
	
	$output .= '</div>';
	
	// return image ouput
	return $output;
}

/*
<div>

<a href="../images/full-image.jpg" class="highslide" onclick="return hs.expand(this)">
	<img src="../images/thumbnail.jpg" alt="Highslide JS"
		title="Click to enlarge" height="120" width="107" />
    
</a>
 
 
</div>


*/

/**
 * Converts string to bool
 *
 * @param string $var
 * @return bool
 */
function bot_rsg2_singledisplay_bool( $var ) {
	if ( $var === 1 ) {
		return true;
	} elseif ( $var === 0 ) {
		return false;
	}
	
    switch (strtolower($var)) {
        case ("true"):
            return true;
            break;
        case ("false"):
            return false;
            break;
        default:
            return false;
    }
}

function bot_rsg2_singledisplay_clean_data ( $attrib ) {//remove &nbsp; and trim white space
	$attrib = str_replace( "&nbsp;", '', "$attrib" );

	return trim( $attrib );
}
?>  
 
 
 
