<?php
/**
* RSGallery2 Slideshow
* @ package Joomla! Open Source
* @ Based on mod_RSGallery2_slideshow.php from Tash Bolta http://www.mamboat.com 
* @ mod_RSGallery2_slideshow.php was based on a slideshow module by Daniel Tulp
* @ Modified for use with RSgallery2 1.12.x and above by Daniel Tulp
* @ Joomla! Open Source is Free Software
* @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @ version 1.2.2
**/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

$imagepath 	= $params->get( 'imagepath', '/images/rsgallery/thumb');
$Clickornot = $params->get( 'Clickornot', '1' );
$Width		= $params->get( 'Width', '100' );
$Height		= $params->get( 'Height', '100' );
$BackColor	= $params->get( 'BackColor', '#ffffff' );
$PicsNum	= $params->get( 'PicsNum', '1' );
$FadeDelay	= $params->get( 'FadeDelay', '6000' );
$Pause		= $params->get( 'Pause', '1' );
$Hits		= $params->get( 'Hits', '0' );
$Votes		= $params->get( 'Votes', '0' );
$Rating		= $params->get( 'Rating', '0' );
$Comments	= $params->get( 'Comments', '0' );
$PickMethod	= $params->get( 'PickMethod', 'Rand()' );
$ShowMethod	= $params->get( 'ShowMethod', '0' );
$usecss		= $params->get( 'usecss', '1' );
$css		= $params->get( 'css');

//get itemid properly
    $query = "SELECT id"
        . "\n FROM #__menu"
        . "\n WHERE published = 1"
        . "\n AND link = 'index.php?option=com_rsgallery2'"
        . "\n ORDER BY link"
        ;
    $database->setQuery( $query );
    $RSG2Itemidobj = $database->loadObjectList();
    if (count($RSG2Itemidobj) > 0)
        $RSG2Itemid = $RSG2Itemidobj[0]->id;
		
//load database object
$database->setQuery("SELECT * FROM #__rsgallery2_files ORDER BY $PickMethod DESC LIMIT $PicsNum" );
$rows = $database->LoadObjectList();

$k = 0;
$text = "";
foreach ($rows as $row)
	{
    if ($k == 0)
        {
        $name = $row->name;
        }
    $name = getImgNameDisplay($row->name);
    $id = $row->id;
	$limitstart = $row->ordering - 1;
	$url = sefRelToAbs('index.php?option=com_rsgallery2&Itemid='.$RSG2Itemid.'&page=inline&id='.$row->id.'&catid='.$row->gallery_id.'&limitstart='.$limitstart);
	if ($Clickornot==1)
	{$text .= "fadeimages[".$k."] = [\"$mosConfig_live_site$imagepath/$name\",\"$url\",\"_parent\",\"$row->name\", \"$row->title\",\"$row->hits\",\"$row->votes\",\"$row->rating\",\"$row->comments\",\"$PickMethod\"];\n";}
    	else
	$text .= "fadeimages[".$k."] = [\"$mosConfig_live_site$imagepath/$name\",\"\",\"_parent\",\"$row->name\", \"$row->title\",\"$row->hits\",\"$row->votes\",\"$row->rating\",\"$row->comments\",\"$PickMethod\"];\n";

	$k++;
	}
//css?
if($usecss){echo"<style type='text/css'>$css</style>";}
echo "<div class=\"rsg2_slideshow\">";
if ($PickMethod=="Rand()"){$PickMethod="Random";}
echo "<script language=\"javascript\" type=\"text/javascript\">\n";
echo '/* <![CDATA[ */';
?> 
var fadeimages = new Array();
//Echo JS-array from DB-query here

<?php echo $text;?>

	
<?php 
echo "w=$Width\n";
echo "h=$Height\n";
echo "b=0\n";
echo "d=$FadeDelay\n";
echo "p=$Pause\n";
echo "f=\"$BackColor\"\n";
echo "hits=$Hits\n";
echo "votes=$Votes\n";
echo "rating=$Rating\n";
echo "comments=$Comments\n";
echo "showm=$ShowMethod\n";
echo "show=\"$PickMethod\"\n";
?>
	
	
//SET IMAGE PATHS. Extend or contract array as needed
 
////NO need to edit beyond here/////////////
var ie=document.all
var dom=document.getElementById
var fadearray=new Array() //array to cache fadeshow instances
var fadeclear=new Array() //array to cache corresponding clearinterval pointers
 
var dom=(document.getElementById) //modern dom browsers
var iebrowser=document.all

function fadeshow(theimages, fadewidth, fadeheight, borderwidth, delay, pause, displayorder){
this.pausecheck=p
this.mouseovercheck=0
this.delay=d
this.degree=10 //initial opacity degree (10%)
this.curimageindex=0
this.nextimageindex=1
fadearray[fadearray.length]=this
this.slideshowid=fadearray.length-1
this.canvasbase="canvas"+this.slideshowid
this.curcanvas=this.canvasbase+"_0"
if (typeof displayorder!="undefined")
theimages.sort(function() {return 0.5 - Math.random();}) //thanks to Mike (aka Mwinter) :)
this.theimages=theimages
this.imageborder=parseInt(b)
this.postimages=new Array() //preload images
for (p=0; p < theimages.length ; p++){
this.postimages[p]=new Image()
this.postimages[p].src=theimages[p][0]
}
 
var fadewidth=w+this.imageborder*2
var fadeheight=h+this.imageborder*2
 
if (iebrowser && dom||dom) //if IE5+ or modern browsers (ie: Firefox)
document.write('<div id="master'+this.slideshowid+'" style="position:relative;width:'+fadewidth+'px;height:'+fadeheight+'px;overflow:hidden;"><div id="'+this.canvasbase+'_0" style="position:absolute;width:'+fadewidth+'px;height:'+fadeheight+'px;top:0;left:0;filter:progid:DXImageTransform.Microsoft.alpha(opacity=10);-moz-opacity:10;-khtml-opacity:10;background-color:'+f+'"></div><div id="'+this.canvasbase+'_1" style="position:absolute;width:'+fadewidth+'px;height:'+fadeheight+'px;top:0;left:0;filter:progid:DXImageTransform.Microsoft.alpha(opacity=10);-moz-opacity:10;background-color:'+f+'"></div></div>')
else
document.write('<div><img name="defaultslide'+this.slideshowid+'" src="'+this.postimages[0].src+'" ></div>')
 
if (iebrowser && dom||dom) //if IE5+ or modern browsers such as Firefox
this.startit()
else{
this.curimageindex++
setInterval("fadearray["+this.slideshowid+"].rotateimage()", this.delay)
}
}

function fadepic(obj){
if (obj.degree<100){
obj.degree+=10
if (obj.tempobj.filters && obj.tempobj.filters[0]){
if (typeof obj.tempobj.filters[0].opacity=="number") //if IE6+
obj.tempobj.filters[0].opacity=obj.degree
else //else if IE5.5-
obj.tempobj.style.filter="alpha(opacity="+obj.degree+")"
}
else if (obj.tempobj.style.MozOpacity)
obj.tempobj.style.MozOpacity=obj.degree/101
else if (obj.tempobj.style.KhtmlOpacity)
obj.tempobj.style.KhtmlOpacity=obj.degree/100
}
else{
clearInterval(fadeclear[obj.slideshowid])
obj.nextcanvas=(obj.curcanvas==obj.canvasbase+"_0")? obj.canvasbase+"_0" : obj.canvasbase+"_1"
obj.tempobj=iebrowser? iebrowser[obj.nextcanvas] : document.getElementById(obj.nextcanvas)
obj.populateslide(obj.tempobj, obj.nextimageindex)
obj.nextimageindex=(obj.nextimageindex<obj.postimages.length-1)? obj.nextimageindex+1 : 0
setTimeout("fadearray["+obj.slideshowid+"].rotateimage()", obj.delay)
}
}
 
fadeshow.prototype.populateslide=function(picobj, picindex){
var slideHTML='<table width="100%" height="100%"><tr><td>'
if (showm==1) {slideHTML=show+'<br />'}
if (this.theimages[picindex][1]!="") //if associated link exists for image
slideHTML+='<a href="'+this.theimages[picindex][1]+'" target="'+this.theimages[picindex][2]+'">'
slideHTML+='<img src="'+this.postimages[picindex].src+'" border="'+this.imageborder+'px"'
if (this.theimages[picindex][3]!="") {slideHTML+='alt="'+this.theimages[picindex][3]+'"'}
if (this.theimages[picindex][4]!="") {slideHTML+='title="'+this.theimages[picindex][4]+'"'}
slideHTML+='>'
if (this.theimages[picindex][1]!="") //if associated link exists for image
slideHTML+='</a>'
if (hits==1) {slideHTML+='Hits('+this.theimages[picindex][5]+')<br />'}
if (votes==1) {slideHTML+='Votes('+this.theimages[picindex][6]+')<br />'}
if (rating==1) {slideHTML+='Rating('+this.theimages[picindex][7]+')<br />'}
if (comments==1) {slideHTML+='Comments('+this.theimages[picindex][8]+')<br />'}
slideHTML+='</td></tr></table>'
picobj.innerHTML=slideHTML
}
 
 
fadeshow.prototype.rotateimage=function(){
if (this.pausecheck==1) //if pause onMouseover enabled, cache object
var cacheobj=this
if (this.mouseovercheck==1)
setTimeout(function(){cacheobj.rotateimage()}, 100)
else if (iebrowser && dom||dom){
this.resetit()
var crossobj=this.tempobj=iebrowser? iebrowser[this.curcanvas] : document.getElementById(this.curcanvas)
crossobj.style.zIndex++
fadeclear[this.slideshowid]=setInterval("fadepic(fadearray["+this.slideshowid+"])",200)
this.curcanvas=(this.curcanvas==this.canvasbase+"_0")? this.canvasbase+"_1" : this.canvasbase+"_0"
}
else{
var ns4imgobj=document.images['defaultslide'+this.slideshowid]
ns4imgobj.src=this.postimages[this.curimageindex].src
}
this.curimageindex=(this.curimageindex<this.postimages.length-1)? this.curimageindex+1 : 0
}
 
fadeshow.prototype.resetit=function(){
this.degree=10
var crossobj=iebrowser? iebrowser[this.curcanvas] : document.getElementById(this.curcanvas)
if (crossobj.filters && crossobj.filters[0]){
if (typeof crossobj.filters[0].opacity=="number") //if IE6+
crossobj.filters(0).opacity=this.degree
else //else if IE5.5-
crossobj.style.filter="alpha(opacity="+this.degree+")"
}
else if (crossobj.style.MozOpacity)
crossobj.style.MozOpacity=this.degree/101
else if (crossobj.style.KhtmlOpacity)
crossobj.style.KhtmlOpacity=obj.degree/100
}
 
 
fadeshow.prototype.startit=function(){
var crossobj=iebrowser? iebrowser[this.curcanvas] : document.getElementById(this.curcanvas)
this.populateslide(crossobj, this.curimageindex)
if (this.pausecheck==1){ //IF SLIDESHOW SHOULD PAUSE ONMOUSEOVER
var cacheobj=this
var crossobjcontainer=iebrowser? iebrowser["master"+this.slideshowid] : document.getElementById("master"+this.slideshowid)
crossobjcontainer.onmouseover=function(){cacheobj.mouseovercheck=1}
crossobjcontainer.onmouseout=function(){cacheobj.mouseovercheck=0}
}
this.rotateimage()
}

/* ]]> */
</script>
<?php

		echo "<script language=\"javascript\" type=\"text/javascript\">\n"; 
		echo '/* <![CDATA[ */';
		//new fadeshow(IMAGES_ARRAY_NAME, slideshow_width, slideshow_height, borderwidth, delay, pause (0=no, 1=yes), optionalRandomOrder)
		echo 'new fadeshow(fadeimages, 1, 1, 1, 1, 1, "")';
		echo '/* ]]> */';
		echo "</script>";	
	
echo '</div>';

function getImgNameDisplay($name){
        return $name . '.jpg';
    }

?>
