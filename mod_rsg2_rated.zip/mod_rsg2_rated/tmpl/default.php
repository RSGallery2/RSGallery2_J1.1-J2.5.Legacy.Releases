<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); ?>

<table class="rsg2_random_table" align="center">
    <tr>
        <td align="center">
            <b>Top Rated Picture<?php if( ((int)$params->get('count')) > 1)echo 's'; ?></b>
        </td>
    </tr>
    <?php
    foreach($images as $item)
    {
        echo modRSG2RatedHelper::getImageCell( $item );
        
        if( $params->get('display_title') )
        {
            echo modRSG2RatedHelper::getImageTitle( $item );
        }
        
        if( $params->get('display_rank') )
        {
            echo modRSG2RatedHelper::getImageRank( $item, $rank );
            $rank ++;
        }
        
        if( $params->get('display_votes') )
        {
            echo modRSG2RatedHelper::getImageVotes( $item );
        }
        
        if( $params->get('display_average') )
        {
            echo modRSG2RatedHelper::getImageAverage( $item, $params->get('display_average') );
        }
    }
   ?>
</table>