<?php
/**
 * Helper class for RSGallery2 top rated picture module
 * 
 * @ package Joomla! Open Source
 * @subpackage Modules
 * @ Joomla! Open Source is Free Software
 * @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
 * @ version 0.0.1
 */
 
class modRSG2RatedHelper
{
    function getRatedImage( $params )
    {  
        $count  = $params->get('count') ? (int)$params->get('count') : 1;
		$db		=& JFactory::getDBO();
		$result	= null;

		$query  = "SELECT * FROM #__rsgallery2_files ORDER BY rating/votes DESC LIMIT $count";
        
		$db->setQuery($query);
        
		$result = $db->loadObjectList();

		if ($db->getErrorNum())
        {
			JError::raiseWarning( 500, $db->stderr() );
		}

		return $result;
    }
    
    function getImageCell ( $item )
    {
		$filename       = $item->name;
		$title          = $item->title;
		$id             = $item->id;
        
        return '<tr><td align="center"><a href="index.php?option=com_rsgallery2&page=inline&id='.$id.'">'.
                '<img src="images/rsgallery/thumb/'.$filename.'.jpg" alt="'.$title.'" border="0" /></a></td></tr>';  
    }
    
    function getImageTitle ( $item )
    {
		$title          = $item->title;
        $id             = $item->id;
        return '<tr><td align="center"><a href="index.php?option=com_rsgallery2&page=inline&id='.$id.'">'.$title.'</a></td></tr>';  
    }
    
    function getImageRank ( $item, $rank )
    {
		$votes			  = $item->votes;
		$id				  = $item->id;
		return '<tr><td align="center"><a href="index.php?option=com_rsgallery2&page=inline&id='.$id.'">Rank: '.$rank.'</a></td></tr>';  
    }
    
    function getImageVotes ( $item )
    {
		$votes			  = $item->votes;
		$id				  = $item->id;
		return '<tr><td align="center"><a href="index.php?option=com_rsgallery2&page=inline&id='.$id.'">Voted: '.$votes.'</a></td></tr>';  
    }
    
    function getImageAverage ( $item, $type )
    {
		$votes			  = $item->votes;
		$rating			  = $item->rating;
		$id				  = $item->id;
		if($votes!=0)
		{
			$average		  = $rating/$votes;
            if( $type == '1' )
            {
                return '<tr><td align="center"><a href="index.php?option=com_rsgallery2&page=inline&id='.$id.'">Average: '.$average.'</a></td></tr>';  
            }
            else
            {
                $output = '<tr><td align="center"><a href="index.php?option=com_rsgallery2&page=inline&id='.$id.'">';
                for($i=1; $i<=$average; $i++)
                {
                    $output .= "<img border='0' src='/images/M_images/rating_star.png' alt='rating' />";
                }
                return $output.'</a></td></tr>'; 
            }
        }
    }
}