<?php
/**
* templates option for RSGallery2
* @version $Id: installer.php 1010 2011-01-26 15:26:17Z mirjam $
* @package RSGallery2
* @copyright (C) 2003 - 2006 RSGallery2
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* RSGallery is Free Software
*/

defined('_JEXEC') or die( 'Restricted Access' );

define( 'rsgOptions_installer_path', $rsgOptions_path . 'templateManager' );
require_once( rsgOptions_installer_path .DS. 'admin.installer.php' );

